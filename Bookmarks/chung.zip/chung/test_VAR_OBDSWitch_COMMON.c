/*****************************************************************************/
/*                            Cantata Test Script                            */
/*****************************************************************************/
/*
 *    Filename: test_VAR_OBDSWitch_COMMON.c
 *    Author: lyc1hc
 *    Generated on: 24-Jul-2020 09:50:24
 *    Generated from: VAR_OBDSWitch_COMMON.c
 */
/*****************************************************************************/
/* Environment Definition                                                    */
/*****************************************************************************/

#define TEST_SCRIPT_GENERATOR 2

/* Include files from software under test */
#include "VAR_OBDSWitch_COMMON.h"

#define CANTATA_DEFAULT_VALUE 0 /* Default value of variables & stub returns */

#include <cantpp.h>  /* Cantata Directives */
/* pragma qas cantata testscript start */
/*****************************************************************************/
/* Global Data Definitions                                                   */
/*****************************************************************************/

/* Global Functions */
extern Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8);
Std_ReturnType Dem_GetComponentFailed(Dem_ComponentIdType ComponentId, boolean * ComponentFailed);
void Dem_ReportErrorStatus(Dem_EventIdType EventId, Dem_EventStatusType EventStatus);
Std_ReturnType NvM_GetErrorStatus(NvM_BlockIdType BlockId, NvM_RequestResultType * RequestResultPtr);
Std_ReturnType NvM_WriteBlock(NvM_BlockIdType BlockId, const void * NvM_SrcPtr);
void * rba_BswSrv_MemCopy(void * xDest_pv, const void * xSrc_pcv, uint32 numBytes_u32);
extern void PRC_VAR_OBDSwitch_x24();
extern Std_ReturnType Calculated_OBD_Typ_ReadCallback(void * NvMBuffer);
extern Std_ReturnType Calculated_OBD_Typ_WriteCallback(void * NvMBuffer);
extern Std_ReturnType Calculated_OBD_Typ_ResultCallback(uint8_t NvM_Servide_ID, NvM_RequestResultType JobResult);

/* Global data */
extern volatile RBMESG_Type_OBDSwitchCalcDone_B RBMESG_OBDSwitchCalcDone_B;
extern volatile RBMESG_Type_OBDSwitchCalcResult_B RBMESG_OBDSwitchCalcResult_B;
extern boolean g_Calculated_OBD_Type_Done_B;
extern volatile MESGType_NMSG_OBD_Typ_ST MESG_NMSG_OBD_Typ_ST;
extern volatile RBMESG_Type_ExpectedOBDRequirements_N RBMESG_ExpectedOBDRequirements_N;
extern OBDRequirements_N g_Calculated_OBD_Typ_N;
extern Dem_EventIdType DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure;
extern Dem_EventStatusType DEM_EVENT_STATUS_PASSED;
extern Dem_EventStatusType DEM_EVENT_STATUS_FAILED;
extern NvM_RequestResultType NVM_Calculated_OBD_Typ_ReadResult_N;
extern OBDRequirements_N g_Previous_DCY_OBD_Typ_N;
extern uint8_t NVM_Calculated_OBD_Typ_WriteStatus_N;
extern Dem_EventIdType DemConf_DemEventParameter_OBDSwitch_NvmWriteError;
extern Dem_ComponentIdType Node_Component_Vehicle_Type;
extern volatile MESGType_NMSG_VehTyp_ST MESG_NMSG_VehTyp_ST;
extern volatile RBMESG_Type_Calculated_OBD_Typ_N RBMESG_Calculated_OBD_Typ_N;
extern Std_ReturnType NVM_Calculated_OBD_Typ_WriteResult_N;
extern VAR_WriteNvmState_N NVM_Calculated_OBD_Typ_WriteTransactionStatus_N;
extern NvM_BlockIdType NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ;
extern uint32 NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ;
extern Dem_EventIdType DemConf_DemEventParameter_OBDSwitch_NvmReadError;
Dcm_NegativeResponseCodeType map_dataNegRespCode_u8[1];

/* Expected variables for global data */
RBMESG_Type_OBDSwitchCalcDone_B expected_RBMESG_OBDSwitchCalcDone_B;
RBMESG_Type_OBDSwitchCalcResult_B expected_RBMESG_OBDSwitchCalcResult_B;
boolean expected_g_Calculated_OBD_Type_Done_B;
MESGType_NMSG_OBD_Typ_ST expected_MESG_NMSG_OBD_Typ_ST;
RBMESG_Type_ExpectedOBDRequirements_N expected_RBMESG_ExpectedOBDRequirements_N;
OBDRequirements_N expected_g_Calculated_OBD_Typ_N;
Dem_EventIdType expected_DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure;
Dem_EventStatusType expected_DEM_EVENT_STATUS_PASSED;
Dem_EventStatusType expected_DEM_EVENT_STATUS_FAILED;
NvM_RequestResultType expected_NVM_Calculated_OBD_Typ_ReadResult_N;
OBDRequirements_N expected_g_Previous_DCY_OBD_Typ_N;
uint8_t expected_NVM_Calculated_OBD_Typ_WriteStatus_N;
Dem_EventIdType expected_DemConf_DemEventParameter_OBDSwitch_NvmWriteError;
Dem_ComponentIdType expected_Node_Component_Vehicle_Type;
MESGType_NMSG_VehTyp_ST expected_MESG_NMSG_VehTyp_ST;
RBMESG_Type_Calculated_OBD_Typ_N expected_RBMESG_Calculated_OBD_Typ_N;
Std_ReturnType expected_NVM_Calculated_OBD_Typ_WriteResult_N;
VAR_WriteNvmState_N expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N;
NvM_BlockIdType expected_NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ;
uint32 expected_NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ;
Dem_EventIdType expected_DemConf_DemEventParameter_OBDSwitch_NvmReadError;
Dcm_NegativeResponseCodeType expected_map_dataNegRespCode_u8[1];

/* This function initialises global data to default values. This function       */
/* is called by every test case so must not contain test case specific settings */
static void initialise_global_data(){
    TEST_SCRIPT_WARNING("Verify initialise_global_data()\n");
    INITIALISE(RBMESG_OBDSwitchCalcDone_B);
    INITIALISE(RBMESG_OBDSwitchCalcResult_B);
    INITIALISE(g_Calculated_OBD_Type_Done_B);
    INITIALISE(MESG_NMSG_OBD_Typ_ST);
    INITIALISE(RBMESG_ExpectedOBDRequirements_N);
    INITIALISE(g_Calculated_OBD_Typ_N);
    INITIALISE(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure);
    INITIALISE(DEM_EVENT_STATUS_PASSED);
    INITIALISE(DEM_EVENT_STATUS_FAILED);
    INITIALISE(NVM_Calculated_OBD_Typ_ReadResult_N);
    INITIALISE(g_Previous_DCY_OBD_Typ_N);
    INITIALISE(NVM_Calculated_OBD_Typ_WriteStatus_N);
    INITIALISE(DemConf_DemEventParameter_OBDSwitch_NvmWriteError);
    INITIALISE(Node_Component_Vehicle_Type);
    INITIALISE(MESG_NMSG_VehTyp_ST);
    INITIALISE(RBMESG_Calculated_OBD_Typ_N);
    INITIALISE(NVM_Calculated_OBD_Typ_WriteResult_N);
    INITIALISE(NVM_Calculated_OBD_Typ_WriteTransactionStatus_N);
    INITIALISE(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ);
    INITIALISE(NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ);
    INITIALISE(DemConf_DemEventParameter_OBDSwitch_NvmReadError);
    INITIALISE(map_dataNegRespCode_u8);
}

/* This function copies the global data settings into expected variables for */
/* use in check_global_data(). It is called by every test case so must not   */
/* contain test case specific settings.                                      */
static void initialise_expected_global_data(){
    TEST_SCRIPT_WARNING("Verify initialise_expected_global_data()\n");
    COPY_TO_EXPECTED(RBMESG_OBDSwitchCalcDone_B, expected_RBMESG_OBDSwitchCalcDone_B);
    COPY_TO_EXPECTED(RBMESG_OBDSwitchCalcResult_B, expected_RBMESG_OBDSwitchCalcResult_B);
    COPY_TO_EXPECTED(g_Calculated_OBD_Type_Done_B, expected_g_Calculated_OBD_Type_Done_B);
    COPY_TO_EXPECTED(MESG_NMSG_OBD_Typ_ST, expected_MESG_NMSG_OBD_Typ_ST);
    COPY_TO_EXPECTED(RBMESG_ExpectedOBDRequirements_N, expected_RBMESG_ExpectedOBDRequirements_N);
    COPY_TO_EXPECTED(g_Calculated_OBD_Typ_N, expected_g_Calculated_OBD_Typ_N);
    COPY_TO_EXPECTED(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure, expected_DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure);
    COPY_TO_EXPECTED(DEM_EVENT_STATUS_PASSED, expected_DEM_EVENT_STATUS_PASSED);
    COPY_TO_EXPECTED(DEM_EVENT_STATUS_FAILED, expected_DEM_EVENT_STATUS_FAILED);
    COPY_TO_EXPECTED(NVM_Calculated_OBD_Typ_ReadResult_N, expected_NVM_Calculated_OBD_Typ_ReadResult_N);
    COPY_TO_EXPECTED(g_Previous_DCY_OBD_Typ_N, expected_g_Previous_DCY_OBD_Typ_N);
    COPY_TO_EXPECTED(NVM_Calculated_OBD_Typ_WriteStatus_N, expected_NVM_Calculated_OBD_Typ_WriteStatus_N);
    COPY_TO_EXPECTED(DemConf_DemEventParameter_OBDSwitch_NvmWriteError, expected_DemConf_DemEventParameter_OBDSwitch_NvmWriteError);
    COPY_TO_EXPECTED(Node_Component_Vehicle_Type, expected_Node_Component_Vehicle_Type);
    COPY_TO_EXPECTED(MESG_NMSG_VehTyp_ST, expected_MESG_NMSG_VehTyp_ST);
    COPY_TO_EXPECTED(RBMESG_Calculated_OBD_Typ_N, expected_RBMESG_Calculated_OBD_Typ_N);
    COPY_TO_EXPECTED(NVM_Calculated_OBD_Typ_WriteResult_N, expected_NVM_Calculated_OBD_Typ_WriteResult_N);
    COPY_TO_EXPECTED(NVM_Calculated_OBD_Typ_WriteTransactionStatus_N, expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N);
    COPY_TO_EXPECTED(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, expected_NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ);
    COPY_TO_EXPECTED(NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ, expected_NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ);
    COPY_TO_EXPECTED(DemConf_DemEventParameter_OBDSwitch_NvmReadError, expected_DemConf_DemEventParameter_OBDSwitch_NvmReadError);
    COPY_TO_EXPECTED(map_dataNegRespCode_u8, expected_map_dataNegRespCode_u8);
}

/* This function checks global data against the expected values. */
static void check_global_data(){
    TEST_SCRIPT_WARNING("Verify check_global_data()\n");
    CHECK_U_CHAR(RBMESG_OBDSwitchCalcDone_B, expected_RBMESG_OBDSwitchCalcDone_B);
    CHECK_U_CHAR(RBMESG_OBDSwitchCalcResult_B, expected_RBMESG_OBDSwitchCalcResult_B);
    CHECK_U_CHAR(g_Calculated_OBD_Type_Done_B, expected_g_Calculated_OBD_Type_Done_B);
    CHECK_MEMORY("MESG_NMSG_OBD_Typ_ST", &MESG_NMSG_OBD_Typ_ST, &expected_MESG_NMSG_OBD_Typ_ST, sizeof(expected_MESG_NMSG_OBD_Typ_ST));
    CHECK_U_INT(RBMESG_ExpectedOBDRequirements_N, expected_RBMESG_ExpectedOBDRequirements_N);
    CHECK_U_INT(g_Calculated_OBD_Typ_N, expected_g_Calculated_OBD_Typ_N);
    CHECK_U_INT(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure, expected_DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure);
    CHECK_U_CHAR(DEM_EVENT_STATUS_PASSED, expected_DEM_EVENT_STATUS_PASSED);
    CHECK_U_CHAR(DEM_EVENT_STATUS_FAILED, expected_DEM_EVENT_STATUS_FAILED);
    CHECK_U_CHAR(NVM_Calculated_OBD_Typ_ReadResult_N, expected_NVM_Calculated_OBD_Typ_ReadResult_N);
    CHECK_U_INT(g_Previous_DCY_OBD_Typ_N, expected_g_Previous_DCY_OBD_Typ_N);
    CHECK_U_CHAR(NVM_Calculated_OBD_Typ_WriteStatus_N, expected_NVM_Calculated_OBD_Typ_WriteStatus_N);
    CHECK_U_INT(DemConf_DemEventParameter_OBDSwitch_NvmWriteError, expected_DemConf_DemEventParameter_OBDSwitch_NvmWriteError);
    CHECK_U_CHAR(Node_Component_Vehicle_Type, expected_Node_Component_Vehicle_Type);
    CHECK_MEMORY("MESG_NMSG_VehTyp_ST", &MESG_NMSG_VehTyp_ST, &expected_MESG_NMSG_VehTyp_ST, sizeof(expected_MESG_NMSG_VehTyp_ST));
    CHECK_U_INT(RBMESG_Calculated_OBD_Typ_N, expected_RBMESG_Calculated_OBD_Typ_N);
    CHECK_U_CHAR(NVM_Calculated_OBD_Typ_WriteResult_N, expected_NVM_Calculated_OBD_Typ_WriteResult_N);
    CHECK_U_INT(NVM_Calculated_OBD_Typ_WriteTransactionStatus_N, expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N);
    CHECK_U_INT(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, expected_NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ);
    CHECK_U_INT(NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ, expected_NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ);
    CHECK_U_INT(DemConf_DemEventParameter_OBDSwitch_NvmReadError, expected_DemConf_DemEventParameter_OBDSwitch_NvmReadError);
    CHECK_MEMORY("map_dataNegRespCode_u8", map_dataNegRespCode_u8, expected_map_dataNegRespCode_u8, sizeof(expected_map_dataNegRespCode_u8));
}

/* Prototypes for test functions */
void run_tests();
void test_PRC_VAR_OBDSwitch_x24_1(int);
void test_PRC_VAR_OBDSwitch_x24_2(int);
void test_PRC_VAR_OBDSwitch_x24_3(int);
void test_PRC_VAR_OBDSwitch_x24_4(int);
void test_PRC_VAR_OBDSwitch_x24_5(int);
void test_PRC_VAR_OBDSwitch_x24_6(int);
void test_PRC_VAR_OBDSwitch_x24_7(int);
void test_PRC_VAR_OBDSwitch_x24_8(int);
void test_PRC_VAR_OBDSwitch_x24_9(int);
void test_PRC_VAR_OBDSwitch_x24_10(int);
void test_PRC_VAR_OBDSwitch_x24_11(int);
void test_PRC_VAR_OBDSwitch_x24_12(int);
void test_PRC_VAR_OBDSwitch_x24_13(int);
void test_PRC_VAR_OBDSwitch_x24_14(int);
void test_PRC_VAR_OBDSwitch_x24_15(int);
void test_PRC_VAR_OBDSwitch_x24_16(int);
void test_PRC_VAR_OBDSwitch_x24_17(int);
void test_PRC_VAR_OBDSwitch_x24_18(int);
void test_PRC_VAR_OBDSwitch_x24_19(int);
void test_PRC_VAR_OBDSwitch_x24_20(int);
void test_PRC_VAR_OBDSwitch_x24_21(int);
void test_VAR_Write_Calculated_OBD_Typ_22(int);
void test_VAR_Write_Calculated_OBD_Typ_23(int);
void test_VAR_Write_Calculated_OBD_Typ_24(int);
void test_VAR_Write_Calculated_OBD_Typ_25(int);
void test_VAR_Write_Calculated_OBD_Typ_26(int);
void test_VAR_Write_Calculated_OBD_Typ_27(int);
void test_VAR_Write_Calculated_OBD_Typ_28(int);
void test_VAR_Write_Calculated_OBD_Typ_29(int);
void test_VAR_Write_Calculated_OBD_Typ_30(int);
void test_VAR_Write_Calculated_OBD_Typ_31(int);
void test_Calculated_OBD_Typ_ReadCallback_32(int);
void test_Calculated_OBD_Typ_WriteCallback_33(int);
void test_Calculated_OBD_Typ_ResultCallback_34(int);
void test_Calculated_OBD_Typ_ResultCallback_35(int);
void test_Calculated_OBD_Typ_ResultCallback_36(int);

/*****************************************************************************/
/* Coverage Analysis                                                         */
/*****************************************************************************/
/* Coverage Rule Set: Report all Metrics */
static void rule_set(char* cppca_sut,
                     char* cppca_context)
{
    START_TEST("COVERAGE RULE SET",
               "Report all Metrics");
#ifdef CANTPP_SUBSET_DEFERRED_ANALYSIS
    TEST_SCRIPT_WARNING("Coverage Rule Set ignored in deferred analysis mode\n");
#elif CANTPP_COVERAGE_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Coverage Instrumentation has been disabled\n");
#elif CANTPP_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Instrumentation has been disabled\n");
#else
    REPORT_COVERAGE(cppca_entrypoint_cov|
                    cppca_statement_cov|
                    cppca_basicblock_cov|
                    cppca_callreturn_cov|
                    cppca_decision_cov|
                    cppca_relational_cov|
                    cppca_loop_cov|
                    cppca_booloper_cov|
                    cppca_booleff_cov,
                    cppca_sut,
                    cppca_all_details|cppca_include_catch,
                    cppca_context);
#endif
    END_TEST();
}

/*****************************************************************************/
/* Program Entry Point                                                       */
/*****************************************************************************/
int main()
{
    CONFIGURE_COVERAGE("cov:boolcomb:yes");
    OPEN_LOG("test_VAR_OBDSWitch_COMMON.ctr", false, 100);
    START_SCRIPT("VAR_OBDSWitch_COMMON", true);

    run_tests();

    return !END_SCRIPT(true);
}

/*****************************************************************************/
/* Test Control                                                              */
/*****************************************************************************/
/* run_tests() contains calls to the individual test cases, you can turn test*/
/* cases off by adding comments*/
void run_tests()
{
    test_PRC_VAR_OBDSwitch_x24_1(1);
    test_PRC_VAR_OBDSwitch_x24_2(1);
    test_PRC_VAR_OBDSwitch_x24_3(1);
    test_PRC_VAR_OBDSwitch_x24_4(1);
    test_PRC_VAR_OBDSwitch_x24_5(1);
    test_PRC_VAR_OBDSwitch_x24_6(1);
    test_PRC_VAR_OBDSwitch_x24_7(1);
    test_PRC_VAR_OBDSwitch_x24_8(1);
    test_PRC_VAR_OBDSwitch_x24_9(1);
    test_PRC_VAR_OBDSwitch_x24_10(1);
    test_PRC_VAR_OBDSwitch_x24_11(1);
    test_PRC_VAR_OBDSwitch_x24_12(1);
    test_PRC_VAR_OBDSwitch_x24_13(1);
    test_PRC_VAR_OBDSwitch_x24_14(1);
    test_PRC_VAR_OBDSwitch_x24_15(1);
    test_PRC_VAR_OBDSwitch_x24_16(1);
    test_PRC_VAR_OBDSwitch_x24_17(1);
    test_PRC_VAR_OBDSwitch_x24_18(1);
    test_PRC_VAR_OBDSwitch_x24_19(1);
    test_PRC_VAR_OBDSwitch_x24_20(1);
    test_PRC_VAR_OBDSwitch_x24_21(1);
    test_VAR_Write_Calculated_OBD_Typ_22(1);
    test_VAR_Write_Calculated_OBD_Typ_23(1);
    test_VAR_Write_Calculated_OBD_Typ_24(1);
    test_VAR_Write_Calculated_OBD_Typ_25(1);
    test_VAR_Write_Calculated_OBD_Typ_26(1);
    test_VAR_Write_Calculated_OBD_Typ_27(1);
    test_VAR_Write_Calculated_OBD_Typ_28(1);
    test_VAR_Write_Calculated_OBD_Typ_29(1);
    test_VAR_Write_Calculated_OBD_Typ_30(1);
    test_VAR_Write_Calculated_OBD_Typ_31(1);
    test_Calculated_OBD_Typ_ReadCallback_32(1);
    test_Calculated_OBD_Typ_WriteCallback_33(1);
    test_Calculated_OBD_Typ_ResultCallback_34(1);
    test_Calculated_OBD_Typ_ResultCallback_35(1);
    test_Calculated_OBD_Typ_ResultCallback_36(1);

    rule_set("*", "*");
    EXPORT_COVERAGE("test_VAR_OBDSWitch_COMMON.cov", cppca_export_replace);
}

/*****************************************************************************/
/* Test Cases                                                                */
/*****************************************************************************/

/*
***TC_1************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
            Check:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(NVM_Calculated_OBD_Typ_WriteStatus_N equal C_NVM_WRITE_INITIATED) condition
---- Preconditions:
----			- RBMESG_OBDSwitchCalcResult_B is set to  85U
----			- RBMESG_OBDSwitchCalcDone_B is set to  85U
----			- g_Calculated_OBD_Typ_N is set to  C_NoOBD_N
----			- NVM_Calculated_OBD_Typ_WriteStatus_N is set to  85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B is set to  85U
----			- expected_RBMESG_OBDSwitchCalcDone_B is set to  85U
----			- expected_RBMESG_Calculated_OBD_Typ_N is set to  C_NoOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_1(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcResult_B = 85U;
    RBMESG_OBDSwitchCalcDone_B = 85U;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 85U;
    expected_RBMESG_OBDSwitchCalcDone_B = 85U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;

    START_TEST("1_PRC_VAR_OBDSwitch_x24",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_2************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(NVM_Calculated_OBD_Typ_WriteStatus_N equal C_NVM_WRITE_INITIATED) condition
                - VAR_Write_Calculated_OBD_Typ(&g_Calculated_OBD_Typ_N, &ErrorCode) is called and return value to NVM_Calculated_OBD_Typ_WriteResult_N
                - Check false case for (NVM_Calculated_OBD_Typ_WriteResult_N equal E_NOT_OK)
                - Check false case for (NVM_Calculated_OBD_Typ_WriteResult_N equal E_OK)
---- Preconditions:
----			- RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- RBMESG_OBDSwitchCalcDone_B  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 1U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 85U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_NVM_Calculated_OBD_Typ_WriteResult_N  is set to 85U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_2(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcResult_B = 85U;
    RBMESG_OBDSwitchCalcDone_B = 85U;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 1U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 85U;
    expected_RBMESG_OBDSwitchCalcDone_B = 85U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_NVM_Calculated_OBD_Typ_WriteResult_N = 85U;

    START_TEST("2_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of NVM_Calculated_OBD_Typ_WriteStatus_N == 0x1 at line number 299 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("VAR_Write_Calculated_OBD_Typ#1");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_3************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(NVM_Calculated_OBD_Typ_WriteStatus_N equal C_NVM_WRITE_INITIATED) condition
                - VAR_Write_Calculated_OBD_Typ(&g_Calculated_OBD_Typ_N, &ErrorCode) is called and return value to NVM_Calculated_OBD_Typ_WriteResult_N
                - Check false case for (NVM_Calculated_OBD_Typ_WriteResult_N equal E_NOT_OK)
                - Check true case for (NVM_Calculated_OBD_Typ_WriteResult_N equal E_OK)
                - Dem_ReportErrorStatus(DemConf_DemEventParameter_OBDSwitch_NvmWriteError, DEM_EVENT_STATUS_PASSED) is called
                - NVM_Calculated_OBD_Typ_WriteStatus_N is set to C_NVM_WRITE_NOTREQUESTED
---- Preconditions:
----			- RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- RBMESG_OBDSwitchCalcDone_B  is set to 85U
----			- DemConf_DemEventParameter_OBDSwitch_NvmWriteError  is set to 0U
----			- DEM_EVENT_STATUS_PASSED  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 1U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 85U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 0U
----			- expected_NVM_Calculated_OBD_Typ_WriteResult_N  is set to 0U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_3(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcResult_B = 85U;
    RBMESG_OBDSwitchCalcDone_B = 85U;
    DemConf_DemEventParameter_OBDSwitch_NvmWriteError = 0U;
    DEM_EVENT_STATUS_PASSED = 85U;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 1U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 85U;
    expected_RBMESG_OBDSwitchCalcDone_B = 85U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_NVM_Calculated_OBD_Typ_WriteStatus_N = 0U;
    expected_NVM_Calculated_OBD_Typ_WriteResult_N = 0U;

    START_TEST("3_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of NVM_Calculated_OBD_Typ_WriteResult_N == 0 at line number 308 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("VAR_Write_Calculated_OBD_Typ#2;Dem_ReportErrorStatus#1");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_4************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(NVM_Calculated_OBD_Typ_WriteStatus_N equal C_NVM_WRITE_INITIATED) condition
                - VAR_Write_Calculated_OBD_Typ(&g_Calculated_OBD_Typ_N, &ErrorCode) is called and return value to NVM_Calculated_OBD_Typ_WriteResult_N
                - Check true case for (NVM_Calculated_OBD_Typ_WriteResult_N equal E_NOT_OK)
                - Dem_ReportErrorStatus(DemConf_DemEventParameter_OBDSwitch_NvmWriteError, DEM_EVENT_STATUS_FAILED) is called
                - NVM_Calculated_OBD_Typ_WriteStatus_N is set to C_NVM_WRITE_NOTREQUESTED
---- Preconditions:
----			- RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- RBMESG_OBDSwitchCalcDone_B  is set to 85U
----			- DemConf_DemEventParameter_OBDSwitch_NvmWriteError  is set to 0U
----			- DEM_EVENT_STATUS_FAILED  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 1U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 85U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 0U
----			- expected_NVM_Calculated_OBD_Typ_WriteResult_N  is set to 1U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_4(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcResult_B = 85U;
    RBMESG_OBDSwitchCalcDone_B = 85U;
    DemConf_DemEventParameter_OBDSwitch_NvmWriteError = 0U;
    DEM_EVENT_STATUS_FAILED = 85U;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 1U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 85U;
    expected_RBMESG_OBDSwitchCalcDone_B = 85U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_NVM_Calculated_OBD_Typ_WriteStatus_N = 0U;
    expected_NVM_Calculated_OBD_Typ_WriteResult_N = 1U;

    START_TEST("4_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of NVM_Calculated_OBD_Typ_WriteResult_N == 0x1 at line number 303 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("VAR_Write_Calculated_OBD_Typ#3;Dem_ReportErrorStatus#1");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_5************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check false case for (g_Calculated_OBD_Typ_N equal C_USOBD_N) condition
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 85U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 0U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_5(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    g_Calculated_OBD_Type_Done_B = 85U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 0U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;

    START_TEST("5_PRC_VAR_OBDSwitch_x24",
               "created to solve false case of l_OBDSwitchCalcDone_B at line number 173 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_6************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check true case for (g_Calculated_OBD_Typ_N equal C_USOBD_N) condition
                - Check true case for l_IsComponentFailed_B equal true condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_Vehicle_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - l_OBDSwitchCalcResult_B is set to true
                - l_OBDSwitchCalcDone_B is set to true

---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- Node_Component_Vehicle_Type  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 85U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 1U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_6(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    Node_Component_Vehicle_Type = 85U;
    g_Calculated_OBD_Typ_N = C_USOBD_N;
    g_Calculated_OBD_Type_Done_B = 85U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 1U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;

    START_TEST("6_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of g_Calculated_OBD_Typ_N == C_USOBD_N at line number 240 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#1");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_7************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check true case for (g_Calculated_OBD_Typ_N equal C_USOBD_N) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_Vehicle_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B equal true condition
                - RcvMESG(l_NMSG_VehTyp_ST, NMSG_VehTyp_ST) is called
                - Check false case for (l_NMSG_VehTyp_ST with element Qualifier_N equal VehicleType_Qualifier_Normal)

---- Preconditions:
----			- RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_VehTyp_ST with element Qualifier_N  is set to VehicleType_Qualifier_Init
----			- Node_Component_Vehicle_Type  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 85U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_7(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcResult_B = 85U;
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_VehTyp_ST.Qualifier_N = VehicleType_Qualifier_Init;
    Node_Component_Vehicle_Type = 85U;
    g_Calculated_OBD_Typ_N = C_USOBD_N;
    g_Calculated_OBD_Type_Done_B = 85U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 85U;
    expected_RBMESG_OBDSwitchCalcDone_B = 0U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;

    START_TEST("7_PRC_VAR_OBDSwitch_x24",
               "created to solve false case of l_IsComponentFailed_B at line number 248 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#2");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_8************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check true case for (g_Calculated_OBD_Typ_N equal C_USOBD_N) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_Vehicle_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B equal true condition
                - RcvMESG(l_NMSG_VehTyp_ST, NMSG_VehTyp_ST) is called
                - Check true case for (l_NMSG_VehTyp_ST with element Qualifier_N equal VehicleType_Qualifier_Normal)
                - Check false case for (l_NMSG_VehTyp_ST with element VehTyp  equal to  VehicleType_N_Hybrid or l_NMSG_VehTyp_ST with element VehTyp  equal to  VehicleType_N_E_Vehicle_With_Range_Extender)
                - l_OBDSwitchCalcResult_B is set to  false
                - l_OBDSwitchCalcDone_B is set to  true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_VehTyp_ST with element VehTyp  is set to VehicleType_N_Combustion_Vehicle
----			- MESG_NMSG_VehTyp_ST with element Qualifier_N  is set to VehicleType_Qualifier_Normal
----			- Node_Component_Vehicle_Type  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 85U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 0U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_8(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_VehTyp_ST.VehTyp = VehicleType_N_Combustion_Vehicle;
    MESG_NMSG_VehTyp_ST.Qualifier_N = VehicleType_Qualifier_Normal;
    Node_Component_Vehicle_Type = 85U;
    g_Calculated_OBD_Typ_N = C_USOBD_N;
    g_Calculated_OBD_Type_Done_B = 85U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 0U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;

    START_TEST("8_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of l_NMSG_VehTyp_ST.Qualifier_N == VehicleType_Qualifier_Normal at line number 259 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#2");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_9************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check true case for (g_Calculated_OBD_Typ_N equal C_USOBD_N) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_Vehicle_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B equal true condition
                - RcvMESG(l_NMSG_VehTyp_ST, NMSG_VehTyp_ST) is called
                - Check true case for (l_NMSG_VehTyp_ST with element Qualifier_N equal VehicleType_Qualifier_Normal)
                - Check true case for (l_NMSG_VehTyp_ST with element VehTyp  equal to  VehicleType_N_Hybrid or l_NMSG_VehTyp_ST with element VehTyp  equal to  VehicleType_N_E_Vehicle_With_Range_Extender)
                - l_OBDSwitchCalcResult_B is set to  true
                - l_OBDSwitchCalcDone_B is set to  true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_VehTyp_ST with element VehTyp  is set to VehicleType_N_E_Vehicle_With_Range_Extender
----			- MESG_NMSG_VehTyp_ST with element Qualifier_N  is set to VehicleType_Qualifier_Normal
----			- Node_Component_Vehicle_Type  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 85U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 1U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_9(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_VehTyp_ST.VehTyp = VehicleType_N_E_Vehicle_With_Range_Extender;
    MESG_NMSG_VehTyp_ST.Qualifier_N = VehicleType_Qualifier_Normal;
    Node_Component_Vehicle_Type = 85U;
    g_Calculated_OBD_Typ_N = C_USOBD_N;
    g_Calculated_OBD_Type_Done_B = 85U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 1U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;

    START_TEST("9_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of l_NMSG_VehTyp_ST.VehTyp == VehicleType_N_E_Vehicle_With_Range_Extender at line number 261 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#2");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_10************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check true case for (g_Calculated_OBD_Typ_N equal C_USOBD_N) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_Vehicle_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B equal true condition
                - RcvMESG(l_NMSG_VehTyp_ST, NMSG_VehTyp_ST) is called
                - Check true case for (l_NMSG_VehTyp_ST with element Qualifier_N equal VehicleType_Qualifier_Normal)
                - Check true case for (l_NMSG_VehTyp_ST with element VehTyp  equal to  VehicleType_N_Hybrid or l_NMSG_VehTyp_ST with element VehTyp  equal to  VehicleType_N_E_Vehicle_With_Range_Extender)
                - l_OBDSwitchCalcResult_B is set to  true
                - l_OBDSwitchCalcDone_B is set to  true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_VehTyp_ST with element VehTyp  is set to VehicleType_N_Hybrid
----			- MESG_NMSG_VehTyp_ST with element Qualifier_N  is set to VehicleType_Qualifier_Normal
----			- Node_Component_Vehicle_Type  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 85U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 1U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_10(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_VehTyp_ST.VehTyp = VehicleType_N_Hybrid;
    MESG_NMSG_VehTyp_ST.Qualifier_N = VehicleType_Qualifier_Normal;
    Node_Component_Vehicle_Type = 85U;
    g_Calculated_OBD_Typ_N = C_USOBD_N;
    g_Calculated_OBD_Type_Done_B = 85U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 1U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;

    START_TEST("10_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of l_NMSG_VehTyp_ST.VehTyp == VehicleType_N_Hybrid at line number 261 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#2");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_11************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check false case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  g_Calculated_OBD_Type_Done_B) condition
                - Check true case for (g_Calculated_OBD_Typ_N equal C_USOBD_N) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_Vehicle_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - l_IsComponentFailed_B is set to  true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- Node_Component_Vehicle_Type  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 85U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 1U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_11(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    Node_Component_Vehicle_Type = 85U;
    g_Calculated_OBD_Typ_N = C_USOBD_N;
    g_Calculated_OBD_Type_Done_B = 85U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 1U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;

    START_TEST("11_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of Dem_GetComponentFailed(Node_Component_Vehicle_Type, &l_IsComponentFailed_B) == 0x1 at line number 243 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#3");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_12************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check true case for l_IsComponentFailed_B condition
                - g_Calculated_OBD_Type_Done_B is set to true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 0U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_g_Calculated_OBD_Type_Done_B  is set to 1U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_12(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 0U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_g_Calculated_OBD_Type_Done_B = 1U;

    START_TEST("12_PRC_VAR_OBDSwitch_x24",
               "created to solve false case of g_Calculated_OBD_Type_Done_B at line number 173 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#4");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_13************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B condition
                - RcvMESG(l_NMSG_OBD_Typ_ST, NMSG_OBD_Typ_ST) is called
                - RBMESG_RcvMESG(l_ExpectedOBDRequirements_N, ExpectedOBDRequirements_N) is called
                - Check false case for(l_NMSG_OBD_Typ_ST with element Qualifier_N equal OBD_Typ_Qualifier_Normal)

---- Preconditions:
----			- RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_OBD_Typ_ST with element Qualifier_N  is set to OBD_Typ_Qualifier_Init
----			- g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 85U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_13(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcResult_B = 85U;
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_OBD_Typ_ST.Qualifier_N = OBD_Typ_Qualifier_Init;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 85U;
    expected_RBMESG_OBDSwitchCalcDone_B = 0U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;

    START_TEST("13_PRC_VAR_OBDSwitch_x24",
               "created to solve false case of l_IsComponentFailed_B at line number 181 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#5");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_14************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B condition
                - RcvMESG(l_NMSG_OBD_Typ_ST, NMSG_OBD_Typ_ST) is called
                - RBMESG_RcvMESG(l_ExpectedOBDRequirements_N, ExpectedOBDRequirements_N) is called
                - Check true case for(l_NMSG_OBD_Typ_ST with element Qualifier_N equal OBD_Typ_Qualifier_Normal)
                - Check true case for( ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_NoOBD_RdW)    and  (l_ExpectedOBDRequirements_N  equal to  C_NoOBD_N) )    or
                                       ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_US_OBD)      and  (l_ExpectedOBDRequirements_N  equal to  C_USOBD_N) )    )
                - g_Calculated_OBD_Typ_N is set to l_ExpectedOBDRequirements_N
                - Dem_ReportErrorStatus(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure, DEM_EVENT_STATUS_PASSED) is called
                - g_Calculated_OBD_Type_Done_B is set to true
                - Check true case for((NVM_Calculated_OBD_Typ_ReadResult_N diff NVM_REQ_OK) or (g_Previous_DCY_OBD_Typ_N diff g_Calculated_OBD_Typ_N)) condition
                - NVM_Calculated_OBD_Typ_WriteStatus_N is set to C_NVM_WRITE_INITIATED

---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_OBD_Typ_ST with element OBD_Typ  is set to OBD_Typ_N_NoOBD_RdW
----			- MESG_NMSG_OBD_Typ_ST with element Qualifier_N  is set to OBD_Typ_Qualifier_Normal
----			- RBMESG_ExpectedOBDRequirements_N  is set to C_NoOBD_N
----			- DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure  is set to 0U
----			- DEM_EVENT_STATUS_PASSED  is set to 85U
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_ReadResult_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 0U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_g_Calculated_OBD_Type_Done_B  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteResult_N  is set to 85U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_14(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_OBD_Typ_ST.OBD_Typ = OBD_Typ_N_NoOBD_RdW;
    MESG_NMSG_OBD_Typ_ST.Qualifier_N = OBD_Typ_Qualifier_Normal;
    RBMESG_ExpectedOBDRequirements_N = C_NoOBD_N;
    DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure = 0U;
    DEM_EVENT_STATUS_PASSED = 85U;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_ReadResult_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 0U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_g_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_g_Calculated_OBD_Type_Done_B = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteStatus_N = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteResult_N = 85U;

    START_TEST("14_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of l_NMSG_OBD_Typ_ST.Qualifier_N == OBD_Typ_Qualifier_Normal at line number 192 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#5;Dem_ReportErrorStatus#1;VAR_Write_Calculated_OBD_Typ#1");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_15************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B condition
                - RcvMESG(l_NMSG_OBD_Typ_ST, NMSG_OBD_Typ_ST) is called
                - RBMESG_RcvMESG(l_ExpectedOBDRequirements_N, ExpectedOBDRequirements_N) is called
                - Check true case for(l_NMSG_OBD_Typ_ST with element Qualifier_N equal OBD_Typ_Qualifier_Normal)
                - Check true case for( ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_NoOBD_RdW)    and  (l_ExpectedOBDRequirements_N  equal to  C_NoOBD_N) )    or
                                       ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_US_OBD)      and  (l_ExpectedOBDRequirements_N  equal to  C_USOBD_N) )    )
                - g_Calculated_OBD_Typ_N is set to l_ExpectedOBDRequirements_N
                - Dem_ReportErrorStatus(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure, DEM_EVENT_STATUS_PASSED) is called
                - g_Calculated_OBD_Type_Done_B is set to true
                - Check false case for((NVM_Calculated_OBD_Typ_ReadResult_N diff NVM_REQ_OK) or (g_Previous_DCY_OBD_Typ_N diff g_Calculated_OBD_Typ_N)) condition
                - Dem_ReportErrorStatus(DemConf_DemEventParameter_OBDSwitch_NvmWriteError, DEM_EVENT_STATUS_PASSED) is called
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_OBD_Typ_ST with element OBD_Typ  is set to OBD_Typ_N_NoOBD_RdW
----			- MESG_NMSG_OBD_Typ_ST with element Qualifier_N  is set to OBD_Typ_Qualifier_Normal
----			- RBMESG_ExpectedOBDRequirements_N  is set to C_NoOBD_N
----			- DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure  is set to 0U
----			- DemConf_DemEventParameter_OBDSwitch_NvmWriteError  is set to 0U
----			- DEM_EVENT_STATUS_PASSED  is set to 85U
----			- g_Previous_DCY_OBD_Typ_N  is set to C_NoOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
----			- NVM_Calculated_OBD_Typ_ReadResult_N  is set to 0U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 0U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_g_Calculated_OBD_Type_Done_B  is set to 1U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_15(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_OBD_Typ_ST.OBD_Typ = OBD_Typ_N_NoOBD_RdW;
    MESG_NMSG_OBD_Typ_ST.Qualifier_N = OBD_Typ_Qualifier_Normal;
    RBMESG_ExpectedOBDRequirements_N = C_NoOBD_N;
    DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure = 0U;
    DemConf_DemEventParameter_OBDSwitch_NvmWriteError = 0U;
    DEM_EVENT_STATUS_PASSED = 85U;
    g_Previous_DCY_OBD_Typ_N = C_NoOBD_N;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    NVM_Calculated_OBD_Typ_ReadResult_N = 0U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 0U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_g_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_g_Calculated_OBD_Type_Done_B = 1U;

    START_TEST("15_PRC_VAR_OBDSwitch_x24",
               "created to solve false case of NVM_Calculated_OBD_Typ_ReadResult_N != 0 at line number 216");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#5;Dem_ReportErrorStatus#1;Dem_ReportErrorStatus#1");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_16************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B condition
                - RcvMESG(l_NMSG_OBD_Typ_ST, NMSG_OBD_Typ_ST) is called
                - RBMESG_RcvMESG(l_ExpectedOBDRequirements_N, ExpectedOBDRequirements_N) is called
                - Check true case for(l_NMSG_OBD_Typ_ST with element Qualifier_N equal OBD_Typ_Qualifier_Normal)
                - Check true case for( ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_NoOBD_RdW)    and  (l_ExpectedOBDRequirements_N  equal to  C_NoOBD_N) )    or
                                       ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_US_OBD)      and  (l_ExpectedOBDRequirements_N  equal to  C_USOBD_N) )    )
                - g_Calculated_OBD_Typ_N is set to l_ExpectedOBDRequirements_N
                - Dem_ReportErrorStatus(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure, DEM_EVENT_STATUS_PASSED) is called
                - g_Calculated_OBD_Type_Done_B is set to true
                - Check false case for((NVM_Calculated_OBD_Typ_ReadResult_N diff NVM_REQ_OK) or (g_Previous_DCY_OBD_Typ_N diff g_Calculated_OBD_Typ_N)) condition
                - Dem_ReportErrorStatus(DemConf_DemEventParameter_OBDSwitch_NvmWriteError, DEM_EVENT_STATUS_PASSED) is called
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_OBD_Typ_ST with element OBD_Typ  is set to OBD_Typ_N_NoOBD_RdW
----			- MESG_NMSG_OBD_Typ_ST with element Qualifier_N  is set to OBD_Typ_Qualifier_Normal
----			- RBMESG_ExpectedOBDRequirements_N  is set to C_NoOBD_N
----			- DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure  is set to 0U
----			- DEM_EVENT_STATUS_PASSED  is set to 85U
----			- g_Previous_DCY_OBD_Typ_N  is set to C_USOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_ReadResult_N  is set to 0U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 0U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_g_Calculated_OBD_Type_Done_B  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteResult_N  is set to 85U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_16(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_OBD_Typ_ST.OBD_Typ = OBD_Typ_N_NoOBD_RdW;
    MESG_NMSG_OBD_Typ_ST.Qualifier_N = OBD_Typ_Qualifier_Normal;
    RBMESG_ExpectedOBDRequirements_N = C_NoOBD_N;
    DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure = 0U;
    DEM_EVENT_STATUS_PASSED = 85U;
    g_Previous_DCY_OBD_Typ_N = C_USOBD_N;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_ReadResult_N = 0U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 0U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_g_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_g_Calculated_OBD_Type_Done_B = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteStatus_N = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteResult_N = 85U;

    START_TEST("16_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of g_Previous_DCY_OBD_Typ_N != g_Calculated_OBD_Typ_N at line number 216");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#5;Dem_ReportErrorStatus#1;VAR_Write_Calculated_OBD_Typ#1");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_17************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B condition
                - RcvMESG(l_NMSG_OBD_Typ_ST, NMSG_OBD_Typ_ST) is called
                - RBMESG_RcvMESG(l_ExpectedOBDRequirements_N, ExpectedOBDRequirements_N) is called
                - Check true case for(l_NMSG_OBD_Typ_ST with element Qualifier_N equal OBD_Typ_Qualifier_Normal)
                - Check false case for( ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_NoOBD_RdW)    and  (l_ExpectedOBDRequirements_N  equal to  C_NoOBD_N) )    or
                                       ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_US_OBD)      and  (l_ExpectedOBDRequirements_N  equal to  C_USOBD_N) )    )
                - Ag_Calculated_OBD_Typ_N is set to C_USOBD_N
                - ADem_ReportErrorStatus(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure, DEM_EVENT_STATUS_FAILED) is called
                - Al_OBDSwitchCalcResult_B is set to true
                - Al_OBDSwitchCalcDone_B is set to true
                - g_Calculated_OBD_Type_Done_B is set to true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_OBD_Typ_ST with element OBD_Typ  is set to OBD_Typ_N_NoOBD_RdW
----			- MESG_NMSG_OBD_Typ_ST with element Qualifier_N  is set to OBD_Typ_Qualifier_Normal
----			- RBMESG_ExpectedOBDRequirements_N  is set to C_USOBD_N
----			- DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure  is set to 0U
----			- DEM_EVENT_STATUS_FAILED  is set to 85U
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_ReadResult_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 1U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_g_Calculated_OBD_Type_Done_B  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteResult_N  is set to 85U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_17(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_OBD_Typ_ST.OBD_Typ = OBD_Typ_N_NoOBD_RdW;
    MESG_NMSG_OBD_Typ_ST.Qualifier_N = OBD_Typ_Qualifier_Normal;
    RBMESG_ExpectedOBDRequirements_N = C_USOBD_N;
    DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure = 0U;
    DEM_EVENT_STATUS_FAILED = 85U;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_ReadResult_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 1U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_g_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_g_Calculated_OBD_Type_Done_B = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteStatus_N = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteResult_N = 85U;

    START_TEST("17_PRC_VAR_OBDSwitch_x24",
               "created to solve false case of l_ExpectedOBDRequirements_N == C_NoOBD_N at line number 195");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#5;Dem_ReportErrorStatus#1;VAR_Write_Calculated_OBD_Typ#4");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_18************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B condition
                - RcvMESG(l_NMSG_OBD_Typ_ST, NMSG_OBD_Typ_ST) is called
                - RBMESG_RcvMESG(l_ExpectedOBDRequirements_N, ExpectedOBDRequirements_N) is called
                - Check true case for(l_NMSG_OBD_Typ_ST with element Qualifier_N equal OBD_Typ_Qualifier_Normal)
                - Check false case for( ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_NoOBD_RdW)    and  (l_ExpectedOBDRequirements_N  equal to  C_NoOBD_N) )    or
                                       ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_US_OBD)      and  (l_ExpectedOBDRequirements_N  equal to  C_USOBD_N) )    )
                - Ag_Calculated_OBD_Typ_N is set to C_USOBD_N
                - ADem_ReportErrorStatus(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure, DEM_EVENT_STATUS_FAILED) is called
                - Al_OBDSwitchCalcResult_B is set to true
                - Al_OBDSwitchCalcDone_B is set to true
                - g_Calculated_OBD_Type_Done_B is set to true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_OBD_Typ_ST with element OBD_Typ  is set to OBD_Typ_N_US_OBD
----			- MESG_NMSG_OBD_Typ_ST with element Qualifier_N  is set to OBD_Typ_Qualifier_Normal
----			- RBMESG_ExpectedOBDRequirements_N  is set to C_NoOBD_N
----			- DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure  is set to 0U
----			- DEM_EVENT_STATUS_FAILED  is set to 85U
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_ReadResult_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 1U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_g_Calculated_OBD_Type_Done_B  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteResult_N  is set to 85U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_18(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_OBD_Typ_ST.OBD_Typ = OBD_Typ_N_US_OBD;
    MESG_NMSG_OBD_Typ_ST.Qualifier_N = OBD_Typ_Qualifier_Normal;
    RBMESG_ExpectedOBDRequirements_N = C_NoOBD_N;
    DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure = 0U;
    DEM_EVENT_STATUS_FAILED = 85U;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_ReadResult_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 1U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_g_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_g_Calculated_OBD_Type_Done_B = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteStatus_N = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteResult_N = 85U;

    START_TEST("18_PRC_VAR_OBDSwitch_x24",
               "created to solve false case of l_NMSG_OBD_Typ_ST.OBD_Typ == OBD_Typ_N_NoOBD_RdW at line number 195");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#5;Dem_ReportErrorStatus#1;VAR_Write_Calculated_OBD_Typ#4");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_19************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B condition
                - RcvMESG(l_NMSG_OBD_Typ_ST, NMSG_OBD_Typ_ST) is called
                - RBMESG_RcvMESG(l_ExpectedOBDRequirements_N, ExpectedOBDRequirements_N) is called
                - Check true case for(l_NMSG_OBD_Typ_ST with element Qualifier_N equal OBD_Typ_Qualifier_Normal)
                - Check false case for( ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_NoOBD_RdW)    and  (l_ExpectedOBDRequirements_N  equal to  C_NoOBD_N) )    or
                                       ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_US_OBD)      and  (l_ExpectedOBDRequirements_N  equal to  C_USOBD_N) )    )
                - Ag_Calculated_OBD_Typ_N is set to C_USOBD_N
                - ADem_ReportErrorStatus(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure, DEM_EVENT_STATUS_FAILED) is called
                - Al_OBDSwitchCalcResult_B is set to true
                - Al_OBDSwitchCalcDone_B is set to true
                - g_Calculated_OBD_Type_Done_B is set to true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_OBD_Typ_ST with element OBD_Typ  is set to OBD_Typ_N_US_OBD
----			- MESG_NMSG_OBD_Typ_ST with element Qualifier_N  is set to OBD_Typ_Qualifier_Normal
----			- RBMESG_ExpectedOBDRequirements_N  is set to C_USOBD_N
----			- DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure  is set to 0U
----			- DEM_EVENT_STATUS_PASSED  is set to 85U
----			- Node_Component_Vehicle_Type  is set to 85U
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_ReadResult_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 1U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_g_Calculated_OBD_Type_Done_B  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteResult_N  is set to 85U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_19(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_OBD_Typ_ST.OBD_Typ = OBD_Typ_N_US_OBD;
    MESG_NMSG_OBD_Typ_ST.Qualifier_N = OBD_Typ_Qualifier_Normal;
    RBMESG_ExpectedOBDRequirements_N = C_USOBD_N;
    DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure = 0U;
    DEM_EVENT_STATUS_PASSED = 85U;
    Node_Component_Vehicle_Type = 85U;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_ReadResult_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 1U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_g_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_g_Calculated_OBD_Type_Done_B = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteStatus_N = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteResult_N = 85U;

    START_TEST("19_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of l_ExpectedOBDRequirements_N == C_USOBD_N at line number 196");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#5;Dem_ReportErrorStatus#1;Dem_GetComponentFailed#6;VAR_Write_Calculated_OBD_Typ#4");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_20************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check false case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - Check false case for l_IsComponentFailed_B condition
                - RcvMESG(l_NMSG_OBD_Typ_ST, NMSG_OBD_Typ_ST) is called
                - RBMESG_RcvMESG(l_ExpectedOBDRequirements_N, ExpectedOBDRequirements_N) is called
                - Check true case for(l_NMSG_OBD_Typ_ST with element Qualifier_N equal OBD_Typ_Qualifier_Normal)
                - Check false case for( ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_NoOBD_RdW)    and  (l_ExpectedOBDRequirements_N  equal to  C_NoOBD_N) )    or
                                       ( (l_NMSG_OBD_Typ_ST with element OBD_Typ  equal to  OBD_Typ_N_US_OBD)      and  (l_ExpectedOBDRequirements_N  equal to  C_USOBD_N) )    )
                - Ag_Calculated_OBD_Typ_N is set to C_USOBD_N
                - ADem_ReportErrorStatus(DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure, DEM_EVENT_STATUS_FAILED) is called
                - Al_OBDSwitchCalcResult_B is set to true
                - Al_OBDSwitchCalcDone_B is set to true
                - g_Calculated_OBD_Type_Done_B is set to true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- MESG_NMSG_OBD_Typ_ST with element OBD_Typ  is set to OBD_Typ_N_reserviert
----			- MESG_NMSG_OBD_Typ_ST with element Qualifier_N  is set to OBD_Typ_Qualifier_Normal
----			- DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure  is set to 0U
----			- DEM_EVENT_STATUS_FAILED  is set to 85U
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_ReadResult_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 1U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_g_Calculated_OBD_Type_Done_B  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteResult_N  is set to 85U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_20(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    MESG_NMSG_OBD_Typ_ST.OBD_Typ = OBD_Typ_N_reserviert;
    MESG_NMSG_OBD_Typ_ST.Qualifier_N = OBD_Typ_Qualifier_Normal;
    DemConf_DemEventParameter_VarCheckOBDCodierplausiFailure = 0U;
    DEM_EVENT_STATUS_FAILED = 85U;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_ReadResult_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 1U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_g_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_g_Calculated_OBD_Type_Done_B = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteStatus_N = 1U;
    expected_NVM_Calculated_OBD_Typ_WriteResult_N = 85U;

    START_TEST("20_PRC_VAR_OBDSwitch_x24",
               "created to solve false case of l_NMSG_OBD_Typ_ST.OBD_Typ == OBD_Typ_N_US_OBD at line number 196");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#5;Dem_ReportErrorStatus#1;VAR_Write_Calculated_OBD_Typ#4");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_21************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function void PRC_VAR_OBDSwitch_x24(void)
---- Test goal:
                - Declare ErrorCode is set to 0x00 with uint8_t type
                - Declare l_ExpectedOBDRequirements_N with OBDRequirements_N type
                - Declare l_NMSG_OBD_Typ_ST with OBD_Typ_ST type
                - Declare l_NMSG_VehTyp_ST with VehTyp_ST type
                - Declare l_OBDSwitchCalcDone_B with boolean type
                - Declare l_OBDSwitchCalcResult_B with boolean type
                - Declare l_IsComponentFailed_B with boolean type
                - RBMESG_RcvMESG(l_OBDSwitchCalcDone_B, OBDSwitchCalcDone_B) is called
                - RBMESG_RcvMESG(l_OBDSwitchCalcResult_B, OBDSwitchCalcResult_B) is called
                - RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                - RBMESG_SendMESG(OBDSwitchCalcDone_B, l_OBDSwitchCalcDone_B) is called
                - RBMESG_SendMESG(OBDSwitchCalcResult_B, l_OBDSwitchCalcResult_B) is called
                - Check true case for(to inverse of l_OBDSwitchCalcDone_B and  to inverse of g_Calculated_OBD_Type_Done_B) condition
                - Check true case for(Dem_GetComponentFailed(Node_Component_OBD_Type, at address of l_IsComponentFailed_B) equal E_NOT_OK)
                - l_IsComponentFailed_B is set to true
---- Preconditions:
----			- RBMESG_OBDSwitchCalcDone_B  is set to 0U
----			- g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- g_Calculated_OBD_Type_Done_B  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteStatus_N  is set to 85U
---- Test steps:
----        Input values:
----        Expected result:
----			- expected_RBMESG_OBDSwitchCalcResult_B  is set to 0U
----			- expected_RBMESG_OBDSwitchCalcDone_B  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_g_Calculated_OBD_Type_Done_B  is set to 1U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_PRC_VAR_OBDSwitch_x24_21(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    RBMESG_OBDSwitchCalcDone_B = 0U;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    g_Calculated_OBD_Type_Done_B = 0U;
    NVM_Calculated_OBD_Typ_WriteStatus_N = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_OBDSwitchCalcResult_B = 0U;
    expected_RBMESG_OBDSwitchCalcDone_B = 1U;
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_g_Calculated_OBD_Type_Done_B = 1U;

    START_TEST("21_PRC_VAR_OBDSwitch_x24",
               "created to solve true case of Dem_GetComponentFailed(55, &l_IsComponentFailed_B) == 0x1 at line number 176 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_GetComponentFailed#7");

            /* Call SUT */
            PRC_VAR_OBDSwitch_x24();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_22************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
			Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case C_InitWrite of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - check false (NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, at address of l_NvM_Result) equal E_OK) condition
                - NVM_Calculated_OBD_Typ_WriteTransactionStatus_N is set to C_ErrorWrite
                - Return dataRetVal_u8
---- Preconditions:
----			- NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_InitWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to NULL
----        Expected result:
----			- returnValue  is set to 10U
----			- expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ErrorWrite
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_22(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ = 0U;
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_InitWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ErrorWrite;

    START_TEST("22_VAR_Write_Calculated_OBD_Typ",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("NvM_GetErrorStatus#1");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 10U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_23************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
            Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case C_InitWrite of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - check true (NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, at address of l_NvM_Result) equal E_OK) condition
                - check true (l_NvM_Result diff NVM_REQ_PENDING)
                - check false (NvM_WriteBlock(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, Data) equal E_OK)
                - NVM_Calculated_OBD_Typ_WriteTransactionStatus_N is set to C_ErrorWrite
                - Return dataRetVal_u8
---- Preconditions:
----			- NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_InitWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to NULL
----        Expected result:
----			- returnValue  is set to 10U
----			- expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ErrorWrite
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_23(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ = 0U;
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_InitWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ErrorWrite;

    START_TEST("23_VAR_Write_Calculated_OBD_Typ",
               "created to solve true case of NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, &l_NvM_Result) == 0 at line number 354 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("NvM_GetErrorStatus#2;NvM_WriteBlock#1");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 10U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_24************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
            Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case C_InitWrite of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - check true (NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, at address of l_NvM_Result) equal E_OK) condition
                - check true (l_NvM_Result diff NVM_REQ_PENDING)
                - check true (NvM_WriteBlock(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, Data) equal E_OK)
                - NVM_Calculated_OBD_Typ_WriteTransactionStatus_N is set to C_ProcessingWrite
                - Return dataRetVal_u8
---- Preconditions:
----			- NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_InitWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to NULL
----        Expected result:
----			- returnValue  is set to 10U
----			- expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ProcessingWrite
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_24(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ = 0U;
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_InitWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ProcessingWrite;

    START_TEST("24_VAR_Write_Calculated_OBD_Typ",
               "created to solve true case of NvM_WriteBlock(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, Data) == 0 at line number 358 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("NvM_GetErrorStatus#2;NvM_WriteBlock#2");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 10U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_25************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
            Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case C_InitWrite of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - check true (NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, at address of l_NvM_Result) equal E_OK) condition
                - check false (l_NvM_Result diff NVM_REQ_PENDING)
                - Return dataRetVal_u8
---- Preconditions:
----			- NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_InitWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to NULL
----        Expected result:
----			- returnValue  is set to 10U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_25(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ = 0U;
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_InitWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("25_VAR_Write_Calculated_OBD_Typ",
               "created to solve false case of l_NvM_Result != 2 at line number 356 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("NvM_GetErrorStatus#3");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 10U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_26************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
            Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case C_ProcessingWrite of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - check false (NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, at address of l_NvM_Result) equal E_OK) condition
                - NVM_Calculated_OBD_Typ_WriteTransactionStatus_N is set to C_ErrorWrite
                - Return dataRetVal_u8
---- Preconditions:
----			- NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ProcessingWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to NULL
----        Expected result:
----			- returnValue  is set to 10U
----			- expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ErrorWrite
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_26(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ = 0U;
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ProcessingWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ErrorWrite;

    START_TEST("26_VAR_Write_Calculated_OBD_Typ",
               "created to solve false case of NVM_Calculated_OBD_Typ_WriteTransactionStatus_N == C_InitWrite at line number 352");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("NvM_GetErrorStatus#1");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 10U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_27************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
            Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case C_ProcessingWrite of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - check true (NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, at address of l_NvM_Result) equal E_OK) condition
                - Case default of switch (l_NvM_Result)
                - NVM_Calculated_OBD_Typ_WriteTransactionStatus_N is set to C_ErrorWrite
                - Return dataRetVal_u8
---- Preconditions:
----			- NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ProcessingWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to NULL
----        Expected result:
----			- returnValue  is set to 10U
----			- expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ErrorWrite
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_27(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ = 0U;
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ProcessingWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ErrorWrite;

    START_TEST("27_VAR_Write_Calculated_OBD_Typ",
               "created to solve true case of NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, &l_NvM_Result) == 0 at line number 382 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("NvM_GetErrorStatus#2");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 10U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_28************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
            Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case C_ProcessingWrite of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - check true (NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, at address of l_NvM_Result) equal E_OK) condition
                - Case NVM_REQ_PENDING of switch (l_NvM_Result)
                - Return dataRetVal_u8
---- Preconditions:
----			- NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ProcessingWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to NULL
----        Expected result:
----			- returnValue  is set to 10U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_28(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ = 0U;
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ProcessingWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("28_VAR_Write_Calculated_OBD_Typ",
               "created to solve true case of l_NvM_Result == 2 at line number 392");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("NvM_GetErrorStatus#3");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 10U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_29************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
            Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case C_ProcessingWrite of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - check true (NvM_GetErrorStatus(NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ, at address of l_NvM_Result) equal E_OK) condition
                - Case NVM_REQ_OK of switch (l_NvM_Result)
                - NVM_Calculated_OBD_Typ_WriteTransactionStatus_N is set to C_DoneWrite
                - Return dataRetVal_u8
---- Preconditions:
----			- NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ  is set to 0U
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ProcessingWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to NULL
----        Expected result:
----			- returnValue  is set to 10U
----			- expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_DoneWrite
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_29(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NvMConf_NvMBlockDescriptor_Calculated_OBD_Typ = 0U;
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ProcessingWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_DoneWrite;

    START_TEST("29_VAR_Write_Calculated_OBD_Typ",
               "created to solve true case of l_NvM_Result == 0 at line number 386");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("NvM_GetErrorStatus#4");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 10U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_30************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
            Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case C_ProcessingWrite of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - NVM_Calculated_OBD_Typ_WriteTransactionStatus_N is set to C_InitWrite
                - dataRetVal_u8 is set to E_OK
                - Return dataRetVal_u8
---- Preconditions:
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_DoneWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to NULL
----        Expected result:
----			- returnValue  is set to 0U
----			- expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_InitWrite
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_30(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_DoneWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_InitWrite;

    START_TEST("30_VAR_Write_Calculated_OBD_Typ",
               "created to solve false case of NVM_Calculated_OBD_Typ_WriteTransactionStatus_N == C_ProcessingWrite at line number 380");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 0U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_31************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data, Dcm_NegativeResponseCodeType * dataNegRespCode_u8)
---- Test goal:
            Check
                - Declare l_NvM_Result with NvM_RequestResultType type
                - Declare dataRetVal_u8 with VAR(Std_ReturnType, AUTOMATIC) type
                - dataRetVal_u8 is set to DCM_E_PENDING
                - case default of switch (NVM_Calculated_OBD_Typ_WriteTransactionStatus_N)
                - NVM_Calculated_OBD_Typ_WriteTransactionStatus_N is set to C_InitWrite
                - Value of dataNegRespCode_u8 is set to DCM_E_CONDITIONSNOTCORRECT
                - dataRetVal_u8 is set to E_NOT_OK
                - Return dataRetVal_u8
---- Preconditions:
----			- NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_ErrorWrite
---- Test steps:
----        Input values:
----			- const OBDRequirements_N * Data  is set to NULL
----			- Dcm_NegativeResponseCodeType * dataNegRespCode_u8  is set to &map_dataNegRespCode_u8[0]
----        Expected result:
----			- returnValue  is set to 1U
----			- expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N  is set to C_InitWrite
----			- expected_map_dataNegRespCode_u8[0]  is set to 34U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_VAR_Write_Calculated_OBD_Typ_31(int doIt){
if (doIt) {
    /* Test case data declarations */
    const OBDRequirements_N * Data = NULL;
    Dcm_NegativeResponseCodeType * dataNegRespCode_u8 = &map_dataNegRespCode_u8[0];
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_ErrorWrite;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_NVM_Calculated_OBD_Typ_WriteTransactionStatus_N = C_InitWrite;
    expected_map_dataNegRespCode_u8[0] = 34U;

    START_TEST("31_VAR_Write_Calculated_OBD_Typ",
               "created to solve false case of NVM_Calculated_OBD_Typ_WriteTransactionStatus_N == C_DoneWrite at line number 411");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = VAR_Write_Calculated_OBD_Typ(Data, dataNegRespCode_u8);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 1U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_32************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType Calculated_OBD_Typ_ReadCallback(void * NvMBuffer)
---- Test goal:
			Check the code coverage for this function
			    -   rba_BswSrv_MemCopy(&g_Calculated_OBD_Typ_N, NvMBuffer, NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ) is called
			    -   return is E_OK
---- Preconditions:
----			- NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ  is set to 0U
----			- g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
---- Test steps:
----        Input values:
----			- void * NvMBuffer  is set to NULL
----        Expected result:
----			- returnValue  is set to 0U
----			- expected_g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_Calculated_OBD_Typ_ReadCallback_32(int doIt){
if (doIt) {
    /* Test case data declarations */
    void * NvMBuffer = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    NVM_CFG_NV_BLOCK_LENGTH_Calculated_OBD_Typ = 0U;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_g_Calculated_OBD_Typ_N = C_NoOBD_N;

    START_TEST("32_Calculated_OBD_Typ_ReadCallback",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("rba_BswSrv_MemCopy#1");

            /* Call SUT */
            returnValue = Calculated_OBD_Typ_ReadCallback(NvMBuffer);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 0U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_33************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType Calculated_OBD_Typ_WriteCallback(void * NvMBuffer)
---- Test goal:
			Check the code coverage for this function with return is E_OK
---- Preconditions:
---- Test steps:
----        Input values:
----			- void NvMBuffer  is set to NULL
----        Expected result:
----			- returnValue  is set to 0U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_Calculated_OBD_Typ_WriteCallback_33(int doIt){
if (doIt) {
    /* Test case data declarations */
    void * NvMBuffer = NULL;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("33_Calculated_OBD_Typ_WriteCallback",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = Calculated_OBD_Typ_WriteCallback(NvMBuffer);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 0U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_34************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType Calculated_OBD_Typ_ResultCallback(uint8_t NvM_Servide_ID, NvM_RequestResultType JobResult)
---- Test goal:
			Check:
			    -   Check false for (NvM_Servide_ID equal NVM_SERVICE_ID_READ_ALL) condition
			    -   return is E_NOT_OK
---- Preconditions:
---- Test steps:
----        Input values:
----			- uint8_t NvM_Servide_ID  is set to 85U
----			- NvM_RequestResultType JobResult  is set to 85U
----        Expected result:
----			- returnValue  is set to 1U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_Calculated_OBD_Typ_ResultCallback_34(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8_t NvM_Servide_ID = 85U;
    NvM_RequestResultType JobResult = 85U;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("34_Calculated_OBD_Typ_ResultCallback",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = Calculated_OBD_Typ_ResultCallback(NvM_Servide_ID, JobResult);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 1U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_35************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType Calculated_OBD_Typ_ResultCallback(uint8_t NvM_Servide_ID, NvM_RequestResultType JobResult)
---- Test goal:
            Check:
                -   Check true for (NvM_Servide_ID equal NVM_SERVICE_ID_READ_ALL) condition
                -   NVM_Calculated_OBD_Typ_ReadResult_N is set to JobResult
                -   Check false for (NVM_Calculated_OBD_Typ_ReadResult_N equal NVM_REQ_OK) condition
                -   Dem_ReportErrorStatus(DemConf_DemEventParameter_OBDSwitch_NvmReadError, DEM_EVENT_STATUS_FAILED) is called
                -   g_Calculated_OBD_Typ_N is set to C_USOBD_N
                -   RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                -   return is E_NOT_OK
---- Preconditions:
----			- DemConf_DemEventParameter_OBDSwitch_NvmReadError  is set to 0U
----			- DEM_EVENT_STATUS_FAILED  is set to 85U
---- Test steps:
----        Input values:
----			- uint8_t NvM_Servide_ID  is set to 12U
----			- NvM_RequestResultType JobResult  is set to 85U
----        Expected result:
----			- returnValue  is set to 1U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_g_Calculated_OBD_Typ_N  is set to C_USOBD_N
----			- expected_NVM_Calculated_OBD_Typ_ReadResult_N  is set to 85U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_Calculated_OBD_Typ_ResultCallback_35(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8_t NvM_Servide_ID = 12U;
    NvM_RequestResultType JobResult = 85U;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    DemConf_DemEventParameter_OBDSwitch_NvmReadError = 0U;
    DEM_EVENT_STATUS_FAILED = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_g_Calculated_OBD_Typ_N = C_USOBD_N;
    expected_NVM_Calculated_OBD_Typ_ReadResult_N = 85U;

    START_TEST("35_Calculated_OBD_Typ_ResultCallback",
               "created to solve true case of NvM_Servide_ID == 12U at line number 476 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_ReportErrorStatus#1");

            /* Call SUT */
            returnValue = Calculated_OBD_Typ_ResultCallback(NvM_Servide_ID, JobResult);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 1U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*
***TC_36************************************************************************************************
---- Test specification
---- Requirements verified:
----              Function Std_ReturnType Calculated_OBD_Typ_ResultCallback(uint8_t NvM_Servide_ID, NvM_RequestResultType JobResult)
---- Test goal:
            Check:
                -   Check true for (NvM_Servide_ID equal NVM_SERVICE_ID_READ_ALL) condition
                -   NVM_Calculated_OBD_Typ_ReadResult_N is set to JobResult
                -   Check true for (NVM_Calculated_OBD_Typ_ReadResult_N equal NVM_REQ_OK) condition
                -   Dem_ReportErrorStatus(DemConf_DemEventParameter_OBDSwitch_NvmReadError, DEM_EVENT_STATUS_PASSED) is called
                -   g_Previous_DCY_OBD_Typ_N is set to g_Calculated_OBD_Typ_N
                -   RBMESG_SendMESG(Calculated_OBD_Typ_N, g_Calculated_OBD_Typ_N) is called
                -   return is E_OK
---- Preconditions:
----			- DemConf_DemEventParameter_OBDSwitch_NvmReadError  is set to 0U
----			- DEM_EVENT_STATUS_PASSED  is set to 85U
----			- g_Calculated_OBD_Typ_N  is set to C_NoOBD_N
---- Test steps:
----        Input values:
----			- uint8_t NvM_Servide_ID  is set to 12U
----			- NvM_RequestResultType JobResult  is set to 0U
----        Expected result:
----			- returnValue  is set to 0U
----			- expected_RBMESG_Calculated_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_g_Previous_DCY_OBD_Typ_N  is set to C_NoOBD_N
----			- expected_NVM_Calculated_OBD_Typ_ReadResult_N  is set to 0U
---- Post conditions: none
---- Testing technique: Requirement based
----
----***************************************************************************************************
*/
void test_Calculated_OBD_Typ_ResultCallback_36(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8_t NvM_Servide_ID = 12U;
    NvM_RequestResultType JobResult = 0U;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    DemConf_DemEventParameter_OBDSwitch_NvmReadError = 0U;
    DEM_EVENT_STATUS_PASSED = 85U;
    g_Calculated_OBD_Typ_N = C_NoOBD_N;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_Calculated_OBD_Typ_N = C_NoOBD_N;
    expected_g_Previous_DCY_OBD_Typ_N = C_NoOBD_N;
    expected_NVM_Calculated_OBD_Typ_ReadResult_N = 0U;

    START_TEST("36_Calculated_OBD_Typ_ResultCallback",
               "created to solve true case of NVM_Calculated_OBD_Typ_ReadResult_N == 0 at line number 481 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_ReportErrorStatus#1");

            /* Call SUT */
            returnValue = Calculated_OBD_Typ_ResultCallback(NvM_Servide_ID, JobResult);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, 0U);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*****************************************************************************/
/* Call Interface Control                                                    */
/*****************************************************************************/

/* Stub for function Dem_GetComponentFailed */
Std_ReturnType Dem_GetComponentFailed(Dem_ComponentIdType ComponentId,
                                      boolean * ComponentFailed){
    REGISTER_CALL("Dem_GetComponentFailed");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }
    IF_INSTANCE("1") {
        Std_ReturnType returnValue;
        returnValue = 85U;
        *ComponentFailed = 85U;
        return returnValue;
    }
    IF_INSTANCE("2") {
        Std_ReturnType returnValue;
        returnValue = 85U;
        *ComponentFailed = 0U;
        return returnValue;
    }
    IF_INSTANCE("3") {
        Std_ReturnType returnValue;
        returnValue = 1U;
        *ComponentFailed = 85U;
        return returnValue;
    }
    IF_INSTANCE("4") {
        Std_ReturnType returnValue;
        returnValue = 85U;
        *ComponentFailed = 85U;
        return returnValue;
    }
    IF_INSTANCE("5") {
        Std_ReturnType returnValue;
        returnValue = 85U;
        *ComponentFailed = 0U;
        return returnValue;
    }
    IF_INSTANCE("6") {
        Std_ReturnType returnValue;
        returnValue = 85U;
        *ComponentFailed = 85U;
        return returnValue;
    }
    IF_INSTANCE("7") {
        Std_ReturnType returnValue;
        returnValue = 1U;
        *ComponentFailed = 85U;
        return returnValue;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Dem_ReportErrorStatus */
void Dem_ReportErrorStatus(Dem_EventIdType EventId,
                           Dem_EventStatusType EventStatus){
    REGISTER_CALL("Dem_ReportErrorStatus");

    IF_INSTANCE("default") {
        return;
    }
    IF_INSTANCE("1") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function NvM_GetErrorStatus */
Std_ReturnType NvM_GetErrorStatus(NvM_BlockIdType BlockId,
                                  NvM_RequestResultType * RequestResultPtr){
    REGISTER_CALL("NvM_GetErrorStatus");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }
    IF_INSTANCE("1") {
        Std_ReturnType returnValue;
        returnValue = 85U;
        *RequestResultPtr = 85U;
        return returnValue;
    }
    IF_INSTANCE("2") {
        Std_ReturnType returnValue;
        returnValue = 0U;
        *RequestResultPtr = 85U;
        return returnValue;
    }
    IF_INSTANCE("3") {
        Std_ReturnType returnValue;
        returnValue = 0U;
        *RequestResultPtr = 2U;
        return returnValue;
    }
    IF_INSTANCE("4") {
        Std_ReturnType returnValue;
        returnValue = 0U;
        *RequestResultPtr = 0U;
        return returnValue;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function NvM_WriteBlock */
Std_ReturnType NvM_WriteBlock(NvM_BlockIdType BlockId,
                              const void * NvM_SrcPtr){
    REGISTER_CALL("NvM_WriteBlock");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }
    IF_INSTANCE("1") {
        Std_ReturnType returnValue;
        returnValue = 85U;
        return returnValue;
    }
    IF_INSTANCE("2") {
        Std_ReturnType returnValue;
        returnValue = 0U;
        return returnValue;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function rba_BswSrv_MemCopy */
void * rba_BswSrv_MemCopy(void * xDest_pv,
                          const void * xSrc_pcv,
                          uint32 numBytes_u32){
    REGISTER_CALL("rba_BswSrv_MemCopy");

    IF_INSTANCE("default") {
        return 0;
    }
    IF_INSTANCE("1") {
        void * returnValue;
        returnValue = NULL;
        *((enum _OBDRequirements_N*) xDest_pv) = C_NoOBD_N;
        return returnValue;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return 0;
}

#pragma qas cantata ignore on

/* Before-Wrapper for function VAR_Write_Calculated_OBD_Typ */
int BEFORE_VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data,
                                        Dcm_NegativeResponseCodeType * dataNegRespCode_u8){
    REGISTER_CALL("VAR_Write_Calculated_OBD_Typ");

    IF_INSTANCE("default") {
        return AFTER_WRAPPER;
    }
    IF_INSTANCE("1") {
        return REPLACE_WRAPPER;
    }
    IF_INSTANCE("2") {
        return REPLACE_WRAPPER;
    }
    IF_INSTANCE("3") {
        return REPLACE_WRAPPER;
    }
    IF_INSTANCE("4") {
        return REPLACE_WRAPPER;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return AFTER_WRAPPER;
}

/* After-Wrapper for function VAR_Write_Calculated_OBD_Typ */
Std_ReturnType AFTER_VAR_Write_Calculated_OBD_Typ(Std_ReturnType cppsm_return_value,
                                                  const OBDRequirements_N * Data,
                                                  Dcm_NegativeResponseCodeType * dataNegRespCode_u8){
    IF_INSTANCE("default") {
        return cppsm_return_value;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return cppsm_return_value;
}

/* Replace-Wrapper for function VAR_Write_Calculated_OBD_Typ */
Std_ReturnType REPLACE_VAR_Write_Calculated_OBD_Typ(const OBDRequirements_N * Data,
                                                    Dcm_NegativeResponseCodeType * dataNegRespCode_u8){

    IF_INSTANCE("1") {
        Std_ReturnType returnValue;
        returnValue = 85U;
        *dataNegRespCode_u8 = 85U;
        return returnValue;
    }
    IF_INSTANCE("2") {
        Std_ReturnType returnValue;
        returnValue = 0U;
        *dataNegRespCode_u8 = 85U;
        return returnValue;
    }
    IF_INSTANCE("3") {
        Std_ReturnType returnValue;
        returnValue = 1U;
        *dataNegRespCode_u8 = 85U;
        return returnValue;
    }
    IF_INSTANCE("4") {
        Std_ReturnType returnValue;
        returnValue = 85U;
        *dataNegRespCode_u8 = 85U;
        return returnValue;
    }
    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

#pragma qas cantata ignore off
/* pragma qas cantata testscript end */
/*****************************************************************************/
/* End of test script                                                        */
/*****************************************************************************/

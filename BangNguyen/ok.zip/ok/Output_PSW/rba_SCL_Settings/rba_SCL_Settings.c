#include "rba_SCL_Settings.h"
#include "rba_SCL_Subsystem.h"
#include "ASWIF09_CommonConfig_IPB.h"

BOOL p_VariantHasEngine_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasEngine_B*/
/*MODEL_NAME=p_VariantHasEngine_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=Engine flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasFrontMotor_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasFrontMotor_B*/
/*MODEL_NAME=p_VariantHasFrontMotor_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=Front Motor flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasRearMotor_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasRearMotor_B*/
/*MODEL_NAME=p_VariantHasRearMotor_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=Rear Motor flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasAcc_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasAcc_B*/
/*MODEL_NAME=p_VariantHasAcc_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=ACC flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/
BOOL p_VariantHasAeb_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasAeb_B*/
/*MODEL_NAME=p_VariantHasAeb_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=AEB flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasAPA_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasAPA_B*/
/*MODEL_NAME=p_VariantHasAPA_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=ACC flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasTpms_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasTpms_B*/
/*MODEL_NAME=p_VariantHasTpms_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=TPMS function flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasATS_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasATS_B*/
/*MODEL_NAME=p_VariantHasATS_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=ATS function flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasHdc_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasHdc_B*/
/*MODEL_NAME=p_VariantHasHdc_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=HDC function flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasDST_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasDST_B*/
/*MODEL_NAME=p_VariantHasDST_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=DST function flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasAvh_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasAvh_B*/
/*MODEL_NAME=p_VariantHasAvh_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=AVH function flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasCDP_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasCDP_B*/
/*MODEL_NAME=p_VariantHasCDP_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=CDP function flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasBDW_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasBDW_B*/
/*MODEL_NAME=p_VariantHasBDW_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=BDW function flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasCST_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasCST_B*/
/*MODEL_NAME=p_VariantHasCST_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=CST function flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasDriverPresent_B = true;
BOOL p_VariantAvhButtonViaCan = false;
BOOL p_VariantEspOffButtonViaCan = true;

BOOL p_VariantHasAwb_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasAwb_B*/
/*MODEL_NAME=p_VariantHasAwb_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=AWB flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasAba_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasAba_B*/
/*MODEL_NAME=p_VariantHasAba_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=ABA flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasAbp_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasAbp_B*/
/*MODEL_NAME=p_VariantHasAbp_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=ABP flag */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasAmbTemp_B = true;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasAmbTemp_B*/
/*MODEL_NAME=p_VariantHasAmbTemp_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=Amb temperature */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasELRatio_B = false;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasELRatio_B*/
/*MODEL_NAME=p_VariantHasELRatio_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=EL Ration enable */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasSCEDRatio_B = false;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasSCEDRatio_B*/
/*MODEL_NAME=p_VariantHasSCEDRatio_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=SCED Ratio enable */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasDM40_B = false;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasDM40_B*/
/*MODEL_NAME=p_VariantHasDM40_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=EL Ration enable */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

BOOL p_VariantHasMbRegen_B = false;
/*[[MEASUREMENT*/
/*NAME=p_VariantHasMbRegen_B*/
/*MODEL_NAME=p_VariantHasMbRegen_B*/
/*DATA_TYPE=BOOL*/
/*COMMENT=EL Ration enable */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=1*/
/*MTEVENT=c_MT_Default_Task_x2*/
/*]]MEASUREMENT*/

void PRC_NET_SCL_Variant_V(void)
{

	Var_RBData_ST l_RBVarcode_ST;
	RcvMESG(l_RBVarcode_ST, NMSG_VarRBData_ST);

#if (RBFS_DriveMode == RBFS_DriveMode_4WD)
  {
	p_VariantHasDM40_B = false; //4WD, don't have DM4.0 projects

	/********************************************************************************************/
	/*Power: Engine + FM + RM*/
	if(((l_RBVarcode_ST.RBVarCode_UB >= 1) && (l_RBVarcode_ST.RBVarCode_UB <= 6))\
		|| (l_RBVarcode_ST.RBVarCode_UB == 15)\
		|| ((l_RBVarcode_ST.RBVarCode_UB >= 19) && (l_RBVarcode_ST.RBVarCode_UB <= 21))\
		)  // ST: AWD variant: 1~6, 15,19~21
	{
		p_VariantHasEngine_B = true;
		p_VariantHasFrontMotor_B = true;
		p_VariantHasRearMotor_B = true;

	}
	/*Power: Engine + RM*/
	else if(((l_RBVarcode_ST.RBVarCode_UB >= 7) && (l_RBVarcode_ST.RBVarCode_UB <= 10))\
			|| ((l_RBVarcode_ST.RBVarCode_UB >= 16) && (l_RBVarcode_ST.RBVarCode_UB <= 17))\
			|| ((l_RBVarcode_ST.RBVarCode_UB >= 22) && (l_RBVarcode_ST.RBVarCode_UB <= 23))\
			|| ((l_RBVarcode_ST.RBVarCode_UB == 32))\
			)//ST: simple AWD variant: 7~10, 16~17, 22~23,32
	{
		p_VariantHasEngine_B = true;
		p_VariantHasFrontMotor_B = false;
		p_VariantHasRearMotor_B = true;
	}
	/*Power: FM + RM*/
	else if(((l_RBVarcode_ST.RBVarCode_UB >= 11) && (l_RBVarcode_ST.RBVarCode_UB <= 14))\
			|| (l_RBVarcode_ST.RBVarCode_UB == 18)\
			|| ((l_RBVarcode_ST.RBVarCode_UB >= 24) && (l_RBVarcode_ST.RBVarCode_UB <= 31))\
			) //STE: AWD variant: 11~14, 18, 24~31
	{
		p_VariantHasEngine_B = false;
		p_VariantHasFrontMotor_B = true;
		p_VariantHasRearMotor_B = true;

	}
	else
	{
		p_VariantHasEngine_B = false;
		p_VariantHasFrontMotor_B = false;
		p_VariantHasRearMotor_B = false;
	}
	/********************************************************************************************/

	/*****************************************ACC/AEB********************************************/
	/*4WD ACC/AEB function variants: 1~4/7~8/11~20/22/24~32*/
	if(((l_RBVarcode_ST.RBVarCode_UB >= 1) && (l_RBVarcode_ST.RBVarCode_UB <= 4))\
			||((l_RBVarcode_ST.RBVarCode_UB >= 7) && (l_RBVarcode_ST.RBVarCode_UB <= 8))\
			||((l_RBVarcode_ST.RBVarCode_UB >= 11) && (l_RBVarcode_ST.RBVarCode_UB <= 20))\
			||(l_RBVarcode_ST.RBVarCode_UB == 22)\
			||((l_RBVarcode_ST.RBVarCode_UB >= 24) && (l_RBVarcode_ST.RBVarCode_UB <= 32))\
		)
	{
		p_VariantHasAcc_B = true;
		p_VariantHasAeb_B = true;
	}
	else
	{
		p_VariantHasAcc_B = false;
		p_VariantHasAeb_B = false;
	}
	/*****************************************ACC/AEB********************************************/

	/*****************************************APA***********************************************/
	/*4WD APA function variants: 15/17~23/28~32*/
	if((l_RBVarcode_ST.RBVarCode_UB == 15)\
			||((l_RBVarcode_ST.RBVarCode_UB >= 17) && (l_RBVarcode_ST.RBVarCode_UB <= 23))\
			||((l_RBVarcode_ST.RBVarCode_UB >= 28) && (l_RBVarcode_ST.RBVarCode_UB <= 32))
		)
	{
		p_VariantHasAPA_B = true;
	}
	else
	{
		p_VariantHasAPA_B = false;
	}
	/*****************************************APA***********************************************/

	/*****************************************TPMS**********************************************/
	p_VariantHasTpms_B = false;
	/*****************************************TPMS**********************************************/

	/*****************************************ATS***********************************************/
	/*4WD ATS function variants: 1~10/19~23/32*/
	if((l_RBVarcode_ST.RBVarCode_UB == 32)\
			||((l_RBVarcode_ST.RBVarCode_UB >= 1) && (l_RBVarcode_ST.RBVarCode_UB <= 10))\
			||((l_RBVarcode_ST.RBVarCode_UB >= 19) && (l_RBVarcode_ST.RBVarCode_UB <= 23))
		)
	{
		p_VariantHasATS_B = true;
	}
	else
	{
		p_VariantHasATS_B = false;
	}
	/*****************************************ATS***********************************************/


	/*****************************************HDC***********************************************/
	/*4WD NO HDC function variants: 15~18*/
	if((l_RBVarcode_ST.RBVarCode_UB >= 15) && (l_RBVarcode_ST.RBVarCode_UB <= 18))
	{
		p_VariantHasHdc_B = false;
	}
	else
	{
		p_VariantHasHdc_B = true;
	}
	/*****************************************HDC***********************************************/

	/*****************************************DST***********************************************/
	p_VariantHasDST_B = false;
	/*****************************************DST***********************************************/

	/*****************************************AVH***********************************************/
	p_VariantHasAvh_B = true;
	/*****************************************AVH***********************************************/

	/*****************************************CDP***********************************************/
	p_VariantHasCDP_B = true;
	/*****************************************CDP***********************************************/

	/*****************************************BDW***********************************************/
	p_VariantHasBDW_B = true;
	/*****************************************BDW***********************************************/

	/*****************************************CST***********************************************/
	p_VariantHasCST_B = true;
	/*****************************************CST***********************************************/

  }
#elif (RBFS_DriveMode == RBFS_DriveMode_2WD)  //STE: 2WD
	{
		p_VariantHasEngine_B = false;
		p_VariantHasFrontMotor_B = true;
		p_VariantHasRearMotor_B = false;
		p_VariantHasDM40_B = false;//DM4.0 project flag

		/*******************************************************************************************/
        /*2WD project, variant = 12~17/20~24/27 Powertrain: Engine+FM */
		if(((l_RBVarcode_ST.RBVarCode_UB >= 12) && (l_RBVarcode_ST.RBVarCode_UB <= 17))\
			|| ((l_RBVarcode_ST.RBVarCode_UB >= 20) && (l_RBVarcode_ST.RBVarCode_UB <= 24))\
			|| (l_RBVarcode_ST.RBVarCode_UB == 27)\
			|| ((l_RBVarcode_ST.RBVarCode_UB >= 45) && (l_RBVarcode_ST.RBVarCode_UB <= 46))\
			|| (l_RBVarcode_ST.RBVarCode_UB == 48)\
		  )
		{
			p_VariantHasEngine_B = true;  /*Engine*/
			p_VariantHasDM40_B = true;  /*DM4.0 project flag*/
		}
		else
		{
			p_VariantHasEngine_B = false;
			if((l_RBVarcode_ST.RBVarCode_UB == 39) || (l_RBVarcode_ST.RBVarCode_UB == 40))
			{
				p_VariantHasDM40_B = true;  /*DM4.0 project flag*/
			}
			else
			{
				p_VariantHasDM40_B = false;
			}
		}
		/******************************************************************************************/


		/*****************************************ACC/AEB********************************************/
		/*2WD project Variant = 4/5/8/11/12/15/16/18~20/23/25/28/29/33/37/38/40/41/42/48 no ACC function*/
		if((l_RBVarcode_ST.RBVarCode_UB == 4) || (l_RBVarcode_ST.RBVarCode_UB == 5)|| (l_RBVarcode_ST.RBVarCode_UB == 8)\
			|| (l_RBVarcode_ST.RBVarCode_UB == 11) || (l_RBVarcode_ST.RBVarCode_UB == 12)|| (l_RBVarcode_ST.RBVarCode_UB == 15)\
			|| (l_RBVarcode_ST.RBVarCode_UB == 16) || ((l_RBVarcode_ST.RBVarCode_UB >= 18) && (l_RBVarcode_ST.RBVarCode_UB <= 20))\
			|| (l_RBVarcode_ST.RBVarCode_UB == 23)|| (l_RBVarcode_ST.RBVarCode_UB == 25) || (l_RBVarcode_ST.RBVarCode_UB == 28)\
			|| (l_RBVarcode_ST.RBVarCode_UB == 29)|| (l_RBVarcode_ST.RBVarCode_UB == 33)|| (l_RBVarcode_ST.RBVarCode_UB == 37)\
			|| (l_RBVarcode_ST.RBVarCode_UB == 38)|| ((l_RBVarcode_ST.RBVarCode_UB >= 40) && (l_RBVarcode_ST.RBVarCode_UB <= 42))\
			|| (l_RBVarcode_ST.RBVarCode_UB == 48)\
		   )
		{
			p_VariantHasAcc_B = false;

			/*Variant = 29, no ACC function, but have AEB function*/
			if(l_RBVarcode_ST.RBVarCode_UB == 29)
			{
				p_VariantHasAeb_B = true;
			}
			else
			{
				p_VariantHasAeb_B = false;
			}
		}
		else
		{
			p_VariantHasAcc_B = true;
			p_VariantHasAeb_B = true;
		}
		/*****************************************ACC/AEB********************************************/

		/*****************************************APA***********************************************/
		/*2WD APA function variants: 7/9~10/13~14/30~33/45~46*/
		if((l_RBVarcode_ST.RBVarCode_UB == 7)\
				||((l_RBVarcode_ST.RBVarCode_UB >= 9) && (l_RBVarcode_ST.RBVarCode_UB <= 10))\
				||((l_RBVarcode_ST.RBVarCode_UB >= 13) && (l_RBVarcode_ST.RBVarCode_UB <= 14))\
				||((l_RBVarcode_ST.RBVarCode_UB >= 30) && (l_RBVarcode_ST.RBVarCode_UB <= 33))\
				||((l_RBVarcode_ST.RBVarCode_UB >= 45) && (l_RBVarcode_ST.RBVarCode_UB <= 46))\
			)
		{
			p_VariantHasAPA_B = true;
		}
		else
		{
			p_VariantHasAPA_B = false;
		}
		/*****************************************APA***********************************************/

		/*****************************************TPMS**********************************************/
        /*2WD project, variant = 11/18~21/23/25/27~29/38/42/47 have the TPMS function*/
		if((l_RBVarcode_ST.RBVarCode_UB == 11)\
			 || ((l_RBVarcode_ST.RBVarCode_UB >= 18) && (l_RBVarcode_ST.RBVarCode_UB <= 21))\
			 || (l_RBVarcode_ST.RBVarCode_UB == 23) || (l_RBVarcode_ST.RBVarCode_UB == 25)\
			 || ((l_RBVarcode_ST.RBVarCode_UB >= 27) && (l_RBVarcode_ST.RBVarCode_UB <= 29))\
			 || (l_RBVarcode_ST.RBVarCode_UB == 38)|| (l_RBVarcode_ST.RBVarCode_UB == 42)\
			 || (l_RBVarcode_ST.RBVarCode_UB == 47)\
		  )
		{
			p_VariantHasTpms_B = true;  /*TPMS function*/
		}
		else
		{
			p_VariantHasTpms_B = false;
		}
		/*****************************************TPMS**********************************************/

		/*****************************************ATS***********************************************/
		/*2WD ATS function variants: 39~40/45~46*/
		if(((l_RBVarcode_ST.RBVarCode_UB >= 39) && (l_RBVarcode_ST.RBVarCode_UB <= 40))\
			 || ((l_RBVarcode_ST.RBVarCode_UB >= 45)&& (l_RBVarcode_ST.RBVarCode_UB <= 46))\
		  )

		{
			p_VariantHasATS_B = true;
		}
		else
		{
			p_VariantHasATS_B = false;
		}
		/*****************************************ATS***********************************************/

		/*****************************************HDC***********************************************/
		/*2WD HDC function variants: 1~4/8~10/12~18/30~37/39~40/44~46*/
		if(((l_RBVarcode_ST.RBVarCode_UB >= 1) && (l_RBVarcode_ST.RBVarCode_UB <= 4))\
			  || ((l_RBVarcode_ST.RBVarCode_UB >= 8)&& (l_RBVarcode_ST.RBVarCode_UB <= 10))\
			  || ((l_RBVarcode_ST.RBVarCode_UB >= 12)&& (l_RBVarcode_ST.RBVarCode_UB <= 18))\
			  || ((l_RBVarcode_ST.RBVarCode_UB >= 30)&& (l_RBVarcode_ST.RBVarCode_UB <= 37))\
			  || ((l_RBVarcode_ST.RBVarCode_UB >= 39)&& (l_RBVarcode_ST.RBVarCode_UB <= 40))\
			  || ((l_RBVarcode_ST.RBVarCode_UB >= 44)&& (l_RBVarcode_ST.RBVarCode_UB <= 46))\
		   )
		{
			p_VariantHasHdc_B = true;
		}
		else
		{
			p_VariantHasHdc_B = false;
		}
		/*****************************************HDC***********************************************/

		/*****************************************DST***********************************************/
		/*2WD DST function variants: 11/19/47*/
		if((l_RBVarcode_ST.RBVarCode_UB == 11) || (l_RBVarcode_ST.RBVarCode_UB == 19) || (l_RBVarcode_ST.RBVarCode_UB == 47))

		{
			p_VariantHasDST_B = true;
		}
		else
		{
			p_VariantHasDST_B = false;
		}
		/*****************************************DST***********************************************/

		/*****************************************AVH***********************************************/
		/*2WD NO AVH function variants: 19/29/38*/
		if((l_RBVarcode_ST.RBVarCode_UB == 19) ||(l_RBVarcode_ST.RBVarCode_UB == 29) || (l_RBVarcode_ST.RBVarCode_UB == 38))
		{
			p_VariantHasAvh_B = false;
		}
		else
		{
			p_VariantHasAvh_B = true;
		}
		/*****************************************AVH***********************************************/

		/*****************************************CDP***********************************************/
		/*2WD NO CDP function variants: 19*/
		if(l_RBVarcode_ST.RBVarCode_UB == 19)
		{
			p_VariantHasCDP_B = false;
		}
		else
		{
			p_VariantHasCDP_B = true;
		}
		/*****************************************CDP***********************************************/

		/*****************************************BDW***********************************************/
		/*2WD NO BDW function variants: all 2WD variants have BDW function*/

		p_VariantHasBDW_B = true;

		/*****************************************BDW***********************************************/

		/*****************************************CST***********************************************/
		/*2WD NO CST function variants: 23/25/41/48*/
		if((l_RBVarcode_ST.RBVarCode_UB == 23) || (l_RBVarcode_ST.RBVarCode_UB == 25)\
			||(l_RBVarcode_ST.RBVarCode_UB == 41) || (l_RBVarcode_ST.RBVarCode_UB == 48)\
		  )
		{
			p_VariantHasCST_B = false;
		}
		else
		{
			p_VariantHasCST_B = true;
		}
		/*****************************************CST***********************************************/
	}
#endif
}

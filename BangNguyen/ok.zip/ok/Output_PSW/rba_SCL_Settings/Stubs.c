 /*
 **************************************************
 **     Project: rba_SCL_Settings
 ** Header File: Stubs.c
 **    Function: ./BYD_IPB_BL05_Int/BYDIPB/rb/as/BYD/ipb/app/net/RBScl/src/rba_SCL_Settings.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:44:38 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_C_
#define STUBS_C_

#include "include.h"








#endif /*  STUBS_C_  */

 /*
 **************************************************
 **     Project: rba_SCL_Settings
 ** Header File: rba_SCL_Subsystem.h
 **    Function: ./BYD_IPB_BL05_Int/BYDIPB/rb/as/BYD/ipb/app/net/RBScl/src/rba_SCL_Settings.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:44:28 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef RBA_SCL_SUBSYSTEM_H_
#define RBA_SCL_SUBSYSTEM_H_

#include "include.h"


#endif /*  RBA_SCL_SUBSYSTEM_H_  */

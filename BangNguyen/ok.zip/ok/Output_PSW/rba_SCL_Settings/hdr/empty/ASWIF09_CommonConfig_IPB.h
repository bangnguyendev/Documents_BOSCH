 /*
 **************************************************
 **     Project: rba_SCL_Settings
 ** Header File: ASWIF09_CommonConfig_IPB.h
 **    Function: ./BYD_IPB_BL05_Int/BYDIPB/rb/as/BYD/ipb/app/net/RBScl/src/rba_SCL_Settings.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:44:30 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef ASWIF09_COMONCONFIG_IPB_H_
#define ASWIF09_COMONCONFIG_IPB_H_

#include "include.h"


#endif /*  ASWIF09_COMONCONFIG_IPB_H_  */

/*****************************************************************************/
/*                            Cantata Test Script                            */
/*****************************************************************************/
/*
 *    Filename: atest_rba_SCL_Settings.c
 *    Author: nbg7hc
 *    Generated on: 26-May-2020 10:27:40
 *    Generated from: rba_SCL_Settings.c
 */
/*****************************************************************************/
/* Environment Definition                                                    */
/*****************************************************************************/

#define TEST_SCRIPT_GENERATOR 2

/* Include files from software under test */
#include "rba_SCL_Settings.h"
#include "rba_SCL_Subsystem.h"
#include "ASWIF09_CommonConfig_IPB.h"

#define CANTATA_DEFAULT_VALUE 0 /* Default value of variables & stub returns */

#include <cantpp.h>  /* Cantata Directives */
/* pragma qas cantata testscript start */
/*****************************************************************************/
/* Global Data Definitions                                                   */
/*****************************************************************************/

/* Global Functions */
extern void PRC_NET_SCL_Variant_V();

/* Global data */
extern volatile MESGType_NMSG_VarRBData_ST MESG_NMSG_VarRBData_ST;
extern BOOL p_VariantHasDM40_B;
extern BOOL p_VariantHasEngine_B;
extern BOOL p_VariantHasFrontMotor_B;
extern BOOL p_VariantHasRearMotor_B;
extern BOOL p_VariantHasAcc_B;
extern BOOL p_VariantHasAeb_B;
extern BOOL p_VariantHasAPA_B;
extern BOOL p_VariantHasTpms_B;
extern BOOL p_VariantHasATS_B;
extern BOOL p_VariantHasHdc_B;
extern BOOL p_VariantHasDST_B;
extern BOOL p_VariantHasAvh_B;
extern BOOL p_VariantHasCDP_B;
extern BOOL p_VariantHasBDW_B;
extern BOOL p_VariantHasCST_B;

/* Expected variables for global data */
MESGType_NMSG_VarRBData_ST expected_MESG_NMSG_VarRBData_ST;
BOOL expected_p_VariantHasDM40_B;
BOOL expected_p_VariantHasEngine_B;
BOOL expected_p_VariantHasFrontMotor_B;
BOOL expected_p_VariantHasRearMotor_B;
BOOL expected_p_VariantHasAcc_B;
BOOL expected_p_VariantHasAeb_B;
BOOL expected_p_VariantHasAPA_B;
BOOL expected_p_VariantHasTpms_B;
BOOL expected_p_VariantHasATS_B;
BOOL expected_p_VariantHasHdc_B;
BOOL expected_p_VariantHasDST_B;
BOOL expected_p_VariantHasAvh_B;
BOOL expected_p_VariantHasCDP_B;
BOOL expected_p_VariantHasBDW_B;
BOOL expected_p_VariantHasCST_B;

/* This function initialises global data to default values. This function       */
/* is called by every test case so must not contain test case specific settings */
static void initialise_global_data(){
    INITIALISE(MESG_NMSG_VarRBData_ST);
    INITIALISE(p_VariantHasDM40_B);
    INITIALISE(p_VariantHasEngine_B);
    INITIALISE(p_VariantHasFrontMotor_B);
    INITIALISE(p_VariantHasRearMotor_B);
    INITIALISE(p_VariantHasAcc_B);
    INITIALISE(p_VariantHasAeb_B);
    INITIALISE(p_VariantHasAPA_B);
    INITIALISE(p_VariantHasTpms_B);
    INITIALISE(p_VariantHasATS_B);
    INITIALISE(p_VariantHasHdc_B);
    INITIALISE(p_VariantHasDST_B);
    INITIALISE(p_VariantHasAvh_B);
    INITIALISE(p_VariantHasCDP_B);
    INITIALISE(p_VariantHasBDW_B);
    INITIALISE(p_VariantHasCST_B);
}

/* This function copies the global data settings into expected variables for */
/* use in check_global_data(). It is called by every test case so must not   */
/* contain test case specific settings.                                      */
static void initialise_expected_global_data(){
    COPY_TO_EXPECTED(MESG_NMSG_VarRBData_ST, expected_MESG_NMSG_VarRBData_ST);
    COPY_TO_EXPECTED(p_VariantHasDM40_B, expected_p_VariantHasDM40_B);
    COPY_TO_EXPECTED(p_VariantHasEngine_B, expected_p_VariantHasEngine_B);
    COPY_TO_EXPECTED(p_VariantHasFrontMotor_B, expected_p_VariantHasFrontMotor_B);
    COPY_TO_EXPECTED(p_VariantHasRearMotor_B, expected_p_VariantHasRearMotor_B);
    COPY_TO_EXPECTED(p_VariantHasAcc_B, expected_p_VariantHasAcc_B);
    COPY_TO_EXPECTED(p_VariantHasAeb_B, expected_p_VariantHasAeb_B);
    COPY_TO_EXPECTED(p_VariantHasAPA_B, expected_p_VariantHasAPA_B);
    COPY_TO_EXPECTED(p_VariantHasTpms_B, expected_p_VariantHasTpms_B);
    COPY_TO_EXPECTED(p_VariantHasATS_B, expected_p_VariantHasATS_B);
    COPY_TO_EXPECTED(p_VariantHasHdc_B, expected_p_VariantHasHdc_B);
    COPY_TO_EXPECTED(p_VariantHasDST_B, expected_p_VariantHasDST_B);
    COPY_TO_EXPECTED(p_VariantHasAvh_B, expected_p_VariantHasAvh_B);
    COPY_TO_EXPECTED(p_VariantHasCDP_B, expected_p_VariantHasCDP_B);
    COPY_TO_EXPECTED(p_VariantHasBDW_B, expected_p_VariantHasBDW_B);
    COPY_TO_EXPECTED(p_VariantHasCST_B, expected_p_VariantHasCST_B);
}

/* This function checks global data against the expected values. */
static void check_global_data(){
    CHECK_MEMORY("MESG_NMSG_VarRBData_ST", &MESG_NMSG_VarRBData_ST, &expected_MESG_NMSG_VarRBData_ST, sizeof(expected_MESG_NMSG_VarRBData_ST));
    CHECK_U_CHAR(p_VariantHasDM40_B, expected_p_VariantHasDM40_B);
    CHECK_U_CHAR(p_VariantHasEngine_B, expected_p_VariantHasEngine_B);
    CHECK_U_CHAR(p_VariantHasFrontMotor_B, expected_p_VariantHasFrontMotor_B);
    CHECK_U_CHAR(p_VariantHasRearMotor_B, expected_p_VariantHasRearMotor_B);
    CHECK_U_CHAR(p_VariantHasAcc_B, expected_p_VariantHasAcc_B);
    CHECK_U_CHAR(p_VariantHasAeb_B, expected_p_VariantHasAeb_B);
    CHECK_U_CHAR(p_VariantHasAPA_B, expected_p_VariantHasAPA_B);
    CHECK_U_CHAR(p_VariantHasTpms_B, expected_p_VariantHasTpms_B);
    CHECK_U_CHAR(p_VariantHasATS_B, expected_p_VariantHasATS_B);
    CHECK_U_CHAR(p_VariantHasHdc_B, expected_p_VariantHasHdc_B);
    CHECK_U_CHAR(p_VariantHasDST_B, expected_p_VariantHasDST_B);
    CHECK_U_CHAR(p_VariantHasAvh_B, expected_p_VariantHasAvh_B);
    CHECK_U_CHAR(p_VariantHasCDP_B, expected_p_VariantHasCDP_B);
    CHECK_U_CHAR(p_VariantHasBDW_B, expected_p_VariantHasBDW_B);
    CHECK_U_CHAR(p_VariantHasCST_B, expected_p_VariantHasCST_B);
}

/* Prototypes for test functions */
void run_tests();
void test_1(int);
void test_2(int);
void test_3(int);
void test_4(int);
void test_5(int);
void test_6(int);
void test_7(int);
void test_8(int);
void test_9(int);
void test_10(int);
void test_11(int);
void test_12(int);
void test_13(int);
void test_14(int);
void test_15(int);
void test_16(int);

/*****************************************************************************/
/* Coverage Analysis                                                         */
/*****************************************************************************/
/* Coverage Rule Set: Report all Metrics */
static void rule_set(char* cppca_sut,
                     char* cppca_context)
{
    START_TEST("COVERAGE RULE SET",
               "Report all Metrics");
#ifdef CANTPP_SUBSET_DEFERRED_ANALYSIS
    TEST_SCRIPT_WARNING("Coverage Rule Set ignored in deferred analysis mode\n");
#elif CANTPP_COVERAGE_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Coverage Instrumentation has been disabled\n");
#elif CANTPP_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Instrumentation has been disabled\n");
#else
    REPORT_COVERAGE(cppca_entrypoint_cov|
                    cppca_statement_cov|
                    cppca_basicblock_cov|
                    cppca_callreturn_cov|
                    cppca_decision_cov|
                    cppca_relational_cov|
                    cppca_loop_cov|
                    cppca_booloper_cov|
                    cppca_booleff_cov,
                    cppca_sut,
                    cppca_all_details|cppca_include_catch,
                    cppca_context);
#endif
    END_TEST();
}

/*****************************************************************************/
/* Program Entry Point                                                       */
/*****************************************************************************/
int main()
{
    CONFIGURE_COVERAGE("cov:boolcomb:yes");
    OPEN_LOG("atest_rba_SCL_Settings.ctr", false, 100);
    START_SCRIPT("rba_SCL_Settings", true);

    run_tests();

    return !END_SCRIPT(true);
}

/*****************************************************************************/
/* Test Control                                                              */
/*****************************************************************************/
/* run_tests() contains calls to the individual test cases, you can turn test*/
/* cases off by adding comments*/
void run_tests()
{
    test_1(1);
    test_2(1);
    test_3(1);
    test_4(1);
    test_5(1);
    test_6(1);
    test_7(1);
    test_8(1);
    test_9(1);
    test_10(1);
    test_11(1);
    test_12(1);
    test_13(1);
    test_14(1);
    test_15(1);
    test_16(1);

    rule_set("*", "*");
    EXPORT_COVERAGE("atest_rba_SCL_Settings.cov", cppca_export_replace);
}

/*****************************************************************************/
/* Test Cases                                                                */
/*****************************************************************************/

void test_1(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 0U;
    expected_p_VariantHasFrontMotor_B = 0U;
    expected_p_VariantHasRearMotor_B = 0U;
    expected_p_VariantHasAcc_B = 0U;
    expected_p_VariantHasAeb_B = 0U;
    expected_p_VariantHasAPA_B = 0U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 0U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("1: PRC_NET_SCL_Variant_V",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_2(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 24U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 0U;
    expected_p_VariantHasFrontMotor_B = 1U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 0U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 0U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("2: PRC_NET_SCL_Variant_V",
               "created to solve true case of l_RBVarcode_ST.RBVarCode_UB <= 31 at line number 308");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_3(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 28U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 0U;
    expected_p_VariantHasFrontMotor_B = 1U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 1U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 0U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("3: PRC_NET_SCL_Variant_V",
               "created to solve true case of l_RBVarcode_ST.RBVarCode_UB >= 28 at line number 347");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_4(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 32U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 0U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 1U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 1U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("4: PRC_NET_SCL_Variant_V",
               "created to solve true case of l_RBVarcode_ST.RBVarCode_UB == 32 at line number 298");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_5(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 22U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 0U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 1U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 1U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("5: PRC_NET_SCL_Variant_V",
               "created to solve true case of l_RBVarcode_ST.RBVarCode_UB <= 23 at line number 297");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_6(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 23U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 0U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 0U;
    expected_p_VariantHasAeb_B = 0U;
    expected_p_VariantHasAPA_B = 1U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 1U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("6: PRC_NET_SCL_Variant_V",
               "created to solve false case of l_RBVarcode_ST.RBVarCode_UB == 22 at line number 329");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_7(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 19U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 1U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 1U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 1U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("7: PRC_NET_SCL_Variant_V",
               "created to solve true case of l_RBVarcode_ST.RBVarCode_UB <= 21 at line number 286");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_8(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 7U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 0U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 0U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 1U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("8: PRC_NET_SCL_Variant_V",
               "created to solve false case of l_RBVarcode_ST.RBVarCode_UB >= 19 at line number 286");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_9(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 9U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 0U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 0U;
    expected_p_VariantHasAeb_B = 0U;
    expected_p_VariantHasAPA_B = 0U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 1U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("9: PRC_NET_SCL_Variant_V",
               "created to solve false case of l_RBVarcode_ST.RBVarCode_UB <= 8 at line number 327");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_10(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 11U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 0U;
    expected_p_VariantHasFrontMotor_B = 1U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 0U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 0U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("10: PRC_NET_SCL_Variant_V",
               "created to solve false case of l_RBVarcode_ST.RBVarCode_UB <= 10 at line number 295");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_11(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 16U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 0U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 0U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 0U;
    expected_p_VariantHasHdc_B = 0U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("11: PRC_NET_SCL_Variant_V",
               "created to solve true case of l_RBVarcode_ST.RBVarCode_UB >= 16 at line number 296");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_12(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 18U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 0U;
    expected_p_VariantHasFrontMotor_B = 1U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 1U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 0U;
    expected_p_VariantHasHdc_B = 0U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("12: PRC_NET_SCL_Variant_V",
               "created to solve false case of l_RBVarcode_ST.RBVarCode_UB <= 17 at line number 296");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_13(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 15U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 1U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 1U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 0U;
    expected_p_VariantHasHdc_B = 0U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("13: PRC_NET_SCL_Variant_V",
               "created to solve true case of l_RBVarcode_ST.RBVarCode_UB == 15 at line number 285");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_14(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 1U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 1U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 1U;
    expected_p_VariantHasAeb_B = 1U;
    expected_p_VariantHasAPA_B = 0U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 1U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("14: PRC_NET_SCL_Variant_V",
               "created to solve true case of l_RBVarcode_ST.RBVarCode_UB <= 6 at line number 284");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_15(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 5U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 1U;
    expected_p_VariantHasFrontMotor_B = 1U;
    expected_p_VariantHasRearMotor_B = 1U;
    expected_p_VariantHasAcc_B = 0U;
    expected_p_VariantHasAeb_B = 0U;
    expected_p_VariantHasAPA_B = 0U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 1U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("15: PRC_NET_SCL_Variant_V",
               "created to solve false case of l_RBVarcode_ST.RBVarCode_UB <= 4 at line number 326");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_16(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_VarRBData_ST.RBVarCode_UB = 0U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_p_VariantHasEngine_B = 0U;
    expected_p_VariantHasFrontMotor_B = 0U;
    expected_p_VariantHasRearMotor_B = 0U;
    expected_p_VariantHasAcc_B = 0U;
    expected_p_VariantHasAeb_B = 0U;
    expected_p_VariantHasAPA_B = 0U;
    expected_p_VariantHasTpms_B = 0U;
    expected_p_VariantHasATS_B = 0U;
    expected_p_VariantHasHdc_B = 1U;
    expected_p_VariantHasDST_B = 0U;
    expected_p_VariantHasAvh_B = 1U;
    expected_p_VariantHasCDP_B = 1U;
    expected_p_VariantHasBDW_B = 1U;
    expected_p_VariantHasCST_B = 1U;
    expected_p_VariantHasDM40_B = 0U;

    START_TEST("16: PRC_NET_SCL_Variant_V",
               "created to solve false case of l_RBVarcode_ST.RBVarCode_UB >= 1 at line number 284");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_SCL_Variant_V();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*****************************************************************************/
/* Call Interface Control                                                    */
/*****************************************************************************/

/* pragma qas cantata testscript end */
/*****************************************************************************/
/* End of test script                                                        */
/*****************************************************************************/

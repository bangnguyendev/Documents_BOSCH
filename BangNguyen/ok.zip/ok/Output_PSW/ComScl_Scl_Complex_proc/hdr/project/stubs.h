 /*
 **************************************************
 **     Project: ComScl_Scl_Complex_proc
 ** Header File: stubs.h
 **    Function: ./GWM_AB30_CP_Int/MainstreamF30/rb/as/gwm/cp/app/net/RBScl/src/ComScl_Scl_Complex_proc.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:43:07 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_H_
#define STUBS_H_

#include "include.h"


typedef enum
{
  RBAPBDynConfig_Unknown_N = 0,
  RBAPBDynConfig_APBNormal_N,
  RBAPBDynConfig_APBZero_N
} RBAPBDynConfig_N;

RBMESG_DefineMESGType_EN(RBAPB_Variant, RBAPBDynConfig_N);
RBMESG_DefineMESG(RBAPB_Variant);

BOOL APBZero_NET_Indicate;// for APB Zero

typedef struct _ABARequest_ST
{
  UBYTE Sensivity_UB;
  BOOL  Enable_B;
} ABARequest_ST;



typedef enum _ACMHPressureQualifier_N /*TOOL_SCAN*/
{
  C_ACMHPressureQualifier_NotInitialized_N = 0,
  C_ACMHPressureQualifier_Normal_N,
  C_ACMHPressureQualifier_Invalid_N
} ACMHPressureQualifier_N;

typedef struct _ACMHPressureExport_ST
{
  SWORD                   Pressure_SW;
  ACMHPressureQualifier_N Qualifier_N;
} ACMHPressureExport_ST;
typedef enum _BDWWiperState_N /*TOOL_SCAN*/
{
  C_BDWWiperState_NotInitialized_N = 0,
  C_BDWWiperState_NoWetnessInEnvironment_N,
  C_BDWWiperState_FrontWiperMotorRunning_N,
  C_BDWWiperState_WiperStroke_N,
  C_BDWWiperState_IntervalWiping_N,
  C_BDWWiperState_SlowWiping_N,
  C_BDWWiperState_FastWiping_N,
  C_BDWWiperState_TestTrigger_N
} BDWWiperState_N;
typedef enum _CruiseCtrlReq_N /*TOOL_SCAN*/
{
  C_CruiseCtrl_NoRequest_N = 0,
  C_CruiseCtrl_Increase_N,
  C_CruiseCtrl_IncreaseFast_N,
  C_CruiseCtrl_Decrease_N,
  C_CruiseCtrl_DecreaseFast_N,
  C_CruiseCtrl_Set_N,
  C_CruiseCtrl_Resume_N
} CruiseCtrlReq_N;
typedef enum _DrvUnitType_N /*TOOL_SCAN*/
{
  C_DrvUnitType_Undef_N = 0,
  C_DrvUnitType_Combustion_N,
  C_DrvUnitType_Combustion_wStartStop_N,
  C_DrvUnitType_Electric_N,
  C_DrvUnitType_Hybrid_noPureElectricDriving_N,
  C_DrvUnitType_Hybrid_wPureElectricDriving_N
} DrvUnitType_N;
typedef uint8 STMState;
typedef struct SystemStateCalculator SystemStateCalculator_t;
typedef struct
{
   boolean isActive;
#if(RBFS_DSWVariableStateLimitation == RBFS_DSWVariableStateLimitation_Yes)
   STMState stateLimit;
#endif
} StateLimiter_State;

typedef struct
{
   StateLimiter_State* state;
#if (RBFS_DSWSystemStateManagementVariantHandling == RBFS_DSWSystemStateManagementVariantHandling_Yes)
   const SystemStateCalculator_t** system;
#else
   const SystemStateCalculator_t* system;
#endif
#if(RBFS_DSWVariableStateLimitation == RBFS_DSWVariableStateLimitation_No)
   STMState stateLimit;
#endif
} StateLimiter;
StateLimiter allStateLimiter_HBB[2];
StateLimiter allStateLimiter_HBA[2];
#define STM_LIMITER_HBB_HBB_Off_ByEEPROM      (&allStateLimiter_HBB[0])
#define STM_LIMITER_HBB_HBB_Off_ByVarCode      (&allStateLimiter_HBB[1])
#define STM_LIMITER_HBA_HBA_Off_ByEEPROM      (&allStateLimiter_HBA[0])
#define STM_LIMITER_HBA_HBA_Off_ByVarCode      (&allStateLimiter_HBA[1])
typedef enum _GearboxType_N /*TOOL_SCAN*/
{
  C_GearboxType_Undefined_N = 0,
  C_GearboxType_Manual_N,
  C_GearboxType_Automat_N,
  C_GearboxType_CVTClutch_N,
  C_GearboxType_CVTConverter_N,
  C_GearboxType_ASGGearInfo_N,
  C_GearboxType_ASGNoGearInfo_N,
  C_GearboxType_TCTGearInfo_N,
  C_GearboxType_TCTNoGearInfo_N
} GearboxType_N;
#define DemConf_DemNode_YrsNet 143
#define DemConf_DemNode_AxsNet 144
#define DemConf_DemNode_AysNet 145
#define DemConf_DemNode_SasNet 134
typedef enum _VAM_SetVAMLTM_State_N /*TOOL_SCAN*/
{
  C_SetVAMLTM_Off_N = 0,
  C_SetVAMLTM_InProgress_N,
  C_SetVAMLTM_FailureEeprom_N,
  C_SetVAMLTM_FailureTimeOut_N,
  C_SetVAMLTM_Finished_N
} VAM_SetVAMLTM_State_N;
uint8 rba_ComScl_RawSignal_EngState_RX_u8;
#define DemConf_DemEnableCondition_NET_UVMonEnabled 5
#define DemConf_DemEnableCondition_PlausBlsMonEnabled 5
#define DemConf_DemEventParameter_Scl_EngineCranking_InvalidValue 5
#define GWM_CAN_ENGStateCRANKING                                       rba_ComScl_RawSignal_EngState_RX_u8
boolean GWM_ComScl_EvaluateRxPdu_EngState;
typedef uint8 Dem_EventStatusType;
#define DEM_EVENT_STATUS_PASSED             0
#define DEM_EVENT_STATUS_FAILED             1
#define DEM_EVENT_STATUS_PREPASSED          2
#define DEM_EVENT_STATUS_PREFAILED          3
#define DEM_EVENT_STATUS_FDC_THRESHOLD_REACHED          4
#define C_NetWheelCircumferenceQualifier_Normal_N 5
typedef uint8 Dem_RatioIdType;
typedef uint16 Dem_EventIdType;
typedef uint32 Dem_DebugDataType;
typedef uint8 Dem_EventStatusType;
typedef uint8 Dem_boolean_least;
typedef uint8 Dem_NodeIdType;

typedef struct _NetWheelCircumference_ST
{
  UWORD WheelCircumference_UW;
  ACMHPressureQualifier_N  Qualifier_N;
} NetWheelCircumference_ST;


extern Std_ReturnType RBScl_Complex_OBD_SignalCopy(void);
extern void PRC_NET_Scl_Rx_x4(void);
extern  void Dem_ReportErrorStatus( Dem_EventIdType EventId, Dem_EventStatusType EventStatus );
extern void PRC_NET_SCL_Rx_YRS_V(void);
extern void PRC_NET_Monitoring_CUSTOMER_CtrlCycx1_V(void);
extern Std_ReturnType Dem_SetEnableCondition (uint8 EnableConditionID, boolean ConditionFulfilled);
extern void Dem_NodeSetInitialized(Dem_NodeIdType NodeId, Dem_boolean_least init);
extern void StateLimiter__setActive (const StateLimiter* self, boolean isActive);


DefineMESGType_UL(NMSG_VAM_LifetimeDataCycles_UL);
DefineMESG(NMSG_VAM_LifetimeDataCycles_UL);
DefineMESGType_UL(NMSG_VAM_LifetimeDataRuntime_UL);
DefineMESG(NMSG_VAM_LifetimeDataRuntime_UL);
DefineMESGType_EN(NMSG_VAM_LifetimeSetState_N, VAM_SetVAMLTM_State_N);
DefineMESG(NMSG_VAM_LifetimeSetState_N);
DefineMESGType_B(NMSG_VAM_LifetimeSetDone_B);
DefineMESG(NMSG_VAM_LifetimeSetDone_B);
DefineMESGType_UL(NMSG_VAM_LifetimeSetDataRuntime_UL);
DefineMESG(NMSG_VAM_LifetimeSetDataRuntime_UL);
DefineMESGType_UL(NMSG_VAM_LifetimeSetDataCycles_UL);
DefineMESG(NMSG_VAM_LifetimeSetDataCycles_UL);
DefineMESGType_B(NMSG_VAM_LifetimeSetRequest_B);
DefineMESG(NMSG_VAM_LifetimeSetRequest_B);
DefineMESGType_EN(NMSG_GearboxType_RA_N, GearboxType_N);
DefineMESG(NMSG_GearboxType_RA_N);
DefineMESGType_EN(NMSG_GearboxType_FA_N, GearboxType_N);
DefineMESG(NMSG_GearboxType_FA_N);
DefineMESGType_EN(NMSG_GearboxType_N, GearboxType_N);
DefineMESG(NMSG_GearboxType_N);
DefineMESGType_B(NMSG_EMotor_Ready_RA_B);
DefineMESG(NMSG_EMotor_Ready_RA_B);
DefineMESGType_B(NMSG_EMotor_Ready_FA_B);
DefineMESG(NMSG_EMotor_Ready_FA_B);
DefineMESGType_EN(NMSG_DrvUnitType_RA_N, DrvUnitType_N);
DefineMESG(NMSG_DrvUnitType_RA_N);
DefineMESGType_EN(NMSG_DrvUnitType_FA_N, DrvUnitType_N);
DefineMESG(NMSG_DrvUnitType_FA_N);
DefineMESGType_EN(NMSG_CruiseCtrlReq_N, CruiseCtrlReq_N);
DefineMESG(NMSG_CruiseCtrlReq_N);
DefineMESGType_EN(NMSG_BdwWiperState_N, BDWWiperState_N);
DefineMESG(NMSG_BdwWiperState_N);
DefineMESGType_ST(NMSG_ABARequest_ST, ABARequest_ST);
DefineMESG(NMSG_ABARequest_ST);

DefineMESGType_B(NMSG_iB_HBV_requested_B);
DefineMESG(NMSG_iB_HBV_requested_B);


DefineMESGType_B(NMSG_iB_HBV_enabled_B);
DefineMESG(NMSG_iB_HBV_enabled_B);


DefineMESGType_B(MESG_OBD_MILLampOnReq_B);
DefineMESG(MESG_OBD_MILLampOnReq_B);
RBMESG_DefineMESGType_EN(RBMESG_RBAPBDynAPBConfig_N, RBAPBDynConfig_N);
RBMESG_DefineMESG(RBMESG_RBAPBDynAPBConfig_N);

DefineMESGType_ST(NMSG_NetWheelCircumference_ST, NetWheelCircumference_ST);
DefineMESG(NMSG_NetWheelCircumference_ST);

#endif /*  STUBS_H_  */

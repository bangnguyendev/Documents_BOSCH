 /*
 **************************************************
 **     Project: ComScl_Scl_Complex_proc
 ** Header File: rba_NET_Global_variable.h
 **    Function: ./GWM_AB30_CP_Int/MainstreamF30/rb/as/gwm/cp/app/net/RBScl/src/ComScl_Scl_Complex_proc.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:42:58 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef RBA_NET_GLOBAL_VARIABLE_H_
#define RBA_NET_GLOBAL_VARIABLE_H_

#include "include.h"


#endif /*  RBA_NET_GLOBAL_VARIABLE_H_  */

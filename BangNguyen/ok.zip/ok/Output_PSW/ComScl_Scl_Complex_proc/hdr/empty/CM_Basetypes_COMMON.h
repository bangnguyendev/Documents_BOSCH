 /*
 **************************************************
 **     Project: ComScl_Scl_Complex_proc
 ** Header File: CM_Basetypes_COMMON.h
 **    Function: ./GWM_AB30_CP_Int/MainstreamF30/rb/as/gwm/cp/app/net/RBScl/src/ComScl_Scl_Complex_proc.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:42:38 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef CM_BASETYPES_COMON_H_
#define CM_BASETYPES_COMON_H_

#include "include.h"


#endif /*  CM_BASETYPES_COMON_H_  */

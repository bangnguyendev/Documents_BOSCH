/*
 * CanIf.h
 *
 *  Created on: Apr 7, 2017
 *      Author: rkh1hc
 */

#ifndef HDR_EMPTY_CANIF_H_
#define HDR_EMPTY_CANIF_H_


#include "include.h"

#endif /* HDR_EMPTY_CANIF_H_ */

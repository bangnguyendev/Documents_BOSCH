 /*
 **************************************************
 **     Project: ComScl_Scl_Complex_proc
 ** Header File: RB_Prj_ConfigSettings.h
 **    Function: ./GWM_AB30_CP_Int/MainstreamF30/rb/as/gwm/cp/app/net/RBScl/src/ComScl_Scl_Complex_proc.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:42:52 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef RB_PRJ_CONFIGSETINGS_H_
#define RB_PRJ_CONFIGSETINGS_H_

#include "include.h"


#endif /*  RB_PRJ_CONFIGSETINGS_H_  */

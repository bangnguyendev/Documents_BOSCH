 /*
 **************************************************
 **     Project: ComScl_Scl_Complex_proc
 ** Header File: ComScl_Scl_Complex_proc.h
 **    Function: ./GWM_AB30_CP_Int/MainstreamF30/rb/as/gwm/cp/app/net/RBScl/src/ComScl_Scl_Complex_proc.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:42:48 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef COMSCL_SCL_COMPLEX_PROC_H_
#define COMSCL_SCL_COMPLEX_PROC_H_

#include "include.h"


#endif /*  COMSCL_SCL_COMPLEX_PROC_H_  */

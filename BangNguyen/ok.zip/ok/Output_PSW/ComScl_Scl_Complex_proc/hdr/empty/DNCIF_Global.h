 /*
 **************************************************
 **     Project: ComScl_Scl_Complex_proc
 ** Header File: DNCIF_Global.h
 **    Function: ./GWM_AB30_CP_Int/MainstreamF30/rb/as/gwm/cp/app/net/RBScl/src/ComScl_Scl_Complex_proc.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:42:32 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef DNCIF_GLOBAL_H_
#define DNCIF_GLOBAL_H_

#include "include.h"


#endif /*  DNCIF_GLOBAL_H_  */

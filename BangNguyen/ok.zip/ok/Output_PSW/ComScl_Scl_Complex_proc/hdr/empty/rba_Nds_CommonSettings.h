 /*
 **************************************************
 **     Project: ComScl_Scl_Complex_proc
 ** Header File: rba_Nds_CommonSettings.h
 **    Function: ./GWM_AB30_CP_Int/MainstreamF30/rb/as/gwm/cp/app/net/RBScl/src/ComScl_Scl_Complex_proc.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:42:45 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef RBA_NDS_COMONSETINGS_H_
#define RBA_NDS_COMONSETINGS_H_

#include "include.h"


#endif /*  RBA_NDS_COMONSETINGS_H_  */

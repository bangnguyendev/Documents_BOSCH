/*****************************************************************************/
/*                            Cantata Test Script                            */
/*****************************************************************************/
/*
 *    Filename: atest_ComScl_Scl_Complex_proc.c
 *    Author: nbg7hc
 *    Generated on: 26-May-2020 10:20:53
 *    Generated from: ComScl_Scl_Complex_proc.c
 */
/*****************************************************************************/
/* Environment Definition                                                    */
/*****************************************************************************/

#define TEST_SCRIPT_GENERATOR 2

/* Include files from software under test */
#include "DNCIF_Global.h"
#include "Std_Types.h"
#include "CM_Basetypes_COMMON.h"
#include "Dem.h"
#include "rba_Nds_CommonSettings.h"
#include "ComScl_Scl_Complex_proc.h"
#include "RB_Prj_ConfigSettings.h"
#include "RBHSWVAR_VarHandling.h"
#include "rba_NET_Global_variable.h"
#include "rba_SCL_Subsystem.h"
#include "SAS_Const.h"

#define CANTATA_DEFAULT_VALUE 0 /* Default value of variables & stub returns */

#include <cantpp.h>  /* Cantata Directives */
/* pragma qas cantata testscript start */
/*****************************************************************************/
/* Global Data Definitions                                                   */
/*****************************************************************************/

/* Global Functions */
void StateLimiter__setActive(const StateLimiter * self, boolean isActive);
void Dem_NodeSetInitialized(Dem_NodeIdType NodeId, Dem_boolean_least init);
Std_ReturnType Dem_SetEnableCondition(uint8 EnableConditionID, boolean ConditionFulfilled);
void PRC_NET_Monitoring_CUSTOMER_CtrlCycx1_V();
void PRC_NET_SCL_Rx_YRS_V();
void Dem_ReportErrorStatus(Dem_EventIdType EventId, Dem_EventStatusType EventStatus);
void PRC_NET_Scl_Rx_x4();
Std_ReturnType RBScl_Complex_OBD_SignalCopy();
extern void PRC_NET_Scl_Complex_Init();
extern void PRC_NET_Scl_Complex_Rx_x1();
extern void PRC_NET_Scl_Complex_Tx_x1();
extern void PRC_NET_Scl_Complex_Rx_x2();
extern void PRC_NET_Scl_FW_Rx_x2();
extern void PRC_NET_Scl_Complex_Tx_x2();
extern void PRC_NET_Scl_Complex_Rx_x4();
extern void PRC_NET_Scl_Complex_Tx_x4();

/* Global data */
extern volatile RBMESG_Type_RBMESG_RBAPBDynAPBConfig_N RBMESG_RBMESG_RBAPBDynAPBConfig_N;
extern BOOL APBZero_NET_Indicate;
extern volatile MESGType_NMSG_NetWheelCircumference_ST MESG_NMSG_NetWheelCircumference_ST;
extern volatile MESGType_NMSG_ABARequest_ST MESG_NMSG_ABARequest_ST;
extern volatile MESGType_NMSG_BdwWiperState_N MESG_NMSG_BdwWiperState_N;
extern volatile MESGType_NMSG_CruiseCtrlReq_N MESG_NMSG_CruiseCtrlReq_N;
extern volatile MESGType_NMSG_DrvUnitType_FA_N MESG_NMSG_DrvUnitType_FA_N;
extern volatile MESGType_NMSG_DrvUnitType_RA_N MESG_NMSG_DrvUnitType_RA_N;
extern volatile MESGType_NMSG_EMotor_Ready_FA_B MESG_NMSG_EMotor_Ready_FA_B;
extern volatile MESGType_NMSG_EMotor_Ready_RA_B MESG_NMSG_EMotor_Ready_RA_B;
extern volatile MESGType_MESG_OBD_MILLampOnReq_B MESG_MESG_OBD_MILLampOnReq_B;
extern volatile MESGType_NMSG_iB_HBV_enabled_B MESG_NMSG_iB_HBV_enabled_B;
extern volatile MESGType_NMSG_iB_HBV_requested_B MESG_NMSG_iB_HBV_requested_B;
extern StateLimiter allStateLimiter_HBB[2];
extern StateLimiter allStateLimiter_HBA[2];
extern volatile MESGType_NMSG_GearboxType_N MESG_NMSG_GearboxType_N;
extern volatile MESGType_NMSG_GearboxType_FA_N MESG_NMSG_GearboxType_FA_N;
extern volatile MESGType_NMSG_GearboxType_RA_N MESG_NMSG_GearboxType_RA_N;
extern volatile MESGType_NMSG_VAM_LifetimeSetRequest_B MESG_NMSG_VAM_LifetimeSetRequest_B;
extern volatile MESGType_NMSG_VAM_LifetimeSetDataRuntime_UL MESG_NMSG_VAM_LifetimeSetDataRuntime_UL;
extern volatile MESGType_NMSG_VAM_LifetimeSetDataCycles_UL MESG_NMSG_VAM_LifetimeSetDataCycles_UL;
extern volatile MESGType_NMSG_VAM_LifetimeSetDone_B MESG_NMSG_VAM_LifetimeSetDone_B;
extern volatile MESGType_NMSG_VAM_LifetimeSetState_N MESG_NMSG_VAM_LifetimeSetState_N;
extern volatile MESGType_NMSG_VAM_LifetimeDataRuntime_UL MESG_NMSG_VAM_LifetimeDataRuntime_UL;
extern volatile MESGType_NMSG_VAM_LifetimeDataCycles_UL MESG_NMSG_VAM_LifetimeDataCycles_UL;
extern boolean GWM_ComScl_EvaluateRxPdu_EngState;

/* Expected variables for global data */
RBMESG_Type_RBMESG_RBAPBDynAPBConfig_N expected_RBMESG_RBMESG_RBAPBDynAPBConfig_N;
BOOL expected_APBZero_NET_Indicate;
MESGType_NMSG_NetWheelCircumference_ST expected_MESG_NMSG_NetWheelCircumference_ST;
MESGType_NMSG_ABARequest_ST expected_MESG_NMSG_ABARequest_ST;
MESGType_NMSG_BdwWiperState_N expected_MESG_NMSG_BdwWiperState_N;
MESGType_NMSG_CruiseCtrlReq_N expected_MESG_NMSG_CruiseCtrlReq_N;
MESGType_NMSG_DrvUnitType_FA_N expected_MESG_NMSG_DrvUnitType_FA_N;
MESGType_NMSG_DrvUnitType_RA_N expected_MESG_NMSG_DrvUnitType_RA_N;
MESGType_NMSG_EMotor_Ready_FA_B expected_MESG_NMSG_EMotor_Ready_FA_B;
MESGType_NMSG_EMotor_Ready_RA_B expected_MESG_NMSG_EMotor_Ready_RA_B;
MESGType_MESG_OBD_MILLampOnReq_B expected_MESG_MESG_OBD_MILLampOnReq_B;
MESGType_NMSG_iB_HBV_enabled_B expected_MESG_NMSG_iB_HBV_enabled_B;
MESGType_NMSG_iB_HBV_requested_B expected_MESG_NMSG_iB_HBV_requested_B;
StateLimiter expected_allStateLimiter_HBB[2];
StateLimiter expected_allStateLimiter_HBA[2];
MESGType_NMSG_GearboxType_N expected_MESG_NMSG_GearboxType_N;
MESGType_NMSG_GearboxType_FA_N expected_MESG_NMSG_GearboxType_FA_N;
MESGType_NMSG_GearboxType_RA_N expected_MESG_NMSG_GearboxType_RA_N;
MESGType_NMSG_VAM_LifetimeSetRequest_B expected_MESG_NMSG_VAM_LifetimeSetRequest_B;
MESGType_NMSG_VAM_LifetimeSetDataRuntime_UL expected_MESG_NMSG_VAM_LifetimeSetDataRuntime_UL;
MESGType_NMSG_VAM_LifetimeSetDataCycles_UL expected_MESG_NMSG_VAM_LifetimeSetDataCycles_UL;
MESGType_NMSG_VAM_LifetimeSetDone_B expected_MESG_NMSG_VAM_LifetimeSetDone_B;
MESGType_NMSG_VAM_LifetimeSetState_N expected_MESG_NMSG_VAM_LifetimeSetState_N;
MESGType_NMSG_VAM_LifetimeDataRuntime_UL expected_MESG_NMSG_VAM_LifetimeDataRuntime_UL;
MESGType_NMSG_VAM_LifetimeDataCycles_UL expected_MESG_NMSG_VAM_LifetimeDataCycles_UL;
boolean expected_GWM_ComScl_EvaluateRxPdu_EngState;

/* This function initialises global data to default values. This function       */
/* is called by every test case so must not contain test case specific settings */
static void initialise_global_data(){
    INITIALISE(RBMESG_RBMESG_RBAPBDynAPBConfig_N);
    INITIALISE(APBZero_NET_Indicate);
    INITIALISE(MESG_NMSG_NetWheelCircumference_ST);
    INITIALISE(MESG_NMSG_ABARequest_ST);
    INITIALISE(MESG_NMSG_BdwWiperState_N);
    INITIALISE(MESG_NMSG_CruiseCtrlReq_N);
    INITIALISE(MESG_NMSG_DrvUnitType_FA_N);
    INITIALISE(MESG_NMSG_DrvUnitType_RA_N);
    INITIALISE(MESG_NMSG_EMotor_Ready_FA_B);
    INITIALISE(MESG_NMSG_EMotor_Ready_RA_B);
    INITIALISE(MESG_MESG_OBD_MILLampOnReq_B);
    INITIALISE(MESG_NMSG_iB_HBV_enabled_B);
    INITIALISE(MESG_NMSG_iB_HBV_requested_B);
    INITIALISE(allStateLimiter_HBB);
    INITIALISE(allStateLimiter_HBA);
    INITIALISE(MESG_NMSG_GearboxType_N);
    INITIALISE(MESG_NMSG_GearboxType_FA_N);
    INITIALISE(MESG_NMSG_GearboxType_RA_N);
    INITIALISE(MESG_NMSG_VAM_LifetimeSetRequest_B);
    INITIALISE(MESG_NMSG_VAM_LifetimeSetDataRuntime_UL);
    INITIALISE(MESG_NMSG_VAM_LifetimeSetDataCycles_UL);
    INITIALISE(MESG_NMSG_VAM_LifetimeSetDone_B);
    INITIALISE(MESG_NMSG_VAM_LifetimeSetState_N);
    INITIALISE(MESG_NMSG_VAM_LifetimeDataRuntime_UL);
    INITIALISE(MESG_NMSG_VAM_LifetimeDataCycles_UL);
    INITIALISE(GWM_ComScl_EvaluateRxPdu_EngState);
}

/* This function copies the global data settings into expected variables for */
/* use in check_global_data(). It is called by every test case so must not   */
/* contain test case specific settings.                                      */
static void initialise_expected_global_data(){
    COPY_TO_EXPECTED(RBMESG_RBMESG_RBAPBDynAPBConfig_N, expected_RBMESG_RBMESG_RBAPBDynAPBConfig_N);
    COPY_TO_EXPECTED(APBZero_NET_Indicate, expected_APBZero_NET_Indicate);
    COPY_TO_EXPECTED(MESG_NMSG_NetWheelCircumference_ST, expected_MESG_NMSG_NetWheelCircumference_ST);
    COPY_TO_EXPECTED(MESG_NMSG_ABARequest_ST, expected_MESG_NMSG_ABARequest_ST);
    COPY_TO_EXPECTED(MESG_NMSG_BdwWiperState_N, expected_MESG_NMSG_BdwWiperState_N);
    COPY_TO_EXPECTED(MESG_NMSG_CruiseCtrlReq_N, expected_MESG_NMSG_CruiseCtrlReq_N);
    COPY_TO_EXPECTED(MESG_NMSG_DrvUnitType_FA_N, expected_MESG_NMSG_DrvUnitType_FA_N);
    COPY_TO_EXPECTED(MESG_NMSG_DrvUnitType_RA_N, expected_MESG_NMSG_DrvUnitType_RA_N);
    COPY_TO_EXPECTED(MESG_NMSG_EMotor_Ready_FA_B, expected_MESG_NMSG_EMotor_Ready_FA_B);
    COPY_TO_EXPECTED(MESG_NMSG_EMotor_Ready_RA_B, expected_MESG_NMSG_EMotor_Ready_RA_B);
    COPY_TO_EXPECTED(MESG_MESG_OBD_MILLampOnReq_B, expected_MESG_MESG_OBD_MILLampOnReq_B);
    COPY_TO_EXPECTED(MESG_NMSG_iB_HBV_enabled_B, expected_MESG_NMSG_iB_HBV_enabled_B);
    COPY_TO_EXPECTED(MESG_NMSG_iB_HBV_requested_B, expected_MESG_NMSG_iB_HBV_requested_B);
    COPY_TO_EXPECTED(allStateLimiter_HBB, expected_allStateLimiter_HBB);
    COPY_TO_EXPECTED(allStateLimiter_HBA, expected_allStateLimiter_HBA);
    COPY_TO_EXPECTED(MESG_NMSG_GearboxType_N, expected_MESG_NMSG_GearboxType_N);
    COPY_TO_EXPECTED(MESG_NMSG_GearboxType_FA_N, expected_MESG_NMSG_GearboxType_FA_N);
    COPY_TO_EXPECTED(MESG_NMSG_GearboxType_RA_N, expected_MESG_NMSG_GearboxType_RA_N);
    COPY_TO_EXPECTED(MESG_NMSG_VAM_LifetimeSetRequest_B, expected_MESG_NMSG_VAM_LifetimeSetRequest_B);
    COPY_TO_EXPECTED(MESG_NMSG_VAM_LifetimeSetDataRuntime_UL, expected_MESG_NMSG_VAM_LifetimeSetDataRuntime_UL);
    COPY_TO_EXPECTED(MESG_NMSG_VAM_LifetimeSetDataCycles_UL, expected_MESG_NMSG_VAM_LifetimeSetDataCycles_UL);
    COPY_TO_EXPECTED(MESG_NMSG_VAM_LifetimeSetDone_B, expected_MESG_NMSG_VAM_LifetimeSetDone_B);
    COPY_TO_EXPECTED(MESG_NMSG_VAM_LifetimeSetState_N, expected_MESG_NMSG_VAM_LifetimeSetState_N);
    COPY_TO_EXPECTED(MESG_NMSG_VAM_LifetimeDataRuntime_UL, expected_MESG_NMSG_VAM_LifetimeDataRuntime_UL);
    COPY_TO_EXPECTED(MESG_NMSG_VAM_LifetimeDataCycles_UL, expected_MESG_NMSG_VAM_LifetimeDataCycles_UL);
    COPY_TO_EXPECTED(GWM_ComScl_EvaluateRxPdu_EngState, expected_GWM_ComScl_EvaluateRxPdu_EngState);
}

/* This function checks global data against the expected values. */
static void check_global_data(){
    CHECK_U_INT(RBMESG_RBMESG_RBAPBDynAPBConfig_N, expected_RBMESG_RBMESG_RBAPBDynAPBConfig_N);
    CHECK_U_CHAR(APBZero_NET_Indicate, expected_APBZero_NET_Indicate);
    CHECK_MEMORY("MESG_NMSG_ABARequest_ST", &MESG_NMSG_ABARequest_ST, &expected_MESG_NMSG_ABARequest_ST, sizeof(expected_MESG_NMSG_ABARequest_ST));
    CHECK_U_INT(MESG_NMSG_BdwWiperState_N, expected_MESG_NMSG_BdwWiperState_N);
    CHECK_U_INT(MESG_NMSG_CruiseCtrlReq_N, expected_MESG_NMSG_CruiseCtrlReq_N);
    CHECK_U_INT(MESG_NMSG_DrvUnitType_FA_N, expected_MESG_NMSG_DrvUnitType_FA_N);
    CHECK_U_INT(MESG_NMSG_DrvUnitType_RA_N, expected_MESG_NMSG_DrvUnitType_RA_N);
    CHECK_U_CHAR(MESG_NMSG_EMotor_Ready_FA_B, expected_MESG_NMSG_EMotor_Ready_FA_B);
    CHECK_U_CHAR(MESG_NMSG_EMotor_Ready_RA_B, expected_MESG_NMSG_EMotor_Ready_RA_B);
    CHECK_U_CHAR(MESG_MESG_OBD_MILLampOnReq_B, expected_MESG_MESG_OBD_MILLampOnReq_B);
    CHECK_U_CHAR(MESG_NMSG_iB_HBV_enabled_B, expected_MESG_NMSG_iB_HBV_enabled_B);
    CHECK_U_CHAR(MESG_NMSG_iB_HBV_requested_B, expected_MESG_NMSG_iB_HBV_requested_B);
    CHECK_MEMORY("allStateLimiter_HBB", allStateLimiter_HBB, expected_allStateLimiter_HBB, sizeof(expected_allStateLimiter_HBB));
    CHECK_MEMORY("allStateLimiter_HBA", allStateLimiter_HBA, expected_allStateLimiter_HBA, sizeof(expected_allStateLimiter_HBA));
    CHECK_U_INT(MESG_NMSG_GearboxType_N, expected_MESG_NMSG_GearboxType_N);
    CHECK_U_INT(MESG_NMSG_GearboxType_FA_N, expected_MESG_NMSG_GearboxType_FA_N);
    CHECK_U_INT(MESG_NMSG_GearboxType_RA_N, expected_MESG_NMSG_GearboxType_RA_N);
    CHECK_U_CHAR(MESG_NMSG_VAM_LifetimeSetRequest_B, expected_MESG_NMSG_VAM_LifetimeSetRequest_B);
    CHECK_U_INT(MESG_NMSG_VAM_LifetimeSetDataRuntime_UL, expected_MESG_NMSG_VAM_LifetimeSetDataRuntime_UL);
    CHECK_U_INT(MESG_NMSG_VAM_LifetimeSetDataCycles_UL, expected_MESG_NMSG_VAM_LifetimeSetDataCycles_UL);
    CHECK_U_CHAR(MESG_NMSG_VAM_LifetimeSetDone_B, expected_MESG_NMSG_VAM_LifetimeSetDone_B);
    CHECK_U_INT(MESG_NMSG_VAM_LifetimeSetState_N, expected_MESG_NMSG_VAM_LifetimeSetState_N);
    CHECK_U_INT(MESG_NMSG_VAM_LifetimeDataRuntime_UL, expected_MESG_NMSG_VAM_LifetimeDataRuntime_UL);
    CHECK_U_INT(MESG_NMSG_VAM_LifetimeDataCycles_UL, expected_MESG_NMSG_VAM_LifetimeDataCycles_UL);
    CHECK_U_CHAR(GWM_ComScl_EvaluateRxPdu_EngState, expected_GWM_ComScl_EvaluateRxPdu_EngState);
}

/* Prototypes for test functions */
void run_tests();
void test_1(int);
void test_2(int);
void test_3(int);
void test_4(int);
void test_5(int);
void test_6(int);
void test_7(int);
void test_8(int);
void test_9(int);
void test_10(int);
void test_11(int);

/*****************************************************************************/
/* Coverage Analysis                                                         */
/*****************************************************************************/
/* Coverage Rule Set: Report all Metrics */
static void rule_set(char* cppca_sut,
                     char* cppca_context)
{
    START_TEST("COVERAGE RULE SET",
               "Report all Metrics");
#ifdef CANTPP_SUBSET_DEFERRED_ANALYSIS
    TEST_SCRIPT_WARNING("Coverage Rule Set ignored in deferred analysis mode\n");
#elif CANTPP_COVERAGE_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Coverage Instrumentation has been disabled\n");
#elif CANTPP_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Instrumentation has been disabled\n");
#else
    REPORT_COVERAGE(cppca_entrypoint_cov|
                    cppca_statement_cov|
                    cppca_basicblock_cov|
                    cppca_callreturn_cov|
                    cppca_decision_cov|
                    cppca_relational_cov|
                    cppca_loop_cov|
                    cppca_booloper_cov|
                    cppca_booleff_cov,
                    cppca_sut,
                    cppca_all_details|cppca_include_catch,
                    cppca_context);
#endif
    END_TEST();
}

/*****************************************************************************/
/* Program Entry Point                                                       */
/*****************************************************************************/
int main()
{
    CONFIGURE_COVERAGE("cov:boolcomb:yes");
    OPEN_LOG("atest_ComScl_Scl_Complex_proc.ctr", false, 100);
    START_SCRIPT("ComScl_Scl_Complex_proc", true);

    run_tests();

    return !END_SCRIPT(true);
}

/*****************************************************************************/
/* Test Control                                                              */
/*****************************************************************************/
/* run_tests() contains calls to the individual test cases, you can turn test*/
/* cases off by adding comments*/
void run_tests()
{
    test_1(1);
    test_2(1);
    test_3(1);
    test_4(1);
    test_5(1);
    test_6(1);
    test_7(1);
    test_8(1);
    test_9(1);
    test_10(1);
    test_11(1);

    rule_set("*", "*");
    EXPORT_COVERAGE("atest_ComScl_Scl_Complex_proc.cov", cppca_export_replace);
}

/*****************************************************************************/
/* Test Cases                                                                */
/*****************************************************************************/

void test_1(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    allStateLimiter_HBB[0].state = NULL;
    allStateLimiter_HBB[0].system = NULL;
    allStateLimiter_HBB[0].stateLimit = 85U;
    allStateLimiter_HBA[0].state = NULL;
    allStateLimiter_HBA[0].system = NULL;
    allStateLimiter_HBA[0].stateLimit = 85U;
    RBMESG_RBMESG_RBAPBDynAPBConfig_N = RBAPBDynConfig_Unknown_N;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_MESG_NMSG_VAM_LifetimeDataCycles_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeDataRuntime_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetState_N = C_SetVAMLTM_Off_N;
    expected_MESG_NMSG_VAM_LifetimeSetDone_B = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetDataRuntime_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetDataCycles_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetRequest_B = 0U;
    expected_MESG_NMSG_GearboxType_RA_N = C_GearboxType_Automat_N;
    expected_MESG_NMSG_GearboxType_FA_N = C_GearboxType_Automat_N;
    expected_MESG_NMSG_GearboxType_N = C_GearboxType_Automat_N;
    expected_MESG_NMSG_EMotor_Ready_RA_B = 1U;
    expected_MESG_NMSG_EMotor_Ready_FA_B = 1U;
    expected_MESG_NMSG_DrvUnitType_RA_N = C_DrvUnitType_Electric_N;
    expected_MESG_NMSG_DrvUnitType_FA_N = C_DrvUnitType_Electric_N;
    expected_MESG_NMSG_CruiseCtrlReq_N = C_CruiseCtrl_NoRequest_N;
    expected_MESG_NMSG_BdwWiperState_N = C_BDWWiperState_NotInitialized_N;
    expected_MESG_NMSG_ABARequest_ST.Sensivity_UB = 0U;
    expected_MESG_NMSG_ABARequest_ST.Enable_B = 0U;
    expected_MESG_NMSG_iB_HBV_requested_B = 0U;
    expected_MESG_NMSG_iB_HBV_enabled_B = 0U;
    expected_MESG_MESG_OBD_MILLampOnReq_B = 0U;
    expected_MESG_NMSG_NetWheelCircumference_ST.WheelCircumference_UW = 1958U;
    expected_MESG_NMSG_NetWheelCircumference_ST.Qualifier_N = 5 /* No matching enumerator found */;

    START_TEST("1: PRC_NET_Scl_Complex_Init",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("StateLimiter__setActive#1;StateLimiter__setActive#2;Dem_NodeSetInitialized#1;Dem_NodeSetInitialized#2;Dem_NodeSetInitialized#3;Dem_SetEnableCondition#1;Dem_SetEnableCondition#1;Dem_NodeSetInitialized#4;Dem_NodeSetInitialized#2;Dem_NodeSetInitialized#3;Dem_NodeSetInitialized#1");

            /* Call SUT */
            PRC_NET_Scl_Complex_Init();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_2(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    allStateLimiter_HBB[0].state = NULL;
    allStateLimiter_HBB[0].system = NULL;
    allStateLimiter_HBB[0].stateLimit = 85U;
    allStateLimiter_HBA[0].state = NULL;
    allStateLimiter_HBA[0].system = NULL;
    allStateLimiter_HBA[0].stateLimit = 85U;
    RBMESG_RBMESG_RBAPBDynAPBConfig_N = RBAPBDynConfig_APBZero_N;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_APBZero_NET_Indicate = 1U;
    expected_MESG_NMSG_VAM_LifetimeDataCycles_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeDataRuntime_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetState_N = C_SetVAMLTM_Off_N;
    expected_MESG_NMSG_VAM_LifetimeSetDone_B = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetDataRuntime_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetDataCycles_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetRequest_B = 0U;
    expected_MESG_NMSG_GearboxType_RA_N = C_GearboxType_Automat_N;
    expected_MESG_NMSG_GearboxType_FA_N = C_GearboxType_Automat_N;
    expected_MESG_NMSG_GearboxType_N = C_GearboxType_Automat_N;
    expected_MESG_NMSG_EMotor_Ready_RA_B = 1U;
    expected_MESG_NMSG_EMotor_Ready_FA_B = 1U;
    expected_MESG_NMSG_DrvUnitType_RA_N = C_DrvUnitType_Electric_N;
    expected_MESG_NMSG_DrvUnitType_FA_N = C_DrvUnitType_Electric_N;
    expected_MESG_NMSG_CruiseCtrlReq_N = C_CruiseCtrl_NoRequest_N;
    expected_MESG_NMSG_BdwWiperState_N = C_BDWWiperState_NotInitialized_N;
    expected_MESG_NMSG_ABARequest_ST.Sensivity_UB = 0U;
    expected_MESG_NMSG_ABARequest_ST.Enable_B = 0U;
    expected_MESG_NMSG_iB_HBV_requested_B = 0U;
    expected_MESG_NMSG_iB_HBV_enabled_B = 0U;
    expected_MESG_MESG_OBD_MILLampOnReq_B = 0U;
    expected_MESG_NMSG_NetWheelCircumference_ST.WheelCircumference_UW = 1958U;
    expected_MESG_NMSG_NetWheelCircumference_ST.Qualifier_N = 5 /* No matching enumerator found */;

    START_TEST("2: PRC_NET_Scl_Complex_Init",
               "created to solve true case of RBAPBDynConfig_APBZero_N == l_RBMESG_RBAPBDynAPBConfig_N at line number 25 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("StateLimiter__setActive#1;StateLimiter__setActive#2;Dem_NodeSetInitialized#1;Dem_NodeSetInitialized#2;Dem_NodeSetInitialized#3;Dem_SetEnableCondition#1;Dem_SetEnableCondition#1;Dem_NodeSetInitialized#4;Dem_NodeSetInitialized#2;Dem_NodeSetInitialized#3;Dem_NodeSetInitialized#1");

            /* Call SUT */
            PRC_NET_Scl_Complex_Init();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_3(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    allStateLimiter_HBB[0].state = NULL;
    allStateLimiter_HBB[0].system = NULL;
    allStateLimiter_HBB[0].stateLimit = 85U;
    allStateLimiter_HBA[0].state = NULL;
    allStateLimiter_HBA[0].system = NULL;
    allStateLimiter_HBA[0].stateLimit = 85U;
    RBMESG_RBMESG_RBAPBDynAPBConfig_N = RBAPBDynConfig_APBNormal_N;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_APBZero_NET_Indicate = 0U;
    expected_MESG_NMSG_VAM_LifetimeDataCycles_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeDataRuntime_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetState_N = C_SetVAMLTM_Off_N;
    expected_MESG_NMSG_VAM_LifetimeSetDone_B = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetDataRuntime_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetDataCycles_UL = 0U;
    expected_MESG_NMSG_VAM_LifetimeSetRequest_B = 0U;
    expected_MESG_NMSG_GearboxType_RA_N = C_GearboxType_Automat_N;
    expected_MESG_NMSG_GearboxType_FA_N = C_GearboxType_Automat_N;
    expected_MESG_NMSG_GearboxType_N = C_GearboxType_Automat_N;
    expected_MESG_NMSG_EMotor_Ready_RA_B = 1U;
    expected_MESG_NMSG_EMotor_Ready_FA_B = 1U;
    expected_MESG_NMSG_DrvUnitType_RA_N = C_DrvUnitType_Electric_N;
    expected_MESG_NMSG_DrvUnitType_FA_N = C_DrvUnitType_Electric_N;
    expected_MESG_NMSG_CruiseCtrlReq_N = C_CruiseCtrl_NoRequest_N;
    expected_MESG_NMSG_BdwWiperState_N = C_BDWWiperState_NotInitialized_N;
    expected_MESG_NMSG_ABARequest_ST.Sensivity_UB = 0U;
    expected_MESG_NMSG_ABARequest_ST.Enable_B = 0U;
    expected_MESG_NMSG_iB_HBV_requested_B = 0U;
    expected_MESG_NMSG_iB_HBV_enabled_B = 0U;
    expected_MESG_MESG_OBD_MILLampOnReq_B = 0U;
    expected_MESG_NMSG_NetWheelCircumference_ST.WheelCircumference_UW = 1958U;
    expected_MESG_NMSG_NetWheelCircumference_ST.Qualifier_N = 5 /* No matching enumerator found */;

    START_TEST("3: PRC_NET_Scl_Complex_Init",
               "created to solve true case of RBAPBDynConfig_APBNormal_N == l_RBMESG_RBAPBDynAPBConfig_N at line number 21 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("StateLimiter__setActive#1;StateLimiter__setActive#2;Dem_NodeSetInitialized#1;Dem_NodeSetInitialized#2;Dem_NodeSetInitialized#3;Dem_SetEnableCondition#1;Dem_SetEnableCondition#1;Dem_NodeSetInitialized#4;Dem_NodeSetInitialized#2;Dem_NodeSetInitialized#3;Dem_NodeSetInitialized#1");

            /* Call SUT */
            PRC_NET_Scl_Complex_Init();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_4(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("4: PRC_NET_Scl_Complex_Rx_x1",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_Scl_Complex_Rx_x1();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_5(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("5: PRC_NET_Scl_Complex_Tx_x1",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("PRC_NET_Monitoring_CUSTOMER_CtrlCycx1_V#1");

            /* Call SUT */
            PRC_NET_Scl_Complex_Tx_x1();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_6(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("6: PRC_NET_Scl_Complex_Rx_x2",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("PRC_NET_SCL_Rx_YRS_V#1");

            /* Call SUT */
            PRC_NET_Scl_Complex_Rx_x2();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_7(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    GWM_ComScl_EvaluateRxPdu_EngState = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("7: PRC_NET_Scl_FW_Rx_x2",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_ReportErrorStatus#1");

            /* Call SUT */
            PRC_NET_Scl_FW_Rx_x2();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_8(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    GWM_ComScl_EvaluateRxPdu_EngState = 0U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("8: PRC_NET_Scl_FW_Rx_x2",
               "created to solve false case of GWM_ComScl_EvaluateRxPdu_EngState at line number 145 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Dem_ReportErrorStatus#2");

            /* Call SUT */
            PRC_NET_Scl_FW_Rx_x2();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_9(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("9: PRC_NET_Scl_Complex_Tx_x2",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_Scl_Complex_Tx_x2();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_10(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("10: PRC_NET_Scl_Complex_Rx_x4",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("PRC_NET_Scl_Rx_x4#1;RBScl_Complex_OBD_SignalCopy#1");

            /* Call SUT */
            PRC_NET_Scl_Complex_Rx_x4();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_11(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("11: PRC_NET_Scl_Complex_Tx_x4",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_NET_Scl_Complex_Tx_x4();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*****************************************************************************/
/* Call Interface Control                                                    */
/*****************************************************************************/

/* Stub for function StateLimiter__setActive */
void StateLimiter__setActive(const StateLimiter * self,
                             boolean isActive){
    REGISTER_CALL("StateLimiter__setActive");

    IF_INSTANCE("1") {
        CHECK_ADDRESS(self, &allStateLimiter_HBB[0]);
        CHECK_ADDRESS(self[0].state, NULL);
        CHECK_ADDRESS(self[0].system, NULL);
        CHECK_U_CHAR(self[0].stateLimit, 85U);
        CHECK_U_CHAR(isActive, 0U);
        return;
    }
    IF_INSTANCE("2") {
        CHECK_ADDRESS(self, &allStateLimiter_HBA[0]);
        CHECK_ADDRESS(self[0].state, NULL);
        CHECK_ADDRESS(self[0].system, NULL);
        CHECK_U_CHAR(self[0].stateLimit, 85U);
        CHECK_U_CHAR(isActive, 0U);
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function Dem_NodeSetInitialized */
void Dem_NodeSetInitialized(Dem_NodeIdType NodeId,
                            Dem_boolean_least init){
    REGISTER_CALL("Dem_NodeSetInitialized");

    IF_INSTANCE("1") {
        CHECK_U_CHAR(NodeId, 143U);
        CHECK_U_CHAR(init, 0U);
        return;
    }
    IF_INSTANCE("2") {
        CHECK_U_CHAR(NodeId, 144U);
        CHECK_U_CHAR(init, 0U);
        return;
    }
    IF_INSTANCE("3") {
        CHECK_U_CHAR(NodeId, 145U);
        CHECK_U_CHAR(init, 0U);
        return;
    }
    IF_INSTANCE("4") {
        CHECK_U_CHAR(NodeId, 134U);
        CHECK_U_CHAR(init, 0U);
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function Dem_SetEnableCondition */
Std_ReturnType Dem_SetEnableCondition(uint8 EnableConditionID,
                                      boolean ConditionFulfilled){
    Std_ReturnType returnValue;
    REGISTER_CALL("Dem_SetEnableCondition");

    IF_INSTANCE("1") {
        returnValue = 0U;
        CHECK_U_CHAR(EnableConditionID, 5U);
        CHECK_U_CHAR(ConditionFulfilled, 1U);
        return returnValue;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return returnValue;
}

/* Stub for function PRC_NET_Monitoring_CUSTOMER_CtrlCycx1_V */
void PRC_NET_Monitoring_CUSTOMER_CtrlCycx1_V(){
    REGISTER_CALL("PRC_NET_Monitoring_CUSTOMER_CtrlCycx1_V");

    IF_INSTANCE("1") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function PRC_NET_SCL_Rx_YRS_V */
void PRC_NET_SCL_Rx_YRS_V(){
    REGISTER_CALL("PRC_NET_SCL_Rx_YRS_V");

    IF_INSTANCE("1") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function Dem_ReportErrorStatus */
void Dem_ReportErrorStatus(Dem_EventIdType EventId,
                           Dem_EventStatusType EventStatus){
    REGISTER_CALL("Dem_ReportErrorStatus");

    IF_INSTANCE("1") {
        CHECK_U_INT(EventId, 5U);
        CHECK_U_CHAR(EventStatus, 2U);
        return;
    }
    IF_INSTANCE("2") {
        CHECK_U_INT(EventId, 5U);
        CHECK_U_CHAR(EventStatus, 3U);
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function PRC_NET_Scl_Rx_x4 */
void PRC_NET_Scl_Rx_x4(){
    REGISTER_CALL("PRC_NET_Scl_Rx_x4");

    IF_INSTANCE("1") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function RBScl_Complex_OBD_SignalCopy */
Std_ReturnType RBScl_Complex_OBD_SignalCopy(){
    Std_ReturnType returnValue;
    REGISTER_CALL("RBScl_Complex_OBD_SignalCopy");

    IF_INSTANCE("1") {
        returnValue = 0U;
        return returnValue;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return returnValue;
}

/* pragma qas cantata testscript end */
/*****************************************************************************/
/* End of test script                                                        */
/*****************************************************************************/

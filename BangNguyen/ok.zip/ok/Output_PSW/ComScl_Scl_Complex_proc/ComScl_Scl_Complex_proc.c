
#include "DNCIF_Global.h"
#include "Std_Types.h"
#include "CM_Basetypes_COMMON.h"
#include "Dem.h"
#include "rba_Nds_CommonSettings.h"
#include "ComScl_Scl_Complex_proc.h"
#include "RB_Prj_ConfigSettings.h" //for project defined FS
#include "RBHSWVAR_VarHandling.h"
#include "rba_NET_Global_variable.h"
#include "rba_SCL_Subsystem.h"
#include "SAS_Const.h"

void PRC_NET_Scl_Complex_Init(void)
{
#if (RBFS_ProjectProduct == RBFS_ProjectProduct_ESP)
    //read the APBZero variant information
	 RBMESG_DefineMESGDef(RBMESG_RBAPBDynAPBConfig_N);
	 RBMESG_RcvMESGDef(RBMESG_RBAPBDynAPBConfig_N);

	if(RBAPBDynConfig_APBNormal_N == l_RBMESG_RBAPBDynAPBConfig_N)
	{
		APBZero_NET_Indicate = 0;//Flag for APBMi
	}
	else if (RBAPBDynConfig_APBZero_N == l_RBMESG_RBAPBDynAPBConfig_N)
	{
		APBZero_NET_Indicate = 1;//Flag for APBZero
	}
	else
	{
		/*do nothing*/
	}
#endif

#if (RBFS_ProjectProduct == RBFS_ProjectProduct_HevX)
	ABARequest_ST l_ABARequest_ST;
	NetWheelCircumference_ST l_NMSG_NetWheelCircumference_ST;

	l_ABARequest_ST.Enable_B = FALSE;
	l_ABARequest_ST.Sensivity_UB = 0;
	l_NMSG_NetWheelCircumference_ST.WheelCircumference_UW = 1958;
	l_NMSG_NetWheelCircumference_ST.Qualifier_N = C_NetWheelCircumferenceQualifier_Normal_N;

	SendMESG(NMSG_NetWheelCircumference_ST, l_NMSG_NetWheelCircumference_ST);
	SendMESG(NMSG_ABARequest_ST, l_ABARequest_ST);
	SendMESG(NMSG_BdwWiperState_N, C_BDWWiperState_NotInitialized_N);

#if (RBFS_AvhHSW != RBFS_AvhHSW_Hardwired)
	SendMESG(NMSG_AVHRequest_N, C_AVHRequest_NoRequest_N);
#endif

#if (RBFS_HdcHSW != RBFS_HdcHSW_Hardwired)
	SendMESG(NMSG_HdcRequest_N, C_HdcRequest_NoRequest_N);
#endif

	SendMESG(NMSG_CruiseCtrlReq_N, C_CruiseCtrl_NoRequest_N);

    SendMESG(NMSG_DrvUnitType_FA_N, C_DrvUnitType_Electric_N);
    SendMESG(NMSG_DrvUnitType_RA_N, C_DrvUnitType_Electric_N);

    SendMESG(NMSG_EMotor_Ready_FA_B, TRUE);
    SendMESG(NMSG_EMotor_Ready_RA_B, TRUE);

   SendMESG(MESG_OBD_MILLampOnReq_B, FALSE);

   SendMESG(NMSG_iB_HBV_enabled_B, FALSE);
   SendMESG(NMSG_iB_HBV_requested_B, FALSE);

   StateLimiter__setActive (STM_LIMITER_HBB_HBB_Off_ByEEPROM,FALSE);
   StateLimiter__setActive (STM_LIMITER_HBA_HBA_Off_ByEEPROM,FALSE);

   /* Temporary definition*/
   SendMESG(NMSG_GearboxType_N, C_GearboxType_Automat_N);
   SendMESG(NMSG_GearboxType_FA_N, C_GearboxType_Automat_N);
   SendMESG(NMSG_GearboxType_RA_N, C_GearboxType_Automat_N);

/* Disable monitoring under YrsNet, AxsNet and AysNet DemNode when NET initialize */
/* And monitoring will be enabled when Yrs, Axs and Ays messages are received */
#if (RBFS_SensorMMxEnable == RBFS_SensorMMxEnable_NO)
   Dem_NodeSetInitialized(DemConf_DemNode_YrsNet,FALSE);
   Dem_NodeSetInitialized(DemConf_DemNode_AxsNet,FALSE);
   Dem_NodeSetInitialized(DemConf_DemNode_AysNet,FALSE);
#endif

 /*  CSCRM00407170                                                           */
 /*  Set the SASNet node to initialized only when the SMM is in normal       */
 /*  and the NET monitoring is active                                        */
 /*  Set the SASNet Node to Not init at system Init                          */
 //  Dem_NodeSetInitialized(DemConf_DemNode_SasNet,(B)FALSE);

#if (RBFS_ESPhevXBoosterType  == RBFS_ESPhevXBoosterType_VACUUM)
   SendMESG(NMSG_VAM_LifetimeSetRequest_B, FALSE);
   SendMESG(NMSG_VAM_LifetimeSetDataRuntime_UL, 0x0000000000);
   SendMESG(NMSG_VAM_LifetimeSetDataCycles_UL, 0x0000000000);
   SendMESG(NMSG_VAM_LifetimeSetDone_B, FALSE);
   SendMESG(NMSG_VAM_LifetimeSetState_N, C_SetVAMLTM_Off_N);
   SendMESG(NMSG_VAM_LifetimeDataRuntime_UL, 0x0000000000);
   SendMESG(NMSG_VAM_LifetimeDataCycles_UL, 0x0000000000);
#endif

#endif

	// set enable condition as enable during init phase
	Dem_SetEnableCondition(DemConf_DemEnableCondition_NET_UVMonEnabled, TRUE);
	Dem_SetEnableCondition(DemConf_DemEnableCondition_PlausBlsMonEnabled, TRUE);
	//Dem_SetNodeStatus(DemConf_DemNode_SasNet,DEM_NODESTATUS_NOTINIT);
	//Dem_NodeSetInitialized(DemConf_DemNode_SasNet,FALSE);

	// set enable condition as disable
	//Dem_SetEnableCondition(DemConf_DemEnableCondition_NET_Variant, FALSE);
    Dem_NodeSetInitialized(DemConf_DemNode_SasNet,FALSE);
    Dem_NodeSetInitialized(DemConf_DemNode_AxsNet,FALSE);
    Dem_NodeSetInitialized(DemConf_DemNode_AysNet,FALSE);
    Dem_NodeSetInitialized(DemConf_DemNode_YrsNet,FALSE);
	//PRC_SAS09_Init();

}

void PRC_NET_Scl_Complex_Rx_x1(void)
{

}

void PRC_NET_Scl_Complex_Tx_x1(void)
{
#if(RBFS_NetworkManagement == RBFS_NetworkManagement_On )
PRC_NET_Monitoring_CUSTOMER_CtrlCycx1_V();
#endif
}


void PRC_NET_Scl_Complex_Rx_x2(void)
{
	//RBScl_Complex_SAS_Initialization(); /* SAS node handling */
	//PRC_SAS09_Monitoring_PROJECT_CtrlCycx2_V();
	//PRC_SAS09_Rx_LWS5_Standard();
	#if (RBFS_ProjectProduct == RBFS_ProjectProduct_HevX)
	PRC_NET_SCL_Rx_YRS_V();
	#endif
}
void PRC_NET_Scl_FW_Rx_x2(void)
{
//receive Engstate signal report pass
    #ifdef GWM_CAN_ENGStateCRANKING
    if(GWM_ComScl_EvaluateRxPdu_EngState)
    {
        Dem_ReportErrorStatus(
                            DemConf_DemEventParameter_Scl_EngineCranking_InvalidValue,
                            DEM_EVENT_STATUS_PREPASSED);
    }
    else
    {

        Dem_ReportErrorStatus(
                DemConf_DemEventParameter_Scl_EngineCranking_InvalidValue,
                DEM_EVENT_STATUS_PREFAILED);
    }

    #endif
}
void PRC_NET_Scl_Complex_Tx_x2(void)
{

}

void PRC_NET_Scl_Complex_Rx_x4(void)
{
	#if (RBFS_ProjectProduct == RBFS_ProjectProduct_HevX)
		PRC_NET_Scl_Rx_x4();
	#endif
	#if(RBFS_OBD == RBFS_OBD_On)
    RBScl_Complex_OBD_SignalCopy();/* Copy OBD signals to non-Standard DCOM interfaces */
	#endif
}

void PRC_NET_Scl_Complex_Tx_x4(void)
{


}

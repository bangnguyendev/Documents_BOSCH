 /*
 **************************************************
 **     Project: ComScl_Scl_Complex_proc
 ** Header File: Stubs.c
 **    Function: ./GWM_AB30_CP_Int/MainstreamF30/rb/as/gwm/cp/app/net/RBScl/src/ComScl_Scl_Complex_proc.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:43:11 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_C_
#define STUBS_C_

#include "include.h"

 Std_ReturnType RBScl_Complex_OBD_SignalCopy(void){}
 void PRC_NET_Scl_Rx_x4(void){}
  void Dem_ReportErrorStatus( Dem_EventIdType EventId, Dem_EventStatusType EventStatus ){}
 void PRC_NET_SCL_Rx_YRS_V(void){}
 void PRC_NET_Monitoring_CUSTOMER_CtrlCycx1_V(void){}
 Std_ReturnType Dem_SetEnableCondition (uint8 EnableConditionID, boolean ConditionFulfilled){}
 void Dem_NodeSetInitialized(Dem_NodeIdType NodeId, Dem_boolean_least init){}
 void StateLimiter__setActive (const StateLimiter* self, boolean isActive){}







#endif /*  STUBS_C_  */

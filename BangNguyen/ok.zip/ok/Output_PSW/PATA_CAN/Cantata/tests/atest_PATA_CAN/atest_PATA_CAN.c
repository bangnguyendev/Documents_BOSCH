/*****************************************************************************/
/*                            Cantata Test Script                            */
/*****************************************************************************/
/*
 *    Filename: atest_PATA_CAN.c
 *    Author: nbg7hc
 *    Generated on: 26-May-2020 09:40:50
 *    Generated from: PATA_CAN.c
 */
/*****************************************************************************/
/* Environment Definition                                                    */
/*****************************************************************************/

#define TEST_SCRIPT_GENERATOR 2

/* Include files from software under test */
#include "DNCIF_Global.h"
#include "Net_Global.h"
#include "ComScl_Scl_Complex_MappingSignals.h"
#include "NET_InternalIF.h"
#include "rba_ComScl_Cubas_ComStackAdap_Sigaccwrap.h"
#include "rba_SCL_ClassMapping.h"
#include "RBCN_SclConvert.h"

#define CANTATA_DEFAULT_VALUE 0 /* Default value of variables & stub returns */

#include <cantpp.h>  /* Cantata Directives */
/* pragma qas cantata testscript start */
/*****************************************************************************/
/* Global Data Definitions                                                   */
/*****************************************************************************/

/* Global Functions */
extern void PRC_FUN_NET_PATA_Can();

/* Global data */
extern volatile MESGType_NMSG_Pata_FICM_UB MESG_NMSG_Pata_FICM_UB;
extern volatile MESGType_NMSG_Pata_IPK_B MESG_NMSG_Pata_IPK_B;
extern volatile RBMESG_Type_RBMESG_PATA_CAN_N RBMESG_RBMESG_PATA_CAN_N;

/* Expected variables for global data */
MESGType_NMSG_Pata_FICM_UB expected_MESG_NMSG_Pata_FICM_UB;
MESGType_NMSG_Pata_IPK_B expected_MESG_NMSG_Pata_IPK_B;
RBMESG_Type_RBMESG_PATA_CAN_N expected_RBMESG_RBMESG_PATA_CAN_N;

/* This function initialises global data to default values. This function       */
/* is called by every test case so must not contain test case specific settings */
static void initialise_global_data(){
    INITIALISE(MESG_NMSG_Pata_FICM_UB);
    INITIALISE(MESG_NMSG_Pata_IPK_B);
    INITIALISE(RBMESG_RBMESG_PATA_CAN_N);
}

/* This function copies the global data settings into expected variables for */
/* use in check_global_data(). It is called by every test case so must not   */
/* contain test case specific settings.                                      */
static void initialise_expected_global_data(){
    COPY_TO_EXPECTED(MESG_NMSG_Pata_FICM_UB, expected_MESG_NMSG_Pata_FICM_UB);
    COPY_TO_EXPECTED(MESG_NMSG_Pata_IPK_B, expected_MESG_NMSG_Pata_IPK_B);
    COPY_TO_EXPECTED(RBMESG_RBMESG_PATA_CAN_N, expected_RBMESG_RBMESG_PATA_CAN_N);
}

/* This function checks global data against the expected values. */
static void check_global_data(){
    CHECK_U_CHAR(MESG_NMSG_Pata_FICM_UB, expected_MESG_NMSG_Pata_FICM_UB);
    CHECK_U_CHAR(MESG_NMSG_Pata_IPK_B, expected_MESG_NMSG_Pata_IPK_B);
    CHECK_U_INT(RBMESG_RBMESG_PATA_CAN_N, expected_RBMESG_RBMESG_PATA_CAN_N);
}

/* Prototypes for test functions */
void run_tests();
void test_1(int);
void test_2(int);
void test_3(int);

/*****************************************************************************/
/* Coverage Analysis                                                         */
/*****************************************************************************/
/* Coverage Rule Set: Report all Metrics */
static void rule_set(char* cppca_sut,
                     char* cppca_context)
{
    START_TEST("COVERAGE RULE SET",
               "Report all Metrics");
#ifdef CANTPP_SUBSET_DEFERRED_ANALYSIS
    TEST_SCRIPT_WARNING("Coverage Rule Set ignored in deferred analysis mode\n");
#elif CANTPP_COVERAGE_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Coverage Instrumentation has been disabled\n");
#elif CANTPP_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Instrumentation has been disabled\n");
#else
    REPORT_COVERAGE(cppca_entrypoint_cov|
                    cppca_statement_cov|
                    cppca_basicblock_cov|
                    cppca_callreturn_cov|
                    cppca_decision_cov|
                    cppca_relational_cov|
                    cppca_loop_cov|
                    cppca_booloper_cov|
                    cppca_booleff_cov,
                    cppca_sut,
                    cppca_all_details|cppca_include_catch,
                    cppca_context);
#endif
    END_TEST();
}

/*****************************************************************************/
/* Program Entry Point                                                       */
/*****************************************************************************/
int main()
{
    CONFIGURE_COVERAGE("cov:boolcomb:yes");
    OPEN_LOG("atest_PATA_CAN.ctr", false, 100);
    START_SCRIPT("PATA_CAN", true);

    run_tests();

    return !END_SCRIPT(true);
}

/*****************************************************************************/
/* Test Control                                                              */
/*****************************************************************************/
/* run_tests() contains calls to the individual test cases, you can turn test*/
/* cases off by adding comments*/
void run_tests()
{
    test_1(1);
    test_2(1);
    test_3(1);

    rule_set("*", "*");
    EXPORT_COVERAGE("atest_PATA_CAN.cov", cppca_export_replace);
}

/*****************************************************************************/
/* Test Cases                                                                */
/*****************************************************************************/

void test_1(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_Pata_IPK_B = 85U;
    MESG_NMSG_Pata_FICM_UB = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_RBMESG_PATA_CAN_N = C_Pata_ModeESP_OFF_N;

    START_TEST("1: PRC_FUN_NET_PATA_Can",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_FUN_NET_PATA_Can();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_2(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_Pata_IPK_B = 85U;
    MESG_NMSG_Pata_FICM_UB = 1U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_RBMESG_PATA_CAN_N = 3 /* No matching enumerator found */;

    START_TEST("2: PRC_FUN_NET_PATA_Can",
               "created to solve true case of l_FICMSCSMdReq_UB == 1 at line number 142");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_FUN_NET_PATA_Can();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_3(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    MESG_NMSG_Pata_IPK_B = 1U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_RBMESG_RBMESG_PATA_CAN_N = 3 /* No matching enumerator found */;

    START_TEST("3: PRC_FUN_NET_PATA_Can",
               "created to solve true case of l_IPKSCSMdReq_B == !0 at line number 142");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_FUN_NET_PATA_Can();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*****************************************************************************/
/* Call Interface Control                                                    */
/*****************************************************************************/

/* pragma qas cantata testscript end */
/*****************************************************************************/
/* End of test script                                                        */
/*****************************************************************************/

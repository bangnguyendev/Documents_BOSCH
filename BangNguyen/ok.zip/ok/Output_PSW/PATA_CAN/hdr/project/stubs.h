 /*
 **************************************************
 **     Project: PATA_CAN
 ** Header File: stubs.h
 **    Function: ./SAIC_A_ARCH_CMP_ESP93_Carbon_Int/MainstreamF30/rb/as/saic/CpiwAPB/app/net/RBScl/EP22_M2/src/PATA_CAN.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:45:40 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_H_
#define STUBS_H_

#include "include.h"


typedef enum _Pata_Mode_N /*TOOL_SCAN*/
{
  C_Pata_ModeNotInit_N = 0,
  C_Pata_ModeNormal_N,
  C_Pata_ModeSport_N,
  C_Pata_ModeEspPassiv_N,
  C_Pata_ModePassivDisable
} Pata_Mode_N;
typedef enum _Pata_DNCMode_N/*TOOL_SCAN*/
{
C_Pata_ModeInvalid_N=0,
C_Pata_ModeESP_OFF_N,
C_Pata_ModeESP_ON_N
} Pata_DNCMode_N;

RBMESG_DefineMESGType_EN(RBMESG_PATA_CAN_N, Pata_DNCMode_N);
RBMESG_DefineMESG(RBMESG_PATA_CAN_N);

DefineMESGType_B(NMSG_Pata_IPK_B);
DefineMESG(NMSG_Pata_IPK_B);
DefineMESGType_UB(NMSG_Pata_FICM_UB);
DefineMESG(NMSG_Pata_FICM_UB);

#endif /*  STUBS_H_  */

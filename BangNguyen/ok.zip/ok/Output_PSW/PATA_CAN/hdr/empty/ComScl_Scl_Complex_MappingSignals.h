 /*
 **************************************************
 **     Project: PATA_CAN
 ** Header File: ComScl_Scl_Complex_MappingSignals.h
 **    Function: ./SAIC_A_ARCH_CMP_ESP93_Carbon_Int/MainstreamF30/rb/as/saic/CpiwAPB/app/net/RBScl/EP22_M2/src/PATA_CAN.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:45:25 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef COMSCL_SCL_COMPLEX_MAPINGSIGNALS_H_
#define COMSCL_SCL_COMPLEX_MAPINGSIGNALS_H_

#include "include.h"


#endif /*  COMSCL_SCL_COMPLEX_MAPINGSIGNALS_H_  */

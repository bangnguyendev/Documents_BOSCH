 /*
 **************************************************
 **     Project: PATA_CAN
 ** Header File: rba_ComScl_Cubas_ComStackAdap_Sigaccwrap.h
 **    Function: ./SAIC_A_ARCH_CMP_ESP93_Carbon_Int/MainstreamF30/rb/as/saic/CpiwAPB/app/net/RBScl/EP22_M2/src/PATA_CAN.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:45:32 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef RBA_COMSCL_CUBAS_COMSTACKADAP_SIGACWRAP_H_
#define RBA_COMSCL_CUBAS_COMSTACKADAP_SIGACWRAP_H_

#include "include.h"


#endif /*  RBA_COMSCL_CUBAS_COMSTACKADAP_SIGACWRAP_H_  */

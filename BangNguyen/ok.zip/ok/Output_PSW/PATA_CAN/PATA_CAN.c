/******************************************************************************/
/* [HISTORY_GENERATOR_V1]                                                     */
/******************************************************************************/
/* THIS IS TOOL GENERATED DATA, DO NOT CHANGE !!!                             */
/******************************************************************************/
/* [COPYRIGHT]                                                                */
/* Robert Bosch GmbH reserves all rights even in the event of industrial      */
/* property rights. We reserve all rights of disposal such as copying and     */
/* passing on to third parties.                                               */
/* [COPYRIGHT_END]                                                            */
/******************************************************************************/
/******************************************************************************/
/* [HISTORY_GENERATOR_V1_END]                                                 */
/******************************************************************************/
/****************************************************************************/
/*                                                                          */
/*                    _|_|_|    _|    _|    _|_|                            */
/*                    _|    _|  _|_|  _|  _|    _|                          */
/*                    _|    _|  _|_|_|_|  _|                                */
/*                    _|    _|  _|  _|_|  _|    _|                          */
/*                    _|_|_|    _|    _|    _|_|                            */
/*                                                                          */
/*                                                                          */
/* DNC - Software                                                           */
/*                                                                          */
/* C module body (.c)                                                       */
/*                                                                          */
/* MODULE_STRUCTURE_TYPE = "c_tpl"                                          */
/* MODULE_STRUCTURE_VERSION = 1.0                                           */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* \file                                                                    */
/* \brief This holds a brief description of the module and is not longer    */
/*        than one line. MANDATORY!                                         */
/*                                                                          */
/*  This is the detailed desrciption of the module functionality and        */
/*  beginns                                                                 */
/*  after the mandatory blank line. MANDATORY!                              */
/*                                                                          */
/****************************************************************************/
/* SYSTEM_INFO:                                                             */
/*                                                                          */
/* PSW                                                                      */
/* BIS16                                                                    */
/* ASAP_INFO                                                                */
/* ACCORDING_TO_C_RULES                                                     */
/*                                                                          */
/* SYSTEM_INFO_END:                                                         */
/****************************************************************************/
/****************************************************************************/
/* Write here Pragma DATA_SECTION directives                                */
/*                                                                          */
/* DATA_SECTION_DIRECTIVES:                                                 */
/*                                                                          */
/* DATA_SECTION_DIRECTIVES_END:                                             */
/****************************************************************************/
/*                                                                          */

/****************************************************************************/
/* HEADER_FILES: */

/* MANDATORY_INTERFACES      */
//#include <CM_Settings_PRJ.CFG>
//#include NET09_GLOBAL_COMMON_H
//#include NET09_ALIVECOUNTERLIB_PROJECT_H
/* MANDATORY_INTERFACES_END  */
#include "DNCIF_Global.h"
#include "Net_Global.h"
#include "ComScl_Scl_Complex_MappingSignals.h"
#include "NET_InternalIF.h"
#include "rba_ComScl_Cubas_ComStackAdap_Sigaccwrap.h"
#include "rba_SCL_ClassMapping.h"
#include "RBCN_SclConvert.h"

/* USED_INTERFACES */


/* USED_INTERFACES_END */

/* REALIZED_INTERFACES */
/* REALIZED_INTERFACES_END */

/* HEADER_FILES_END: */

/****************************************************************************/
/* Check here used switches. */
/* USED_SWITCHES: */

/* USED_SWITCHES_END: */

/****************************************************************************/
/* Write here all switch settings which are defined at this time.           */
/* SUPPORTED_SWITCH_SETTINGS:                                               */

/* SUPPORTED_SWITCH_SETTINGS_END:                                           */

/****************************************************************************/
/* Write here local define expressions. Symbols cannot be used in headers!  */
/*                                                                          */
/* LOCAL_DEFINE_EXPRESSIONS:                                                */

/* LOCAL_DEFINE_EXPRESSIONS_END:                                            */

/****************************************************************************/
/* Write here type definitions which are only used in this module.          */
/*                                                                          */
/* LOCAL_TYPE_DEFINITIONS:                                                  */

/* LOCAL_TYPE_DEFINITIONS_END:                                              */

/****************************************************************************/
/* Write here global variables                                              */
/*                                                                          */
/* DATA_OBJECT_DEFINITIONS:                                                 */
/* DATA_OBJECT_DEFINITIONS_END:                                             */

/****************************************************************************/
/* Write here function prototypes for functions which are used only in      */
/* this module.                                                             */
/*                                                                          */
/* LOCAL_FUNCTION_PROTOTYPES:                                               */

/* LOCAL_FUNCTION_PROTOTYPES_END:                                           */

/****************************************************************************/
/* Write here function definitions.                                         */
/*                                                                          */
/* FUNCTION_DEFINITIONS:                                                    */

void PRC_FUN_NET_PATA_Can(void)
{
#if (RBFS_SAIC ==  RBFS_SAIC_EP22MnDA || RBFS_SAIC ==  RBFS_SAIC_EP22MDA)

	UBYTE l_FICMSCSMdReq_UB;
	BOOL l_IPKSCSMdReq_B;
	Pata_Mode_N l_PATA_CAN_N = (Pata_Mode_N) 0;

	RcvMESG(l_FICMSCSMdReq_UB, NMSG_Pata_FICM_UB);
	RcvMESG(l_IPKSCSMdReq_B, NMSG_Pata_IPK_B);

	if((l_IPKSCSMdReq_B == TRUE) || (l_FICMSCSMdReq_UB == 1))
	{
		l_PATA_CAN_N = C_Pata_ModeEspPassiv_N;
	}
	else
	{
		l_PATA_CAN_N = C_Pata_ModeNormal_N;
	}

	RBMESG_SendMESG(RBMESG_PATA_CAN_N, l_PATA_CAN_N);
#endif
}



/* FUNCTION_DEFINITIONS_END:                                                */

/****************************************************************************/
/* Write here process definitions,                                          */
/*                                                                          */
/* PROCESS_DEFINITIONS:                                                     */

/* PROCESS_DEFINITIONS_END:                                                 */
/****************************************************************************/

 /*
 **************************************************
 **     Project: RBVAR_OutputDriver_PROJECT
 ** Header File: stubs.h
 **    Function: ./GAC_IB2_HADHAP_Int/iBoosterGen2/rb/as/gaig/core/app/dsm/RBVAR/A12FPA/src/RBVAR_OutputDriver_PROJECT.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:44:01 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_H_
#define STUBS_H_

#include "include.h"
#define EngineTypeBits                              (0x02)
#define GearboxTypeBits                             (0x03)
#define DrvUnitTypeBits                             (0x03)
#ifndef true
    #define true  1
#endif
#ifndef false
    #define false 0
#endif
#define C_NOOFVARIANTS_UB                 (32u)
typedef enum _EngineType_N /*TOOL_SCAN*/
{
  C_EngineType_Undefined_N = 0,
  C_EngineType_Gasoline_N,
  C_EngineType_Diesel_N,
  C_EngineType_Electrical_N
} EngineType_N;

typedef enum _GearboxType_N /*TOOL_SCAN*/
{
  C_GearboxType_Undefined_N = 0,
  C_GearboxType_Manual_N,
  C_GearboxType_Automat_N,
  C_GearboxType_CVTClutch_N,
  C_GearboxType_CVTConverter_N,
  C_GearboxType_ASGGearInfo_N,
  C_GearboxType_ASGNoGearInfo_N,
  C_GearboxType_TCTGearInfo_N,
  C_GearboxType_TCTNoGearInfo_N
} GearboxType_N;

typedef enum _DrvUnitType_N /*TOOL_SCAN*/
{
  C_DrvUnitType_Undef_N = 0,
  C_DrvUnitType_Combustion_N,
  C_DrvUnitType_Combustion_wStartStop_N,
  C_DrvUnitType_Electric_N,
  C_DrvUnitType_Hybrid_noPureElectricDriving_N,
  C_DrvUnitType_Hybrid_wPureElectricDriving_N
} DrvUnitType_N;
typedef struct
{
  uint32 VehicleType1 :8;
  uint32 VehicleType2 :8;
  uint32 EcuType :8;
  uint32 WssType :8;
  uint32 VehicleConfig :8;
  uint32 DrivelineType :8;
  uint32 Reserved1 :8;
  uint32 VarChecksum :8;
} CCP_DATA_ST;
typedef struct
{
  uint8 VarCode;            // RB VAR code
  CCP_DATA_ST VarCodeID;    // Customer VAR code
  uint32 DemVariant;        // Dem Variant to control State limiter and Failure word usage
  uint8 AswVarOutput;       // Send NMSG to ASW
} VAR_TYPE_LIST_ST;


VAR_TYPE_LIST_ST C_VARTable_PST[C_NOOFVARIANTS_UB];


typedef struct _Var_RBData_ST
{
  UBYTE RBVarCode_UB;
} Var_RBData_ST;

DefineMESGType_ST(NMSG_VarRBData_ST, Var_RBData_ST);
DefineMESG(NMSG_VarRBData_ST);

DefineMESGType_EN(NMSG_DrvUnitType_N, DrvUnitType_N);
DefineMESG(NMSG_DrvUnitType_N);

DefineMESGType_EN(NMSG_GearboxType_N, GearboxType_N);
DefineMESG(NMSG_GearboxType_N);

DefineMESGType_EN(NMSG_EngineType_N, EngineType_N);
DefineMESG(NMSG_EngineType_N);

extern Getbits(uint8 x, uint8 p, uint8 n);


#endif /*  STUBS_H_  */

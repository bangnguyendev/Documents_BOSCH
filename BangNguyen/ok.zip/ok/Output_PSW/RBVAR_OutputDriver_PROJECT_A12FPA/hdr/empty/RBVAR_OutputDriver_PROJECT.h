 /*
 **************************************************
 **     Project: RBVAR_OutputDriver_PROJECT
 ** Header File: RBVAR_OutputDriver_PROJECT.h
 **    Function: ./GAC_IB2_HADHAP_Int/iBoosterGen2/rb/as/gaig/core/app/dsm/RBVAR/A12FPA/src/RBVAR_OutputDriver_PROJECT.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:43:57 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef RBVAR_OUTPUTDRIVER_PROJECT_H_
#define RBVAR_OUTPUTDRIVER_PROJECT_H_

#include "include.h"


#endif /*  RBVAR_OUTPUTDRIVER_PROJECT_H_  */

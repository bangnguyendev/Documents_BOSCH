/*****************************************************************************/
/*                            Cantata Test Script                            */
/*****************************************************************************/
/*
 *    Filename: atest_RBVAR_OutputDriver_PROJECT.c
 *    Author: nbg7hc
 *    Generated on: 27-May-2020 10:18:57
 *    Generated from: RBVAR_OutputDriver_PROJECT.c
 */
/*****************************************************************************/
/* Environment Definition                                                    */
/*****************************************************************************/

#define TEST_SCRIPT_GENERATOR 2

/* Include files from software under test */
#include "RBVAR_OutputDriver_PROJECT.h"

#define CANTATA_DEFAULT_VALUE 0 /* Default value of variables & stub returns */

#include <cantpp.h>  /* Cantata Directives */
/* pragma qas cantata testscript start */
/*****************************************************************************/
/* Global Data Definitions                                                   */
/*****************************************************************************/

/* Global Functions */
int Getbits(uint8 x, uint8 p, uint8 n);
extern void FNC_VAR_OutputDriver(const uint8 * const CDPVars);
extern void PRC_RBVAR_Configuration_GAC();

/* Global data */
extern uint8 RBVAR_VariantCode_UB;
extern volatile MESGType_NMSG_EngineType_N MESG_NMSG_EngineType_N;
extern VAR_TYPE_LIST_ST C_VARTable_PST[32U];
extern volatile MESGType_NMSG_GearboxType_N MESG_NMSG_GearboxType_N;
extern volatile MESGType_NMSG_DrvUnitType_N MESG_NMSG_DrvUnitType_N;
extern volatile MESGType_NMSG_VarRBData_ST MESG_NMSG_VarRBData_ST;

/* Expected variables for global data */
uint8 expected_RBVAR_VariantCode_UB;
MESGType_NMSG_EngineType_N expected_MESG_NMSG_EngineType_N;
VAR_TYPE_LIST_ST expected_C_VARTable_PST[32U];
MESGType_NMSG_GearboxType_N expected_MESG_NMSG_GearboxType_N;
MESGType_NMSG_DrvUnitType_N expected_MESG_NMSG_DrvUnitType_N;
MESGType_NMSG_VarRBData_ST expected_MESG_NMSG_VarRBData_ST;

/* This function initialises global data to default values. This function       */
/* is called by every test case so must not contain test case specific settings */
static void initialise_global_data(){
    INITIALISE(RBVAR_VariantCode_UB);
    INITIALISE(MESG_NMSG_EngineType_N);
    INITIALISE(C_VARTable_PST);
    INITIALISE(MESG_NMSG_GearboxType_N);
    INITIALISE(MESG_NMSG_DrvUnitType_N);
    INITIALISE(MESG_NMSG_VarRBData_ST);
}

/* This function copies the global data settings into expected variables for */
/* use in check_global_data(). It is called by every test case so must not   */
/* contain test case specific settings.                                      */
static void initialise_expected_global_data(){
    COPY_TO_EXPECTED(RBVAR_VariantCode_UB, expected_RBVAR_VariantCode_UB);
    COPY_TO_EXPECTED(MESG_NMSG_EngineType_N, expected_MESG_NMSG_EngineType_N);
    COPY_TO_EXPECTED(C_VARTable_PST, expected_C_VARTable_PST);
    COPY_TO_EXPECTED(MESG_NMSG_GearboxType_N, expected_MESG_NMSG_GearboxType_N);
    COPY_TO_EXPECTED(MESG_NMSG_DrvUnitType_N, expected_MESG_NMSG_DrvUnitType_N);
    COPY_TO_EXPECTED(MESG_NMSG_VarRBData_ST, expected_MESG_NMSG_VarRBData_ST);
}

/* This function checks global data against the expected values. */
static void check_global_data(){
    CHECK_U_CHAR(RBVAR_VariantCode_UB, expected_RBVAR_VariantCode_UB);
    CHECK_U_INT(MESG_NMSG_EngineType_N, expected_MESG_NMSG_EngineType_N);
    CHECK_MEMORY("C_VARTable_PST", C_VARTable_PST, expected_C_VARTable_PST, sizeof(expected_C_VARTable_PST));
    CHECK_U_INT(MESG_NMSG_GearboxType_N, expected_MESG_NMSG_GearboxType_N);
    CHECK_U_INT(MESG_NMSG_DrvUnitType_N, expected_MESG_NMSG_DrvUnitType_N);
    CHECK_MEMORY("MESG_NMSG_VarRBData_ST", &MESG_NMSG_VarRBData_ST, &expected_MESG_NMSG_VarRBData_ST, sizeof(expected_MESG_NMSG_VarRBData_ST));
}

/* Prototypes for test functions */
void run_tests();
void test_1(int);
void test_2(int);
void test_3(int);

/*****************************************************************************/
/* Coverage Analysis                                                         */
/*****************************************************************************/
/* Coverage Rule Set: Report all Metrics */
static void rule_set(char* cppca_sut,
                     char* cppca_context)
{
    START_TEST("COVERAGE RULE SET",
               "Report all Metrics");
#ifdef CANTPP_SUBSET_DEFERRED_ANALYSIS
    TEST_SCRIPT_WARNING("Coverage Rule Set ignored in deferred analysis mode\n");
#elif CANTPP_COVERAGE_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Coverage Instrumentation has been disabled\n");
#elif CANTPP_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Instrumentation has been disabled\n");
#else
    REPORT_COVERAGE(cppca_entrypoint_cov|
                    cppca_statement_cov|
                    cppca_basicblock_cov|
                    cppca_callreturn_cov|
                    cppca_decision_cov|
                    cppca_relational_cov|
                    cppca_loop_cov|
                    cppca_booloper_cov|
                    cppca_booleff_cov,
                    cppca_sut,
                    cppca_all_details|cppca_include_catch,
                    cppca_context);
#endif
    END_TEST();
}

/*****************************************************************************/
/* Program Entry Point                                                       */
/*****************************************************************************/
int main()
{
    CONFIGURE_COVERAGE("cov:boolcomb:yes");
    OPEN_LOG("atest_RBVAR_OutputDriver_PROJECT.ctr", false, 100);
    START_SCRIPT("RBVAR_OutputDriver_PROJECT", true);

    run_tests();

    return !END_SCRIPT(true);
}

/*****************************************************************************/
/* Test Control                                                              */
/*****************************************************************************/
/* run_tests() contains calls to the individual test cases, you can turn test*/
/* cases off by adding comments*/
void run_tests()
{
    test_1(1);
    test_2(1);
    test_3(1);

    rule_set("*", "*");
    EXPORT_COVERAGE("atest_RBVAR_OutputDriver_PROJECT.cov", cppca_export_replace);
}

/*****************************************************************************/
/* Test Cases                                                                */
/*****************************************************************************/

void test_1(int doIt){
if (doIt) {
    /* Test case data declarations */
    const uint8 * CDPVars = NULL;
    /* Set global data */
    initialise_global_data();
    RBVAR_VariantCode_UB = 85U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_MESG_NMSG_DrvUnitType_N = C_DrvUnitType_Undef_N;
    expected_MESG_NMSG_GearboxType_N = C_GearboxType_Undefined_N;
    expected_MESG_NMSG_EngineType_N = C_EngineType_Undefined_N;

    START_TEST("1: FNC_VAR_OutputDriver",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            FNC_VAR_OutputDriver(CDPVars);

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_2(int doIt){
if (doIt) {
    /* Test case data declarations */
    const uint8 * CDPVars = NULL;
    /* Set global data */
    initialise_global_data();
    C_VARTable_PST[0].AswVarOutput = 85U;
    RBVAR_VariantCode_UB = 1U;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_MESG_NMSG_DrvUnitType_N = C_DrvUnitType_Undef_N;
    expected_MESG_NMSG_GearboxType_N = C_GearboxType_Undefined_N;
    expected_MESG_NMSG_EngineType_N = C_EngineType_Undefined_N;

    START_TEST("2: FNC_VAR_OutputDriver",
               "created to solve true case of RBVAR_VariantCode_UB <= 32U at line number 94 ");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Getbits#1;Getbits#2;Getbits#3");

            /* Call SUT */
            FNC_VAR_OutputDriver(CDPVars);

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_3(int doIt){
if (doIt) {
    /* Test case data declarations */
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("3: PRC_RBVAR_Configuration_GAC",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            PRC_RBVAR_Configuration_GAC();

            /* Test case checks */
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*****************************************************************************/
/* Call Interface Control                                                    */
/*****************************************************************************/

/* Stub for function Getbits */
int Getbits(uint8 x,
            uint8 p,
            uint8 n){
    int returnValue;
    REGISTER_CALL("Getbits");

    IF_INSTANCE("1") {
        returnValue = 0;
        CHECK_U_CHAR(x, 85U);
        CHECK_U_CHAR(p, 2U);
        CHECK_U_CHAR(n, 2U);
        return returnValue;
    }
    IF_INSTANCE("2") {
        returnValue = 0;
        CHECK_U_CHAR(x, 85U);
        CHECK_U_CHAR(p, 5U);
        CHECK_U_CHAR(n, 3U);
        return returnValue;
    }
    IF_INSTANCE("3") {
        returnValue = 0;
        CHECK_U_CHAR(x, 85U);
        CHECK_U_CHAR(p, 8U);
        CHECK_U_CHAR(n, 3U);
        return returnValue;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return returnValue;
}

/* pragma qas cantata testscript end */
/*****************************************************************************/
/* End of test script                                                        */
/*****************************************************************************/

/******************************************************************************/
/* [HISTORY_GENERATOR_V1]                                                     */
/******************************************************************************/
/* THIS IS TOOL GENERATED DATA, DO NOT CHANGE !!!                             */
/******************************************************************************/
/* [COPYRIGHT]                                                                */
/* Robert Bosch GmbH reserves all rights even in the event of industrial      */
/* property rights. We reserve all rights of disposal such as copying and     */
/* passing on to third parties.                                               */
/* [COPYRIGHT_END]                                                            */
/******************************************************************************/
/* [HISTORY]                                                                  */
/* -------------------------------------------------------------------------- */
/* [FILE_BASIC_INFO]                                                          */
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/* Description   :                                                            */
/* Note          :                                                            */
/* -------------------------------------------------------------------------- */
/* [FILE_BASIC_INFO_END]                                                      */
/******************************************************************************/
/* [FILE_CHANGE_ENTRIES]                                                      */
/* -------------------------------------------------------------------------- */
/* Revision      : 1.0                                                        */
/* Checked in by : stk7kor                                                    */
/* Check in date : 12.02.2014 19:04:40                                        */
/*                 02/12/2014 19:04:40                                        */
/* Changes       : V362C ESP: Var Updates for CSW2                            */
/* Reasons       : CSCRM00615898                                              */
/*                                                                            */
/* CSCRM00615898 : V362C ESP: Var Updates for CSW2                            */
/*               : CSCRM00613373 : V362C ESP: Var Updates for CSW2            */
/* -------------------------------------------------------------------------- */
/* [FILE_CHANGE_ENTRIES_END]                                                  */
/* -------------------------------------------------------------------------- */
/* [HISTORY_END]                                                              */
/******************************************************************************/
/* [HISTORY_GENERATOR_V1_END]                                                 */
/******************************************************************************/

/**
 * WARNING: This file is a template, do not use without adaption to project requirements
 */

#include "RBVAR_OutputDriver_PROJECT.h"

//Value of calculated variant code.
uint8 RBVAR_VariantCode_UB;
/*[[MEASUREMENT*/
/*NAME=RBVAR_VariantCode_UB*/
/*MODEL_NAME=RBVAR_VariantCode_UB*/
/*DATA_TYPE=uint8*/
/*COMMENT=ASW Variant calculated */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=0xFF*/
/*MTEVENT=c_MT_Default_Task_x1*/
/*]]MEASUREMENT*/

uint8 RBVAR_varcode_DoubleChannelCAN_UB = true;//This flag is used in NET to distinguish sing/double channel CAN variant.
/*[[MEASUREMENT*/
/*NAME=RBVAR_varcode_DoubleChannelCAN_UB*/
/*MODEL_NAME=RBVAR_varcode_DoubleChannelCAN_UB*/
/*DATA_TYPE=uint8*/
/*COMMENT=RBVAR_varcode_DoubleChannelCAN_UB */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=0xFF*/
/*MTEVENT=c_MT_Default_Task_x1*/
/*]]MEASUREMENT*/

uint8 debugEnablecondition_UB = 0;
/*[[MEASUREMENT*/
/*NAME=debugEnablecondition_UB*/
/*MODEL_NAME=debugEnablecondition_UB*/
/*DATA_TYPE=uint8*/
/*COMMENT=ASW Variant calculated */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=0xFF*/
/*MTEVENT=c_MT_Default_Task_x1*/
/*]]MEASUREMENT*/

// Sends all necessary parameter depended messages
/*
 * DE: This function set VAR info to ASW side
 *
 */

#if (RBFS_ASWVarOutputCustomized == RBFS_ASWVarOutputCustomized_Yes)
void FNC_VAR_OutputDriver(const uint8 * const CDPVars)
{
  (void)CDPVars;
  if (RBVAR_VariantCode_UB <= C_NOOFVARIANTS_UB)
  {
    SendMESG(NMSG_EngineType_N, (EngineType_N)Getbits(C_VARTable_PST[RBVAR_VariantCode_UB-1].AswVarOutput, EngineTypeBits, EngineTypeBits));
    SendMESG(NMSG_GearboxType_N, (GearboxType_N)Getbits(C_VARTable_PST[RBVAR_VariantCode_UB-1].AswVarOutput, (GearboxTypeBits+EngineTypeBits), GearboxTypeBits));
    SendMESG(NMSG_DrvUnitType_N, (DrvUnitType_N)Getbits(C_VARTable_PST[RBVAR_VariantCode_UB-1].AswVarOutput, 8, DrvUnitTypeBits));    
  }
  else
  {
    SendMESG(NMSG_EngineType_N, C_EngineType_Undefined_N);
    SendMESG(NMSG_GearboxType_N, C_GearboxType_Undefined_N);
    SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Undef_N);
  }
}
#else
void FNC_VAR_OutputDriver(const uint8 * const CDPVars)
{

}
#endif


/*
 * default on variant:     HBA,HHC,CRBS,CDP,APBMi,HAZ,HSM
 * need to define variant: ABA,ABP,AEB,AWB,CDD_S,LSM,AVH,HBB,HDC
 * default off variant:    BDW,CCB,CCL,CCO,DCT_C,EUC,HFC,HRB,LFC,PAP,RAG,SCM,TSM
 */

void PRC_RBVAR_Configuration_GAC(void)
{
	Var_RBData_ST l_RBVarcode_ST;
	RcvMESG(l_RBVarcode_ST, NMSG_VarRBData_ST);

	//implement single/double can
	//if(l_RBVarcode_ST.RBVarCode_UB == 2)
	//{
		//debugEnablecondition_UB=1;
		//Dem_SetEnableCondition(DemConf_DemEnableCondition_RBNetSingleCAN, TRUE);

		//RBVAR_varcode_DoubleChannelCAN_UB = TRUE;
	//}
	//single can variant should suppress the FWs related second can monitors.
	//else
	//{
		//debugEnablecondition_UB=2;
		//Dem_SetEnableCondition(DemConf_DemEnableCondition_RBNetSingleCAN, FALSE);

		//RBVAR_varcode_DoubleChannelCAN_UB = FALSE;
	//}

}
/* FUNCTION_DEFINITIONS_END:                                                */
/****************************************************************************/

 /*
 **************************************************
 **     Project: RBVAR_OutputDriver_PROJECT
 ** Header File: Stubs.c
 **    Function: ./GAC_IB2_HADHAP_Int/iBoosterGen2/rb/as/gaig/core/app/dsm/RBVAR/A12FPA/src/RBVAR_OutputDriver_PROJECT.c
 **************************************************
 **
 **  Created on: Mon, May 25, 2020 12:44:04 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_C_
#define STUBS_C_

#include "include.h"

 Getbits(uint8 x, uint8 p, uint8 n)
{
  return (x>>(p-n)) & ~(~0<<n);
}






#endif /*  STUBS_C_  */

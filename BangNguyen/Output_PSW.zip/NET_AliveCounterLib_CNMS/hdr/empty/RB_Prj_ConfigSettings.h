 /*
 **************************************************
 **     Project: NET_AliveCounterLib_CNMS
 ** Header File: RB_Prj_ConfigSettings.h
 **    Function: ./BAIC_ESP93CPi_RC_Init/MainstreamF30/rb/as/baic/CpiwAPB/app/net/RbNetPrj/RBNet_Can/src/NET_AliveCounterLib_CNMS.c
 **************************************************
 **
 **  Created on: Wed, May  6, 2020  1:43:59 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef RB_PRJ_CONFIGSETINGS_H_
#define RB_PRJ_CONFIGSETINGS_H_

#include "include.h"


#endif /*  RB_PRJ_CONFIGSETINGS_H_  */

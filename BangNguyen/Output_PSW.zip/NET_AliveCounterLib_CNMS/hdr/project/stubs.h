 /*
 **************************************************
 **     Project: NET_AliveCounterLib_CNMS
 ** Header File: stubs.h
 **    Function: ./BAIC_ESP93CPi_RC_Init/MainstreamF30/rb/as/baic/CpiwAPB/app/net/RbNetPrj/RBNet_Can/src/NET_AliveCounterLib_CNMS.c
 **************************************************
 **
 **  Created on: Wed, May  6, 2020  1:44:00 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_H_
#define STUBS_H_

#include "include.h"


#define ALVIE_COUNTER_MAX_UB             (0x0F)

#define SAS_AC_MAX_UB                    (0x10)
#define SAS_AC_LOWRANGE_UB               (0x01)
#define SAS_AC_HIGHRANGE_UB              (0x03)

#define RBFS_ProjectBB_95572            1
#define RBFS_ProjectBB_96004            2
#define RBFS_ProjectBB_97164            3   //C11
#define RBFS_ProjectBB_97365            4   //C40DB
#define RBFS_ProjectBB_97330            5   //C51EB
#define RBFS_ProjectBB_97331            6   //C62X
#define RBFS_ProjectBB_97527            7   //C35DB
#define RBFS_ProjectBB_99011            8   //C40D C06
#define RBFS_ProjectBB_99012            9   //C51E M08
#define RBFS_ProjectBB_99117            10  //C53F G06
#define RBFS_ProjectBB_99989            11  //C40DB RC
#define RBFS_ProjectBB_99990            12  //C51EB RC
#define RBFS_ProjectBB_81018            13  //C40DB C02
#define RBFS_ProjectBB_82308            14  //C62X RC

#define RBFS_ProjectBB RBFS_ProjectBB_82308






#endif /*  STUBS_H_  */

 /*
 **************************************************
 **     Project: NET_AliveCounterLib_CNMS
 ** Header File: Stubs.c
 **    Function: ./BAIC_ESP93CPi_RC_Init/MainstreamF30/rb/as/baic/CpiwAPB/app/net/RbNetPrj/RBNet_Can/src/NET_AliveCounterLib_CNMS.c
 **************************************************
 **
 **  Created on: Wed, May  6, 2020  1:44:00 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_C_
#define STUBS_C_

#include "include.h"








#endif /*  STUBS_C_  */

/******************************************************************************/
/* [HISTORY_GENERATOR_V1]                                                     */
/******************************************************************************/
/* THIS IS TOOL GENERATED DATA, DO NOT CHANGE !!!                             */
/******************************************************************************/
/* [COPYRIGHT]                                                                */
/* Robert Bosch GmbH reserves all rights even in the event of industrial      */
/* property rights. We reserve all rights of disposal such as copying and     */
/* passing on to third parties.                                               */
/* [COPYRIGHT_END]                                                            */
/******************************************************************************/
/* [HISTORY]                                                                  */
/* -------------------------------------------------------------------------- */
/* [FILE_BASIC_INFO]                                                          */
/* -------------------------------------------------------------------------- */
/* File name     : NET09_AliveCounterLib_CNMS.c                               */
/* -------------------------------------------------------------------------- */
/* Description   :                                                            */
/* Note          :                                                            */
/* -------------------------------------------------------------------------- */
/* [FILE_BASIC_INFO_END]                                                      */
/******************************************************************************/
/* [FILE_CHANGE_ENTRIES]                                                      */
/* -------------------------------------------------------------------------- */
/* Revision      : 1.0                                                        */
/* Checked in by : sum1szh                                                    */
/* Check in date : 19.09.2013 23:21:02                                        */
/*                 09/19/2013 23:21:02                                        */
/* Changes       : CA ESP C206 Base CAN Matrix                                */
/*                                                                            */
/*                 Functions Utils                                            */
/* Reasons       : CNMS 7.0                                                   */
/*                                                                            */
/* CSCRM00549102 : [CNMS_CP_BaseLine_13_1_NET]:XPASS Implementation           */
/*               : CSCRM00549081 : [CNMS_CP_BaseLine_BL7_NET]:NET             */
/*                 Implementation                                             */
/* -------------------------------------------------------------------------- */
/* [FILE_CHANGE_ENTRIES_END]                                                  */
/* -------------------------------------------------------------------------- */
/* [HISTORY_END]                                                              */
/******************************************************************************/
/* [HISTORY_GENERATOR_V1_END]                                                 */
/******************************************************************************/
/****************************************************************************/
/*                                                                          */
/*                    _|_|_|    _|    _|    _|_|                            */
/*                    _|    _|  _|_|  _|  _|    _|                          */
/*                    _|    _|  _|_|_|_|  _|                                */
/*                    _|    _|  _|  _|_|  _|    _|                          */
/*                    _|_|_|    _|    _|    _|_|                            */
/*                                                                          */
/*                                                                          */
/* DNC - Software                                                           */
/*                                                                          */
/* C module body (.c)                                                       */
/*                                                                          */
/* MODULE_STRUCTURE_TYPE = "c_tpl"                                          */
/* MODULE_STRUCTURE_VERSION = 1.0                                           */
/*                                                                          */
/****************************************************************************/
/* MODULEFILE_NAME:                                                         */
/* NET09_ALIVECOUNTERLIB_RBRef.C                                            */
/* MODULEFILE_NAME_END:                                                     */
/*--------------------------------------------------------------------------*/
/* MODULEFILE_DESCRIPTION:                                                  */
/*                                                                          */
/* OVERVIEW:                                                                */
/* Contains checksum libs              .                                    */
/* MODULDESCRIPTION:                                                        */
/*                                                                          */
/* MODULEFILE_DESCRIPTION_END:                                              */
/****************************************************************************/
/* Only printed attributes can be applied to this module type.              */
/* Delete inappropriate attribute lines below.                              */
/* If more than one leave only one entry per line.                          */
/* SYSTEM_INFO:                                                             */
/*                                                                          */
/* ASAP_INFO */
/* BIS16 */
/* PSW */
/* RB_SOURCE */
/* STRICT */
/* TMS470 */
/*                                                                          */
/* SYSTEM_INFO_END:                                                         */
/****************************************************************************/
/* Write here Pragma DATA_SECTION directives which refer to                 */
/* included headers. Other write directly above data object definition      */
/*                                                                          */
/* DATA_SECTION_DIRECTIVES:                                                 */

/* DATA_SECTION_DIRECTIVES_END:                                             */
/****************************************************************************/
/* Include here header files of supported types.                            */
/* MANDATORY_INTERFACES:                                                    */

/* ======================================================================== */
/* CSW global CM header files                                               */
/* ======================================================================== */
//#include <CM_Settings_PRJ.CFG>
//#include NET09_GLOBAL_PROJECT_H
//#include SMM_SYSTEMMODE_COMMON_H
//#include GETSYSTEMMODE_COMMON_H
#include "Net_Global.h"
#include "NET_AliveCounterLib_CNMS.h"
#include "RB_Prj_ConfigSettings.h"
/* ======================================================================== */
/* Global CM header for group                                               */
/* ======================================================================== */

/* ======================================================================== */
/* If this file uses configuration elements                                 */
/* (i.e. it is using switches, parameters),                                 */
/* get the group configuration by including the corresponding header.       */
/* ======================================================================== */

/* ======================================================================== */
/* Normalization constant definition header files (nrm)                     */
/* ======================================================================== */

/* ======================================================================== */
/* Non global function switch files (swi, swd)                              */
/* ======================================================================== */

/* ======================================================================== */
/* Parameter definition header files (pcd)                                  */
/* ======================================================================== */

/* ======================================================================== */
/* Constant definition header files (cdf)                                   */
/* ======================================================================== */

/* ======================================================================== */
/* Type definition header files (tdf) / Common header files (h)             */
/* ======================================================================== */

/* ======================================================================== */
/* Component interface header files (cif)                                   */
/* ======================================================================== */

/* ======================================================================== */
/* Inline function header files (inl)                                       */
/* ======================================================================== */

/* MANDATORY_INTERFACES_END:                                                */
/****************************************************************************/
/* Check here used switches.                                                */
/*                                                                          */
/* USED_SWITCHES:                                                           */

/* USED_SWITCHES_END:                                                       */
/****************************************************************************/
/* Write here all switch settings which are defined at this time.           */
/*                                                                          */
/* SUPPORTED_SWITCH_SETTINGS:                                               */

/* SUPPORTED_SWITCH_SETTINGS_END:                                           */
/****************************************************************************/
/* Write here local define expressions. Symbols cannot be used in headers!  */
/*                                                                          */
/* LOCAL_DEFINE_EXPRESSIONS:                                                */

/* LOCAL_DEFINE_EXPRESSIONS_END:                                            */
/****************************************************************************/
/* Write here type definitions which are only used in this module.          */
/*                                                                          */
/* LOCAL_TYPE_DEFINITIONS:                                                  */

/* LOCAL_TYPE_DEFINITIONS_END:                                              */
/****************************************************************************/
/* Write here variables and constants.                                      */
/*                                                                          */
/* DATA_OBJECT_DEFINITIONS:                                                 */
//SystemMode_N g_SmmPrevModestate_N = C_SMM_NET_ON_N;
//SystemMode_N g_SmmCurrModestate_N = C_SMM_INIT_N;
/* DATA_OBJECT_DEFINITIONS_END:                                             */
/****************************************************************************/
/* Write here function prototypes for functions which are used only in      */
/* this module.                                                             */
/*                                                                          */
/* LOCAL_FUNCTION_PROTOTYPES:                                               */

/* LOCAL_FUNCTION_PROTOTYPES_END:                                           */
/****************************************************************************/
/* Write here function definitions.                                         */
/*                                                                          */
/* FUNCTION_DEFINITIONS:                                                    */


/* SAS LiveCounter Algorithm */
/* From ASW side */
boolean rba_ComScl_SAS_EvalAc_Std(uint8 receivedAliveCounter, uint8 lastAliveCounter)
{
    boolean isOk;
    static UBYTE ls_SasDifAC;

    isOk = TRUE;

    ls_SasDifAC = (receivedAliveCounter >= lastAliveCounter) ? (receivedAliveCounter - lastAliveCounter)
    		                    : ((receivedAliveCounter + SAS_AC_MAX_UB) - lastAliveCounter);

    /* If deviation < 1 or >3 then report error */
    if(( ls_SasDifAC < SAS_AC_LOWRANGE_UB) || (ls_SasDifAC > SAS_AC_HIGHRANGE_UB))
    {
        isOk = FALSE;
    }
    return (isOk);
}


/* ----------------------------------------------------------------------------
 Name:
  FUN_NET_EvalAc_CntMaxUb_B

 Description:
  Evaluating synchronous alivecounter.
  Received Alivecounter must be equal to value that was transmitted with
  the last CAN-message request.

 Parameter:
   NetAliveCounter_UB - current alive counter received via Network message
   BufferedAliveCounter_PUB - For passing back expected alivecounter value
   MaxCount_UB - maximum allowed counter value

 Return:
  Result of evaluation
  TRUE  = Alivecounter o.k.
  FALSE = Alivecouter check failed 

 History:
-----------------------------------------------------------------------------*/
BOOL FUN_NET_EvalAc_CntMaxUb_B(uint8_t NetAliveCounter_UB, uint8_t* BufferedAliveCounter_PUB)
{
  BOOL l_RetVal_B = FALSE;

  if ((NetAliveCounter_UB != *BufferedAliveCounter_PUB) && (NetAliveCounter_UB <= ALVIE_COUNTER_MAX_UB))
  {
    l_RetVal_B = TRUE;
  }
  *BufferedAliveCounter_PUB = NetAliveCounter_UB;

  return (l_RetVal_B);
}


/* ----------------------------------------------------------------------------
 Name:
  FUN_NET_EvalAc_CntMaxUw_B

 Description:
  Evaluating synchronous alivecounter.
  Received Alivecounter must be equal to value that was transmitted with
  the last CAN-message request.

 Parameter:
   NetAliveCounter_UW - current alive counter received via Network message
   BufferedAliveCounter_PUW - For passing back expected alivecounter value
   MaxCount_UW - maximum allowed counter value

 Return:
  Result of evaluation
  TRUE  = Alivecounter o.k.
  FALSE = Alivecouter check failed 

 History:
-----------------------------------------------------------------------------*/
BOOL FUN_NET_EvalAc_CntMaxUw_B(uint16_t NetAliveCounter_UW, uint16_t* BufferedAliveCounter_PUW, uint16_t MaxCount_UW)
{
  BOOL l_RetVal_B = FALSE;

  if ((NetAliveCounter_UW != *BufferedAliveCounter_PUW) && (NetAliveCounter_UW <= MaxCount_UW))
  {
    l_RetVal_B = TRUE;
  }
  *BufferedAliveCounter_PUW = NetAliveCounter_UW;

  return (l_RetVal_B);
}


/* ----------------------------------------------------------------------------
 Name:
  FUN_NET_GenAc_CntMaxWithMaskUb_UB

 Description:
  Calculation of the message counter
  MaxCount_UL value configurable via config entry in NDS sheet project config.


 Parameter:
   BufferedAliveCounter_PUB - For passing back the alivecounter value to caller
   MaxCount_UB - maximum allowed counter value
   Mask_UB - Bit Mask

 Return:
  current alivecounter value

 History:
-----------------------------------------------------------------------------*/
uint8_t FUN_NET_GenAc_CntMaxWithMaskUb_UB(uint8_t* BufferedAliveCounter_PUB)
{
  {
    (*BufferedAliveCounter_PUB)++;

    if(ALVIE_COUNTER_MAX_UB < (*BufferedAliveCounter_PUB))
    {
      *BufferedAliveCounter_PUB = 0;
    }
    *BufferedAliveCounter_PUB = (*BufferedAliveCounter_PUB) & ALVIE_COUNTER_MAX_UB;
  }

  return *BufferedAliveCounter_PUB;
}

uint8_t FUN_NET_GenAc_CntMaxUb_UB(uint8_t* BufferedAliveCounter_PUB)
{
  {
    (*BufferedAliveCounter_PUB)++;
    if(ALVIE_COUNTER_MAX_UB < (*BufferedAliveCounter_PUB))
    {
      *BufferedAliveCounter_PUB = 0;
    }
    *BufferedAliveCounter_PUB = (*BufferedAliveCounter_PUB);
  }
  return *BufferedAliveCounter_PUB;
}

/* ----------------------------------------------------------------------------
 Name:
  FUN_NET_GenAc_CntMaxWithMaskUw_UW

 Description:
  Calculation of the message counter
  MaxCount_UL value configurable via config entry in NDS sheet project config.


 Parameter:
   BufferedAliveCounter_PUW - For passing back the alivecounter value to caller
   MaxCount_UW - maximum allowed counter value
   Mask_UW - Bit Mask

 Return:
  current alivecounter value

 History:
-----------------------------------------------------------------------------*/
uint16_t FUN_NET_GenAc_CntMaxWithMaskUw_UW(uint16_t* BufferedAliveCounter_PUW, uint16_t MaxCount_UW, uint16_t Mask_UW)
{
  {
    (*BufferedAliveCounter_PUW)++;

    if(MaxCount_UW < (*BufferedAliveCounter_PUW))
    {
      *BufferedAliveCounter_PUW = 0;
    }
    *BufferedAliveCounter_PUW = (*BufferedAliveCounter_PUW) & Mask_UW;
  }

  return *BufferedAliveCounter_PUW;
}

/* ----------------------------------------------------------------------------
 Name:
  FUN_NET_IsRxMsgCntMonReq_B

 Description:
  Function which ensures that the alive counter monitoring is not done 
  for Rx frame recieved first after ECU on,after system mode state switches 
  from CAN_OFF to CAN_ON and after a timeout situation is been detected.	  

 Parameter:

 Return:
  Result of evaluation
  TRUE  = First Rx msg Alive Counter monitoring is required.
  FALSE = First Rx msg Alive couter monitoring not required. 

 History:
30.06.10/paj4kor/ First edition of function
-----------------------------------------------------------------------------*/

//BOOL FUN_NET_IsRxMsgCntMonReq_B(void)
//{
//  BOOL l_RetVal_B = TRUE;

//  g_SmmCurrModestate_N = FUN_SMM_CurrentSystemMode_N();

//  if( /* check which ensures that the Smm mode state has changed from NET_OFF to NET_ON */
//      ((g_SmmCurrModestate_N == C_SMM_NET_ON_N) && (g_SmmPrevModestate_N == C_SMM_NET_OFF_N)) ||
//      /* check which ensures that the Smm mode state has changed from NET_ON to NORMAL */
//      ((g_SmmCurrModestate_N == C_SMM_NORMAL_N) && (g_SmmPrevModestate_N != C_SMM_NORMAL_N))
//      /* check which ensures that there was timeout situation detected during previous cycle */
//    )
//  {
//    l_RetVal_B = FALSE;
//  }
    
//  return (l_RetVal_B);
//} /* end of function FUN_NET_IsRxMsgCntMonReq_B */

/**
 * Generate a Counter module 15.
 * Parameters:
 *    lastAliveCounterPtr: AliveCounter previously generated.
 * Output: New value of the AliveCounter.
 */
uint8 FUN_NET_GenAc_Std_Cntmax_UB(uint8 lastAliveCounter,uint8 Maxvalue_counter)
{
    uint8 msgCtr_u8 = lastAliveCounter;

    if(msgCtr_u8 < Maxvalue_counter)
    {
        msgCtr_u8++;
    }
    else
    {
        msgCtr_u8 = 0;
    }

    lastAliveCounter = msgCtr_u8;

    return (msgCtr_u8);
}
/* ----------------------------------------------------------------------------
In The VBP_0x47F frame info and vacummpressure signal is same for Both C40_C51 and C11_C35 project. but there
 * is no checksum and alive counter signals for C40_C51 project. so by using Project specific switch, the function
 * will return true always for C40_C51 project.In RBA nds, the frame commonly configured and Alivecounter and checkum is
 * controlled in SCL

 History:
-----------------------------------------------------------------------------*/
BOOL FUN_NET_EvalAc_CntMaxUb_VBP_B(uint8_t NetAliveCounter_UB, uint8_t BufferedAliveCounter_PUB)
{
#if((RBFS_ProjectBB == RBFS_ProjectBB_97164)||(RBFS_ProjectBB == RBFS_ProjectBB_97527))

  BOOL l_RetVal_B;


  l_RetVal_B = TRUE;

     if(NetAliveCounter_UB == BufferedAliveCounter_PUB)
     {
    	 l_RetVal_B = FALSE;
     }

  return (l_RetVal_B);
#endif

#if((RBFS_ProjectBB == RBFS_ProjectBB_97365)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99989)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_97330)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99990)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_97331)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99011)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99012)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99117)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_81018)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_82308)\
	)
  {
  BOOL l_RetVal_B =TRUE;
  return l_RetVal_B;
  }
#endif

}

/* FUNCTION_DEFINITIONS_END:                                                */
/****************************************************************************/

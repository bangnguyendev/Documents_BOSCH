 /*
 **************************************************
 **     Project: RBAPLCUST_WDBI_NVMData
 ** Header File: RB_AssertSwitchsettings.h
 **    Function: ./BAIC_ESP93CPi_RC_Init/MainstreamF30/rb/as/baic/core/app/dcom/RBAPLCust/src/RBAPLCUST_WDBI_NVMData.c
 **************************************************
 **
 **  Created on: Wed, May  6, 2020  1:43:31 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef RB_ASERTSWITCHSETINGS_H_
#define RB_ASERTSWITCHSETINGS_H_

#include "include.h"


#endif /*  RB_ASERTSWITCHSETINGS_H_  */

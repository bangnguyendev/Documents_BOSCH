 /*
 **************************************************
 **     Project: RBAPLCUST_WDBI_NVMData
 ** Header File: stubs.h
 **    Function: ./BAIC_ESP93CPi_RC_Init/MainstreamF30/rb/as/baic/core/app/dcom/RBAPLCust/src/RBAPLCUST_WDBI_NVMData.c
 **************************************************
 **
 **  Created on: Wed, May  6, 2020  1:43:33 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_H_
#define STUBS_H_

#include "include.h"


typedef enum
{
    C_InitWriteByPdm =0,
    C_ProcessingWriteByPdm,
    C_DoneWriteByPdm,
    C_ErrorWriteByPdm

}DCOM_WriteNvmState_N;
#define DCM_E_PENDING               10
#define DCM_E_CONDITIONSNOTCORRECT 0x22
#define NvMConf_NvMBlockDescriptor_NVM_ID_BLDR_VIN 5
#define NvMConf_NvMBlockDescriptor_NVM_ID_DCOM_ProgrammingDate 5
#define RBFS_ProjectBB_82308            14  //C62X RC
#define RBFS_ProjectBB                  RBFS_ProjectBB_82308

#define RBFS_ASCETASW_FULL              1
#define RBFS_ASCETASW_STUBBED           2
#define RBFS_ASCETASW_BYPASSED          3

#define RBFS_WssDirInfoChangeable_YES   1
#define RBFS_WssDirInfoChangeable_NO    2

#define RBFS_ASCETASW                   RBFS_ASCETASW_FULL  // for test_RBVAR_OutputDriver_PROJECT.c
#define RBFS_WssDirInfoChangeable         RBFS_WssDirInfoChangeable_YES

typedef enum   /* TOOL_SCAN */
{
  C_RBWSSindexFL_N,
  C_RBWSSindexRR_N,
  C_RBWSSindexFR_N,
  C_RBWSSindexRL_N,
  C_RBWSSindexEnd_N
}WSSwheelIndex_N;
enum RBVAR_VehicleParameter_Id
{
    RBVAR_VehicleParameter_Id_varcode = 0x00u,

    RBVAR_COUNT_OF_VEHPARAMS   // Do not touch, it MUST be the last one

};

typedef struct _Var_RBData_ST
{
  UBYTE RBVarCode_UB;
} Var_RBData_ST;

typedef enum _EngineType_N /*TOOL_SCAN*/
{
  C_EngineType_Undefined_N = 0,
  C_EngineType_Gasoline_N,
  C_EngineType_Diesel_N,
  C_EngineType_Electrical_N
} EngineType_N;
typedef enum _GearboxType_N /*TOOL_SCAN*/
{
  C_GearboxType_Undefined_N = 0,
  C_GearboxType_Manual_N,
  C_GearboxType_Automat_N,
  C_GearboxType_CVTClutch_N,
  C_GearboxType_CVTConverter_N,
  C_GearboxType_ASGGearInfo_N,
  C_GearboxType_ASGNoGearInfo_N,
  C_GearboxType_TCTGearInfo_N,
  C_GearboxType_TCTNoGearInfo_N
} GearboxType_N;
typedef enum _DrvUnitType_N /*TOOL_SCAN*/
{
  C_DrvUnitType_Undef_N = 0,
  C_DrvUnitType_Combustion_N,
  C_DrvUnitType_Combustion_wStartStop_N,
  C_DrvUnitType_Electric_N,
  C_DrvUnitType_Hybrid_noPureElectricDriving_N,
  C_DrvUnitType_Hybrid_wPureElectricDriving_N
} DrvUnitType_N;

struct ASW_ModularVariants_t {
    uint8 VarCode;
};

DefineMESGType_ST(NMSG_VarRBData_ST, Var_RBData_ST);
DefineMESG(NMSG_VarRBData_ST);

DefineMESGType_EN(NMSG_EngineType_N, EngineType_N);
DefineMESG(NMSG_EngineType_N);

DefineMESGType_EN(NMSG_GearboxType_N, GearboxType_N);
DefineMESG(NMSG_GearboxType_N);

DefineMESGType_EN(NMSG_DrvUnitType_N, DrvUnitType_N);
DefineMESG(NMSG_DrvUnitType_N);


extern void NvM_SetBlockLockStatus(NvM_BlockIdType BlockId,
                            boolean BlockLocked);
extern Std_ReturnType NvM_WriteBlock(NvM_BlockIdType BlockId,
        void * NvM_SrcPtr);

extern Std_ReturnType NvM_GetErrorStatus(NvM_BlockIdType BlockId,
                                  NvM_RequestResultType * RequestResultPtr);

#endif /*  STUBS_H_  */

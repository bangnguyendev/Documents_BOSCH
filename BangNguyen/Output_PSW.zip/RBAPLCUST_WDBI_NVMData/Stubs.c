 /*
 **************************************************
 **     Project: RBAPLCUST_WDBI_NVMData
 ** Header File: Stubs.c
 **    Function: ./BAIC_ESP93CPi_RC_Init/MainstreamF30/rb/as/baic/core/app/dcom/RBAPLCust/src/RBAPLCUST_WDBI_NVMData.c
 **************************************************
 **
 **  Created on: Wed, May  6, 2020  1:43:33 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_C_
#define STUBS_C_

#include "include.h"


void NvM_SetBlockLockStatus(NvM_BlockIdType BlockId,
                            boolean BlockLocked){}

Std_ReturnType NvM_WriteBlock(NvM_BlockIdType BlockId,
        void * NvM_SrcPtr){}

Std_ReturnType NvM_GetErrorStatus(NvM_BlockIdType BlockId,
                                  NvM_RequestResultType * RequestResultPtr){}


#endif /*  STUBS_C_  */

/**
 * @ingroup 'RBAPLCust'
 * @{
 *
 * RBAPLCUST_WDBI_RealTireCircumfernce.c
 * Contains function to write the tire Circumference Information onto EEPROM
 *  
 * RBAPLCUST_RealTireCircumference_WriteData -- Write Data information
 *
 * DCOM_WriteDataByNvmId -----Actual write operation
 *
 *
 *
 * \copyright
 * Robert Bosch GmbH reserves all rights even in the event of industrial property rights.
 * We reserve all rights of disposal such as copying and passing on to third parties.
 */

#include "Dcm.h"
#include "NvM.h"
#include "NvM_Cfg.h"


/* used interfaces */
#include "RBAPLCust_Config.h"
#include "RB_AssertSwitchsettings.h"
#include "RBAPLCUST_Global.h"
#include "RBAPLCUST_NVMGeneric.h"
/* realized interfaces */

/* Assert supported configurations: switches, parameters, constants, ... */





DCOM_WriteNvmState_N EepromWriteByPdmState = C_InitWriteByPdm;



/* --------------------------------------------------------------------------
 * --------------------------------------------------------------------------
 * FUNCTION_NAME:
 *   DCOM_WriteDataByPdmId
 * FUNCTION_NAME_END:
 * --------------------------------------------------------------------------
 * FUNCTION_DESCRIPTION:
 *   Copy Data from specified  RAM location to the EEPROM
 *
 * FUNCTION_DESCRIPTION_END:
 * --------------------------------------------------------------------------
 * FUNCTION_PARAMETER:
 *   Block_Id 
 *   void* Data; Generic RAM pointer to the same variable type as the one to write
 *   dataNegRespCode_u8,Pointer to the NRC code
 * FUNCTION_PARAMETER_END:
 * --------------------------------------------------------------------------
 * FUNCTION_RETURN:
 * TRUE when Read is complete
 * FUNCTION_RETURN_END:
 * --------------------------------------------------------------------------
 */
Std_ReturnType DCOM_WriteDataByNvmId (NvM_BlockIdType Block_Id,const uint8* Data,P2VAR(Dcm_NegativeResponseCodeType,AUTOMATIC,DCM_INTERN_DATA) dataNegRespCode_u8)
{
	static NvM_RequestResultType l_NvM_Result;
	VAR(Std_ReturnType,AUTOMATIC) dataRetVal_u8;

	dataRetVal_u8 = DCM_E_PENDING;

	switch (EepromWriteByPdmState)
	{
	case C_InitWriteByPdm:
	{
		/*block should be unlocked before writing */
		NvM_SetBlockLockStatus(Block_Id,FALSE);

		if (NvM_WriteBlock (Block_Id,Data) == E_OK)
		{
			EepromWriteByPdmState = C_ProcessingWriteByPdm;

		}
		else
		{		
			EepromWriteByPdmState = C_ErrorWriteByPdm;
			/* Lock the block,accessing the nvm is not successful */
			NvM_SetBlockLockStatus(Block_Id,TRUE);

		}
		break;
	}


	case C_ProcessingWriteByPdm:
	{
		if (NvM_GetErrorStatus(Block_Id,&l_NvM_Result)== E_OK)
		{
			switch (l_NvM_Result)
			{
			case NVM_REQ_OK:
			{
				/* Lock the block after the successful write */
				NvM_SetBlockLockStatus(Block_Id,TRUE);
				EepromWriteByPdmState  = C_DoneWriteByPdm;
				break;
			}

			case NVM_REQ_PENDING:
			{
				break;
			}

			default:
			{
				EepromWriteByPdmState  = C_ErrorWriteByPdm;
				/* Lock the block,Status of the read is not successful */
				NvM_SetBlockLockStatus(Block_Id,TRUE);
				break;
			}
			}
		}
		else
		{
			EepromWriteByPdmState = C_ErrorWriteByPdm;
			/* Lock the block,Read state is terminated */
			NvM_SetBlockLockStatus(Block_Id,TRUE);
		}
		break;
	}

	case C_DoneWriteByPdm:
	{

		EepromWriteByPdmState = C_InitWriteByPdm;
		dataRetVal_u8 = E_OK;
		break;
	}

	case C_ErrorWriteByPdm:
	default:
	{

		EepromWriteByPdmState = C_InitWriteByPdm;
		*dataNegRespCode_u8 = DCM_E_CONDITIONSNOTCORRECT;
		dataRetVal_u8 = E_NOT_OK;
		break;
	}

	}

	return(dataRetVal_u8);
}



/*
 * --------------------------------------------------------------------------
 * FUNCTION_NAME:
 *   RBAPLCUST_RealTireCircumference_WriteData
 * FUNCTION_NAME_END:
 * --------------------------------------------------------------------------
 * FUNCTION_DESCRIPTION:
 *  Data --- corresponding buffer  of incoming write data,ErrorCode ---- NRC to be set.   
 * FUNCTION_DESCRIPTION_END:
 * --------------------------------------------------------------------------
 * FUNCTION_PARAMETER:
 * write the Real tire Circumference
 * FUNCTION_PARAMETER_END:
 * --------------------------------------------------------------------------
 * FUNCTION_RETURN:
 * E_OK -- means the function is executed successfully  
 * E_NOT_OK -- means the function is not completed / error code
 * DCM_E_PENDING -- means if the function is pending and DCM calls the 
 *                  function once again
 * FUNCTION_RETURN_END:
 * --------------------------------------------------------------------------
 */

FUNC(Std_ReturnType,DCM_APPL_CODE) RBAPLCUST_FillingInStatus_WriteData(
		P2VAR(uint8,AUTOMATIC,DCM_INTERN_DATA) Data,P2VAR(Dcm_NegativeResponseCodeType,AUTOMATIC,DCM_INTERN_DATA) ErrorCode)
{

	VAR(Std_ReturnType,AUTOMATIC) dataRetWriteFunc_u8 = E_NOT_OK;


	dataRetWriteFunc_u8 = DCOM_WriteDataByNvmId(NvMConf_NvMBlockDescriptor_NVM_ID_DCOM_FillingInStatus,Data,ErrorCode);

	return dataRetWriteFunc_u8;


}

FUNC(Std_ReturnType,DCM_APPL_CODE) RBAPLCUST_EOLStatus_WriteData(
		P2VAR(uint8,AUTOMATIC,DCM_INTERN_DATA) Data,P2VAR(Dcm_NegativeResponseCodeType,AUTOMATIC,DCM_INTERN_DATA) ErrorCode)
{

	VAR(Std_ReturnType,AUTOMATIC) dataRetWriteFunc_u8 = E_NOT_OK;


	dataRetWriteFunc_u8 = DCOM_WriteDataByNvmId(NvMConf_NvMBlockDescriptor_NVM_ID_DCOM_EOLStatus,Data,ErrorCode);

	return dataRetWriteFunc_u8;


}

FUNC(Std_ReturnType,DCM_APPL_CODE) RBAPLCUST_VIN_WriteData(
		P2VAR(uint8,AUTOMATIC,DCM_INTERN_DATA) Data,P2VAR(Dcm_NegativeResponseCodeType,AUTOMATIC,DCM_INTERN_DATA) ErrorCode)
{

	VAR(Std_ReturnType,AUTOMATIC) dataRetWriteFunc = E_NOT_OK;


	dataRetWriteFunc = DCOM_WriteDataByNvmId(NvMConf_NvMBlockDescriptor_NVM_ID_BLDR_VIN,Data,ErrorCode);

	return dataRetWriteFunc;


}

#if ((RBFS_ProjectBB == RBFS_ProjectBB_97330)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99990)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_97331)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_97365)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99989)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99011)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99012)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_99117)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_81018)\
	|| (RBFS_ProjectBB == RBFS_ProjectBB_82308)\
	)
FUNC(Std_ReturnType,DCM_APPL_CODE) RBAPLCUST_ProgrammingDate_WriteData(
		P2VAR(uint8,AUTOMATIC,DCM_INTERN_DATA) Data,P2VAR(Dcm_NegativeResponseCodeType,AUTOMATIC,DCM_INTERN_DATA) ErrorCode)
{

	VAR(Std_ReturnType,AUTOMATIC) dataRetWriteFunc = E_NOT_OK;


	dataRetWriteFunc = DCOM_WriteDataByNvmId(NvMConf_NvMBlockDescriptor_NVM_ID_DCOM_ProgrammingDate,Data,ErrorCode);

	return dataRetWriteFunc;


}
#endif

/** @} */
/* End ingroup 'RBAPLCust' */

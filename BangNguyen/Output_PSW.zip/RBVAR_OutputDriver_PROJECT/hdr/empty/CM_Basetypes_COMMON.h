 /*
 **************************************************
 **     Project: RBVAR_OutputDriver_PROJECT
 ** Header File: CM_Basetypes_COMMON.h
 **    Function: ./BAIC_ESP93CPi_RC_Init/MainstreamF30/rb/as/baic/CpiwAPB/app/dsm/RBVAR/src/RBVAR_OutputDriver_PROJECT.c
 **************************************************
 **
 **  Created on: Wed, May  6, 2020  1:43:41 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef CM_BASETYPES_COMON_H_
#define CM_BASETYPES_COMON_H_

#include "include.h"


#endif /*  CM_BASETYPES_COMON_H_  */

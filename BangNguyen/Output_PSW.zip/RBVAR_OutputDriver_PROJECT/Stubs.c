 /*
 **************************************************
 **     Project: RBVAR_OutputDriver_PROJECT
 ** Header File: Stubs.c
 **    Function: ./BAIC_ESP93CPi_RC_Init/MainstreamF30/rb/as/baic/CpiwAPB/app/dsm/RBVAR/src/RBVAR_OutputDriver_PROJECT.c
 **************************************************
 **
 **  Created on: Wed, May  6, 2020  1:43:46 PM
 **      Author: HC-UT40277C
 **   Copyright: bang.nguyen-duy
 **************************************************
 */



#ifndef STUBS_C_
#define STUBS_C_

#include "include.h"
void ASW_setVariant(struct ASW_ModularVariants_t *ASW_ModularVariants){}







#endif /*  STUBS_C_  */

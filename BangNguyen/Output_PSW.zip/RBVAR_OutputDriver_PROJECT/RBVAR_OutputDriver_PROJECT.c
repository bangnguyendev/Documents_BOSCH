/******************************************************************************/
/* [HISTORY_GENERATOR_V1]                                                     */
/******************************************************************************/
/* THIS IS TOOL GENERATED DATA, DO NOT CHANGE !!!                             */
/******************************************************************************/
/* [COPYRIGHT]                                                                */
/* Robert Bosch GmbH reserves all rights even in the event of industrial      */
/* property rights. We reserve all rights of disposal such as copying and     */
/* passing on to third parties.                                               */
/* [COPYRIGHT_END]                                                            */
/******************************************************************************/
/* [HISTORY]                                                                  */
/* -------------------------------------------------------------------------- */
/* [FILE_BASIC_INFO]                                                          */
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/* Description   :                                                            */
/* Note          :                                                            */
/* -------------------------------------------------------------------------- */
/* [FILE_BASIC_INFO_END]                                                      */
/******************************************************************************/
/* [FILE_CHANGE_ENTRIES]                                                      */
/* -------------------------------------------------------------------------- */
/* Revision      : 1.0                                                        */
/* Checked in by : stk7kor                                                    */
/* Check in date : 12.02.2014 19:04:40                                        */
/*                 02/12/2014 19:04:40                                        */
/* Changes       : V362C ESP: Var Updates for CSW2                            */
/* Reasons       : CSCRM00615898                                              */
/*                                                                            */
/* CSCRM00615898 : V362C ESP: Var Updates for CSW2                            */
/*               : CSCRM00613373 : V362C ESP: Var Updates for CSW2            */
/* -------------------------------------------------------------------------- */
/* [FILE_CHANGE_ENTRIES_END]                                                  */
/* -------------------------------------------------------------------------- */
/* [HISTORY_END]                                                              */
/******************************************************************************/
/* [HISTORY_GENERATOR_V1_END]                                                 */
/******************************************************************************/


/**
 * WARNING: This file is a template, do not use without adaption to project requirements
 */

#include "CM_Basetypes_COMMON.h"

#include "RBVAR_STATEMACHINE_PROJECT.h"
#include "RBVAR_Config_PROJECT.h"
#include "RBVAR_IDDefinitionTable_PROJECT.h"
#include "RBVAR_OutputDriver_PROJECT.h"
#include "RBVAR_VarCode_PROJECT.h"
#include "DNCIF_CommonConfig_Project.h"
#include "DNCIF_CustomerSpecific_F30.h"

#include "ASWIF_CommonConfig.h"

#if (RBFS_ASCETASW == RBFS_ASCETASW_FULL)
#include "ASW_Runtime_System.h"

#endif
//Value of calculated variant code.
uint8 RBVAR_VariantCode_UB;
/*[[MEASUREMENT*/
/*NAME=RBVAR_VariantCode_UB*/
/*MODEL_NAME=RBVAR_VariantCode_UB*/
/*DATA_TYPE=uint8*/
/*COMMENT=ASW Variant calculated */
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=0xFF*/
/*MTEVENT=c_MT_Default_Task_x1*/
/*]]MEASUREMENT*/

BOOL RBVAR_VAF_VAR_3_Support = FALSE;
/*[[MEASUREMENT*/
/*NAME=RBVAR_VAF_VAR_3_Support*/
/*MODEL_NAME=RBVAR_VAF_VAR_3_Support*/
/*DATA_TYPE=BOOL*/
/*COMMENT=VAF VLC -support*/
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=0x1*/
/*MTEVENT=c_MT_Default_Task_x1*/
/*]]MEASUREMENT*/

BOOL RBVAR_SAS_VAR_3_Support = FALSE;
/*[[MEASUREMENT*/
/*NAME=RBVAR_SAS_VAR_3_Support*/
/*MODEL_NAME=RBVAR_SAS_VAR_3_Support*/
/*DATA_TYPE=BOOL*/
/*COMMENT= Bosch SAS CAL-support*/
/*FORMULA=NF_IDENTITY*/
/*MINBORDER=0*/
/*MAXBORDER=0x1*/
/*MTEVENT=c_MT_Default_Task_x1*/
/*]]MEASUREMENT*/
// Sends all necessary parameter depended messages

/*
 * DE: This function set VAR info to ASW side
 *
 */
void FNC_VAR_OutputDriver(const uint8 * const CDPVars)
{
	  /* RBFS_ProjectBB_97365 -->C40 */

#if(RBFS_ProjectBB == RBFS_ProjectBB_97365||RBFS_ProjectBB == RBFS_ProjectBB_99989||RBFS_ProjectBB == RBFS_ProjectBB_81018)

/*****************************************************************/
/******************DriveType*************************************/
   switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
    {
        case 0x01:
		case 0x02:
		case 0x03:
			SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Electric_N);
        break;
        default:
        	SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Undef_N);
        break;
    }
/*****************************************************************/
/******************Engine Unit Type********************************/
   switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
    {
        case 0x01:
		case 0x02:
		case 0x03:

            SendMESG(NMSG_EngineType_N, C_EngineType_Electrical_N);
            break;
        default:
            SendMESG(NMSG_EngineType_N, C_EngineType_Undefined_N);
        break;
    }
/*****************************************************************/
/******************Gearbox Unit Type********************************/
      switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
    {
        case 0x01:
		case 0x02:
		case 0x03:
           SendMESG(NMSG_GearboxType_N, C_GearboxType_Automat_N);
        break;
        default:
           SendMESG(NMSG_GearboxType_N, C_GearboxType_Undefined_N);
        break;
    }
/*****************************************************************/
/******************VLC*************************************/
   switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
    {
        case 0x01:
        case 0x03:
			RBVAR_VAF_VAR_3_Support = FALSE;
        break;
        case 0x02:
			RBVAR_VAF_VAR_3_Support = TRUE;
            
        break;
        default:
        	RBVAR_VAF_VAR_3_Support = FALSE;
        break;
    }
/*****************************************************************/

/*****************************************************************/
      /* RBFS_ProjectBB_97330 -->C51 */
#elif(RBFS_ProjectBB == RBFS_ProjectBB_97330||RBFS_ProjectBB == RBFS_ProjectBB_99990)
      /******************DriveType*************************************/
         switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
          {
              case 0x01:
      		  case 0x02:
      			SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Electric_N);
              break;
              default:
            	  SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Undef_N);
              break;
          }
      /*****************************************************************/
      /******************Engine Unit Type********************************/
         switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
          {
              case 0x01:
              case 0x02:

                  SendMESG(NMSG_EngineType_N, C_EngineType_Electrical_N);
                  break;
              default:
                  SendMESG(NMSG_EngineType_N, C_EngineType_Undefined_N);
              break;
          }
      /*****************************************************************/
      /******************Gearbox Unit Type********************************/
            switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
          {
              case 0x01:
              case 0x02:
                 SendMESG(NMSG_GearboxType_N, C_GearboxType_Automat_N);
              break;
              default:
                 SendMESG(NMSG_GearboxType_N, C_GearboxType_Undefined_N);
              break;
          }
            /*******************************************************/
			/******************VLC*************************************/
   switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
    {
        case 0x01:   
			RBVAR_VAF_VAR_3_Support = FALSE;
        break;
        case 0x02:
			RBVAR_VAF_VAR_3_Support = TRUE;
            
        break;
        default:
        	RBVAR_VAF_VAR_3_Support = FALSE;
        break;
    }
/*****************************************************************/
    		/*  RBFS_ProjectBB_97331 --> C62 */
#elif((RBFS_ProjectBB == RBFS_ProjectBB_97331)||(RBFS_ProjectBB == RBFS_ProjectBB_82308))
            /******************DriveType*************************************/
               switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
                {
                    case 0x01:
            		case 0x02:
            		case 0x03:
            		case 0x04:
            			SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Combustion_N);
                    break;
                    default:
                    	SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Undef_N);
                    break;
                }
            /*****************************************************************/
            /******************Engine Unit Type********************************/
               switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
                {
                    case 0x01:
                    case 0x02:
                    case 0x03:
                    case 0x04:
                        SendMESG(NMSG_EngineType_N, C_EngineType_Gasoline_N);
                        break;
                    default:
                        SendMESG(NMSG_EngineType_N, C_EngineType_Undefined_N);
                    break;
                }
            /*****************************************************************/
            /******************Gearbox Unit Type********************************/
                  switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
                {
                    case 0x01:
                    	  SendMESG(NMSG_GearboxType_N, C_GearboxType_Manual_N);
                    	  break;
                    case 0x02:
                    case 0x03:
                       SendMESG(NMSG_GearboxType_N, C_GearboxType_TCTGearInfo_N);
                    break;
                    case 0x04:
                       SendMESG(NMSG_GearboxType_N, C_GearboxType_TCTGearInfo_N);
                    break;
                    default:
                       SendMESG(NMSG_GearboxType_N, C_GearboxType_Undefined_N);
                    break;
                }

                  /**********************************************************/
				/******************VLC*************************************/
				   switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				    {
				        case 0x01:   
						case 0x02:
							RBVAR_VAF_VAR_3_Support = FALSE;
							RBVAR_SAS_VAR_3_Support = FALSE;
				        break;
				        case 0x03:
							RBVAR_VAF_VAR_3_Support = TRUE;
							RBVAR_SAS_VAR_3_Support = TRUE;
            
				        break;
				        case 0x04:
							RBVAR_VAF_VAR_3_Support = TRUE;
							RBVAR_SAS_VAR_3_Support = TRUE;

				        break;
				        default:
				        	RBVAR_VAF_VAR_3_Support = FALSE;
				        	RBVAR_SAS_VAR_3_Support = FALSE;
				        break;
				    }
				/*****************************************************************/
/*  RBFS_ProjectBB_99011 --> C40 C06 */
#elif(RBFS_ProjectBB == RBFS_ProjectBB_99011)
				               /******************DriveType*************************************/
				                  switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				                   {
				                    case 0x01:
				               		case 0x02:
				               		case 0x03:
				                    case 0x04:
				               		case 0x05:
				               		case 0x06:
				                    case 0x07:
				               		case 0x08:
				               		case 0x09:
				                    case 0x10:
				               			SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Combustion_N);
				                    break;
				                    default:
				                       	SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Undef_N);
				                    break;
				                   }
				               /*****************************************************************/
				               /******************Engine Unit Type********************************/
				                  switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				                   {
				                    case 0x01:
				               		case 0x02:
				               		case 0x03:
				                    case 0x04:
				               		case 0x05:
				               		case 0x06:
				                    case 0x07:
				               		case 0x08:
				               		case 0x09:
				                    case 0x10:
				                           SendMESG(NMSG_EngineType_N, C_EngineType_Gasoline_N);
				                           break;
				                       default:
				                           SendMESG(NMSG_EngineType_N, C_EngineType_Undefined_N);
				                       break;
				                   }
				               /*****************************************************************/
				               /******************Gearbox Unit Type********************************/
				                     switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				                   {
					                    case 0x01:
					               		case 0x02:
					               		case 0x03:
					                    case 0x04:
					               		case 0x08:
					               		case 0x09:
					                    case 0x10:
				                       	  SendMESG(NMSG_GearboxType_N, C_GearboxType_Manual_N);
				                       	break;
					               		case 0x05:
					               		case 0x06:
					                    case 0x07:
				                          SendMESG(NMSG_GearboxType_N, C_GearboxType_CVTConverter_N);
				                       break;
				                       default:
				                          SendMESG(NMSG_GearboxType_N, C_GearboxType_Undefined_N);
				                       break;
				                   }

				                     /**********************************************************/
				   				/******************VLC*************************************/
				   				   switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				   				    {
				                    case 0x01:
				               		case 0x02:
				               		case 0x03:
				                    case 0x04:
				               		case 0x05:
				               		case 0x06:
				                    case 0x07:
				               		case 0x08:
				               		case 0x09:
				                    case 0x10:
				   							RBVAR_VAF_VAR_3_Support = FALSE;
				   							RBVAR_SAS_VAR_3_Support = FALSE;
				   				    break;

				   				    default:
				   				        	RBVAR_VAF_VAR_3_Support = FALSE;
				   				        	RBVAR_SAS_VAR_3_Support = FALSE;
				   				    break;
				   				    }
				   				/*****************************************************************/
/*  RBFS_ProjectBB_99011 --> C51 M08 */
#elif(RBFS_ProjectBB == RBFS_ProjectBB_99012)
				   				/******************DriveType*************************************/
				   				switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				   				{
				   					case 0x01:
				   					case 0x02:
				   					case 0x03:
				   					SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Combustion_N);
				   					break;
				   					default:
				   					SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Undef_N);
				   					break;
				   				 }
				   				/*****************************************************************/
				   				/******************Engine Unit Type********************************/
				   				switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				   				{
				   					case 0x01:
				   					case 0x02:
				   					case 0x03:
				   					SendMESG(NMSG_EngineType_N, C_EngineType_Gasoline_N);
				   					break;
				   					default:
				   					SendMESG(NMSG_EngineType_N, C_EngineType_Undefined_N);
				   					break;
				   				}
				   				/*****************************************************************/
				   				/******************Gearbox Unit Type********************************/
				   				switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				   				{
				   					case 0x01:
				   					SendMESG(NMSG_GearboxType_N, C_GearboxType_Manual_N);
				   					break;
				   					case 0x02:
				   					case 0x03:
				   					SendMESG(NMSG_GearboxType_N, C_GearboxType_Automat_N);
				   					break;
				   					default:
				   					SendMESG(NMSG_GearboxType_N, C_GearboxType_Undefined_N);
				   					break;
				   				}

				   				/**********************************************************/
				   				/******************VLC*************************************/
				   				switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				   				{
				   					case 0x01:
				   					case 0x02:
				   						RBVAR_VAF_VAR_3_Support = FALSE;
				   						RBVAR_SAS_VAR_3_Support = FALSE;
				   					break;
				   					case 0x03:
				   						RBVAR_VAF_VAR_3_Support = TRUE;
				   						RBVAR_SAS_VAR_3_Support = TRUE;

				   					break;
				   					default:
				   						RBVAR_VAF_VAR_3_Support = FALSE;
				   						RBVAR_SAS_VAR_3_Support = FALSE;
				   					break;
				   				}
				   				/*****************************************************************/

/*  RBFS_ProjectBB_99117 --> C53F */
#elif(RBFS_ProjectBB == RBFS_ProjectBB_99117)
				   				/******************DriveType*************************************/
				   				switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				   				{
				   					case 0x01:
				   					case 0x02:
				   						SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Combustion_N);
				   					break;
				   					default:
				   						SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Undef_N);
				   					break;
				   				}
				   				/*****************************************************************/
				   				/******************Engine Unit Type********************************/
				   				switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				   				{
				   					case 0x01:
				   					case 0x02:
				   						SendMESG(NMSG_EngineType_N, C_EngineType_Gasoline_N);
				   					break;
				   					default:
				   						SendMESG(NMSG_EngineType_N, C_EngineType_Undefined_N);
				   					break;
				   				}
				   				/*****************************************************************/
				   				/******************Gearbox Unit Type********************************/
				   				switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
				   				{
				   					case 0x01:
				   						SendMESG(NMSG_GearboxType_N,C_GearboxType_Manual_N );
				   					break;
				   					case 0x02:
				   						SendMESG(NMSG_GearboxType_N, C_GearboxType_CVTConverter_N);
				   					break;
				   					default:
				   						SendMESG(NMSG_GearboxType_N, C_GearboxType_Undefined_N);
				   					break;
				   				}

								/**********************************************************/
								/******************VLC*************************************/
								switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
								{
									case 0x01:
										RBVAR_VAF_VAR_3_Support = FALSE;
										RBVAR_SAS_VAR_3_Support = FALSE;
									break;
									case 0x02:
										RBVAR_VAF_VAR_3_Support = FALSE;
										RBVAR_SAS_VAR_3_Support = FALSE;

									break;
									default:
										RBVAR_VAF_VAR_3_Support = FALSE;
										RBVAR_SAS_VAR_3_Support = FALSE;
									break;
								}
								/*****************************************************************/


				   /*  RBFS_ProjectBB_97164 --> C11 */

        #elif(RBFS_ProjectBB == RBFS_ProjectBB_97164)
                  /******************DriveType*************************************/
                           switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
                            {
                                case 0x01:

                        			SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Electric_N);
                                break;
                                default:
                                	SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Undef_N);
                                break;
                            }
                        /*****************************************************************/
                        /******************Engine Unit Type********************************/
                           switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
                            {
                                case 0x01:


                                    SendMESG(NMSG_EngineType_N, C_EngineType_Electrical_N);
                                    break;
                                default:
                                    SendMESG(NMSG_EngineType_N, C_EngineType_Undefined_N);
                                break;
                            }
                        /*****************************************************************/
                        /******************Gearbox Unit Type********************************/
                              switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
                            {
                                case 0x01:

                                   SendMESG(NMSG_GearboxType_N, C_GearboxType_Automat_N);
                                break;
                                default:
                                   SendMESG(NMSG_GearboxType_N, C_GearboxType_Undefined_N);
                                break;
                            }

                              /*****************************************************************/
							           
									/******************ACC*************************************/
						   switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
						    {
						        case 0x01:   
									RBVAR_VAF_VAR_3_Support = TRUE;
						        break;
						        default:
						        	RBVAR_VAF_VAR_3_Support = FALSE;
						        break;
						    }
						/*****************************************************************/
                              /*  RBFS_ProjectBB_97527 --> C35*/
                              #elif(RBFS_ProjectBB == RBFS_ProjectBB_97527)
                                    /******************DriveType*************************************/
                                       switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
                                        {
                                            case 0x01:
                                    		  case 0x02:
                                    			SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Electric_N);
                                            break;
                                            default:
                                            	SendMESG(NMSG_DrvUnitType_N, C_DrvUnitType_Undef_N);
                                            break;
                                        }
                                    /*****************************************************************/
                                    /******************Engine Unit Type********************************/
                                       switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
                                        {
                                            case 0x01:
                                            case 0x02:

                                                SendMESG(NMSG_EngineType_N, C_EngineType_Electrical_N);
                                                break;
                                            default:
                                                SendMESG(NMSG_EngineType_N, C_EngineType_Undefined_N);
                                            break;
                                        }
                                    /*****************************************************************/
                                    /******************Gearbox Unit Type********************************/
                                          switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
                                        {
                                            case 0x01:
                                            case 0x02:
                                               SendMESG(NMSG_GearboxType_N, C_GearboxType_Automat_N);
                                            break;
                                            default:
                                               SendMESG(NMSG_GearboxType_N, C_GearboxType_Undefined_N);
                                            break;
                                        }
          /*******************************************************/
			/******************VLC*************************************/
   switch (CDPVars[RBVAR_VehicleParameter_Id_varcode])
    {
        case 0x01:   
			RBVAR_VAF_VAR_3_Support = FALSE;
        break;
        case 0x02:
			RBVAR_VAF_VAR_3_Support = TRUE;
            
        break;
        default:
        	RBVAR_VAF_VAR_3_Support = FALSE;
        break;
    }
/*****************************************************************/
#else

#endif

}


// Sends variant code via message.
// PRQA S 3206 2
void FNC_VAR_SendVariantCode(const uint8 pVariantCode)
{
    // Place sending variant code here
    // It is empty currently
    // Please remove QAC suppress when once fill it....
	Var_RBData_ST l_RBVarcode_ST;
#if (RBFS_ASCETASW == RBFS_ASCETASW_FULL)
	 struct ASW_ModularVariants_t  l_modularVariants;
#endif

	l_RBVarcode_ST.RBVarCode_UB = pVariantCode;

	SendMESG(NMSG_VarRBData_ST, l_RBVarcode_ST);

#if (RBFS_ASCETASW == RBFS_ASCETASW_FULL)
     l_modularVariants.VarCode =pVariantCode;

	 ASW_setVariant(&l_modularVariants);
#endif
}



/* FUNCTION_DEFINITIONS_END:                                                */
/****************************************************************************/

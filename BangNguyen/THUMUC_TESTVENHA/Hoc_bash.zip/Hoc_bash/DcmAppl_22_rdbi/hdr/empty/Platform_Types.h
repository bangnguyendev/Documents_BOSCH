/*
 * Platform_Types.h
 *
 *  Created on: Apr 22, 2020
 *      Author: nbg7hc
 */

#ifndef HDR_PLATFORM_TYPES_H_
#define HDR_PLATFORM_TYPES_H_


#include "include.h"

#endif /* HDR_PLATFORM_TYPES_H_ */

/*
 * ASWIF_CommonConfig.h
 *
 *  Created on: Apr 22, 2020
 *      Author: nbg7hc
 */

#ifndef HDR_ASWIF_COMMONCONFIG_H_
#define HDR_ASWIF_COMMONCONFIG_H_


#include "include.h"

#endif /* HDR_ASWIF_COMMONCONFIG_H_ */

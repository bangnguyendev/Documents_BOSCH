/*
 * RBSMM_Requester_Cfg.h
 *
 *  Created on: Apr 22, 2020
 *      Author: nbg7hc
 */

#ifndef HDR_RBSMM_REQUESTER_CFG_H_
#define HDR_RBSMM_REQUESTER_CFG_H_


#include "include.h"

#endif /* HDR_RBSMM_REQUESTER_CFG_H_ */

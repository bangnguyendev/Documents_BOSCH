"{a[0]}".format(a=object) # [invalid-format-index]
